/*
 * ====================================================================
 *
 * Greater Lowell Technical High School
 *
 * Custom Aspen X2 Export
 *
 * ====================================================================
 */
package com.x2dev.reports.ma.lowell;

import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
import com.follett.fsc.core.framework.persistence.SubQuery;
import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.DistrictSchoolYearContext;
import com.follett.fsc.core.k12.beans.X2BaseBean;
import com.follett.fsc.core.k12.tools.exports.ExportJavaSource;
import com.follett.fsc.core.k12.tools.reports.ReportDataGrid;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.GradeTerm;
import com.x2dev.sis.model.beans.GradeTermDate;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.StudentAttendance;
import com.x2dev.sis.tools.reports.StudentContextReportHelper;
import com.x2dev.utils.DataGrid;
import com.x2dev.utils.StringUtils;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.apache.ojb.broker.query.QueryByCriteria;

/**
 * Attendance Policy Unexcused Absence Export.
 *
 * Calculates unexcused absences per GLTHS attendance policy:
 * - 1 unexcused absence per unexcused full-day absence (codes A, AT, AD with portionAbsent = 1.0)
 * - 4 unexcused tardies (portionAbsent = 0.0) = 1 additional unexcused absence
 * - 4 unexcused dismissals (portionAbsent = 0.0) = 1 additional unexcused absence
 *
 * Outputs CSV with student name, LASID, breakdown counts, and calculated total.
 */
public class AttendancePolicyExportData extends ExportJavaSource
{
    private static final long serialVersionUID = 1L;

    // Input parameter names
    private static final String CONTEXT_OID_PARAM    = "contextOid";
    private static final String FULL_YEAR_PARAM      = "fullYear";
    private static final String GRADE_TERM_OID_PARAM = "gradeTermOid";
    private static final String THRESHOLD_PARAM      = "threshold";
    private static final String QUERY_BY_PARAM       = "queryBy";
    private static final String QUERY_STRING_PARAM   = "queryString";

    // Attendance codes that count as full unexcused absences
    private static final String CODE_ABSENT          = "A";
    private static final String CODE_ABSENT_TARDY    = "AT";
    private static final String CODE_ABSENT_DISMISS  = "AD";

    // Tardy/dismissal to absence conversion ratio
    private static final int TARDY_DISMISSAL_RATIO = 4;

    // CSV column names
    private static final String COL_STUDENT_NAME         = "Student Name";
    private static final String COL_LASID                = "LASID";
    private static final String COL_FULL_ABSENCES        = "Full Absences (A/AT/AD)";
    private static final String COL_UNEXCUSED_TARDIES    = "Unexcused Tardies";
    private static final String COL_TARDY_EQUIVALENT     = "Tardy Absence Equivalent";
    private static final String COL_UNEXCUSED_DISMISSALS = "Unexcused Dismissals";
    private static final String COL_DISMISSAL_EQUIVALENT = "Dismissal Absence Equivalent";
    private static final String COL_TOTAL                = "Total Unexcused Absences";

    // Member variables
    private DistrictSchoolYearContext m_context;
    private GradeTerm                m_gradeTerm;
    private PlainDate                m_startDate;
    private PlainDate                m_endDate;
    private int                      m_threshold;
    private X2Criteria               m_studentCriteria;
    private List<String>             m_columnNames;
    private List<String>             m_columnUserNames;

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#gatherData()
     */
    @Override
    protected DataGrid gatherData()
    {
        ReportDataGrid grid = new ReportDataGrid();

        resolveTermDates();

        if (m_startDate == null || m_endDate == null)
        {
            grid.beforeTop();
            return grid;
        }

        /*
         * Load students matching criteria
         */
        QueryByCriteria studentQuery = new QueryByCriteria(SisStudent.class, m_studentCriteria);
        studentQuery.addOrderByAscending(SisStudent.COL_NAME_VIEW);
        Collection<SisStudent> students = getBroker().getCollectionByQuery(studentQuery);

        if (students.isEmpty())
        {
            grid.beforeTop();
            return grid;
        }

        /*
         * Load all unexcused attendance records for these students within the term date range.
         * Group by student OID for efficient per-student processing.
         */
        X2Criteria attCriteria = new X2Criteria();
        attCriteria.addGreaterOrEqualThan(StudentAttendance.COL_DATE, m_startDate);
        attCriteria.addLessOrEqualThan(StudentAttendance.COL_DATE, m_endDate);
        attCriteria.addEqualTo(StudentAttendance.COL_EXCUSED_INDICATOR, Boolean.FALSE);

        SubQuery studentSubQuery = new SubQuery(SisStudent.class, X2BaseBean.COL_OID, m_studentCriteria);
        attCriteria.addIn(StudentAttendance.COL_STUDENT_OID, studentSubQuery);

        QueryByCriteria attQuery = new QueryByCriteria(StudentAttendance.class, attCriteria);
        Map<String, Collection<StudentAttendance>> attendanceMap =
                getBroker().getGroupedCollectionByQuery(attQuery, StudentAttendance.COL_STUDENT_OID, 500);

        /*
         * Process each student: count absences, tardies, dismissals and calculate totals
         */
        for (SisStudent student : students)
        {
            int fullAbsences = 0;
            int unexcusedTardies = 0;
            int unexcusedDismissals = 0;

            Collection<StudentAttendance> records = attendanceMap.get(student.getOid());
            if (records != null)
            {
                for (StudentAttendance att : records)
                {
                    BigDecimal portion = att.getPortionAbsent();
                    String code = att.getCodeView();

                    /*
                     * Full unexcused absences: portionAbsent = 1.0 with codes A, AT, or AD
                     */
                    if (portion != null && portion.compareTo(BigDecimal.ONE) == 0
                            && (CODE_ABSENT.equals(code) || CODE_ABSENT_TARDY.equals(code)
                                    || CODE_ABSENT_DISMISS.equals(code)))
                    {
                        fullAbsences++;
                    }

                    /*
                     * Unexcused tardies with portionAbsent = 0.0
                     */
                    if (portion != null && portion.compareTo(BigDecimal.ZERO) == 0
                            && att.getTardyIndicator())
                    {
                        unexcusedTardies++;
                    }

                    /*
                     * Unexcused dismissals with portionAbsent = 0.0
                     */
                    if (portion != null && portion.compareTo(BigDecimal.ZERO) == 0
                            && att.getDismissedIndicator())
                    {
                        unexcusedDismissals++;
                    }
                }
            }

            int tardyEquiv = unexcusedTardies / TARDY_DISMISSAL_RATIO;
            int dismissalEquiv = unexcusedDismissals / TARDY_DISMISSAL_RATIO;
            int total = fullAbsences + tardyEquiv + dismissalEquiv;

            /*
             * Apply threshold filter — skip students below the minimum
             */
            if (m_threshold > 0 && total < m_threshold)
            {
                continue;
            }

            grid.append();
            grid.set(COL_STUDENT_NAME, student.getNameView());
            grid.set(COL_LASID, student.getLocalId());
            grid.set(COL_FULL_ABSENCES, Integer.toString(fullAbsences));
            grid.set(COL_UNEXCUSED_TARDIES, Integer.toString(unexcusedTardies));
            grid.set(COL_TARDY_EQUIVALENT, Integer.toString(tardyEquiv));
            grid.set(COL_UNEXCUSED_DISMISSALS, Integer.toString(unexcusedDismissals));
            grid.set(COL_DISMISSAL_EQUIVALENT, Integer.toString(dismissalEquiv));
            grid.set(COL_TOTAL, Integer.toString(total));
        }

        grid.beforeTop();
        grid.sort(Arrays.asList(COL_STUDENT_NAME), false);
        return grid;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#initialize()
     */
    @Override
    protected void initialize() throws X2BaseException
    {
        super.initialize();

        /*
         * Load school year context
         */
        String contextOid = (String) getParameter(CONTEXT_OID_PARAM);
        m_context = (DistrictSchoolYearContext) getBroker().getBeanByOid(
                DistrictSchoolYearContext.class, contextOid);

        /*
         * Load grade term (skip if Full Year checkbox is checked)
         */
        Boolean fullYear = (Boolean) getParameter(FULL_YEAR_PARAM);
        if (fullYear == null || !fullYear.booleanValue())
        {
            String gradeTermOid = (String) getParameter(GRADE_TERM_OID_PARAM);
            if (!StringUtils.isEmpty(gradeTermOid))
            {
                m_gradeTerm = (GradeTerm) getBroker().getBeanByOid(GradeTerm.class, gradeTermOid);
            }
        }

        /*
         * Parse threshold (blank or non-numeric = 0 = show all)
         */
        String thresholdStr = (String) getParameter(THRESHOLD_PARAM);
        m_threshold = 0;
        if (!StringUtils.isEmpty(thresholdStr) && StringUtils.isNumeric(thresholdStr))
        {
            m_threshold = Integer.parseInt(thresholdStr);
        }

        /*
         * Build student criteria: active students in school context with user query filters
         */
        StudentContextReportHelper helper =
                new StudentContextReportHelper(getOrganization(), m_context, getBroker());

        m_studentCriteria = new X2Criteria();

        if (isSchoolContext())
        {
            m_studentCriteria.addEqualTo(helper.getSchoolOidField(), getSchool().getOid());
        }
        else
        {
            m_studentCriteria.addAndCriteria(getOrganizationCriteria(SisStudent.class));
        }

        m_studentCriteria.addAndCriteria(helper.getActiveStudentCriteria());

        String queryBy = (String) getParameter(QUERY_BY_PARAM);
        if (queryBy != null)
        {
            queryBy = queryBy.replace("student" + PATH_DELIMITER, "");
        }
        addUserCriteria(m_studentCriteria,
                queryBy,
                (String) getParameter(QUERY_STRING_PARAM),
                SisStudent.class,
                X2BaseBean.COL_OID);

        /*
         * CSV properties
         */
        setIncludeHeaderRow(true);
        setValueDelimiter(',');
        setValueWrapper('"');

        m_columnNames = new ArrayList<String>(8);
        m_columnNames.add(COL_STUDENT_NAME);
        m_columnNames.add(COL_LASID);
        m_columnNames.add(COL_FULL_ABSENCES);
        m_columnNames.add(COL_UNEXCUSED_TARDIES);
        m_columnNames.add(COL_TARDY_EQUIVALENT);
        m_columnNames.add(COL_UNEXCUSED_DISMISSALS);
        m_columnNames.add(COL_DISMISSAL_EQUIVALENT);
        m_columnNames.add(COL_TOTAL);

        m_columnUserNames = new ArrayList<String>(m_columnNames);
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#saveState(UserDataContainer)
     */
    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException
    {
        super.saveState(userData);
        runOnApplicationServer();
    }

    /**
     * Resolves the start and end dates for the selected grade term by querying
     * GradeTermDate records linked to the selected GradeTerm.
     *
     * Each GradeTerm (Q1, Q2, Q3, Q4) has associated GradeTermDate records
     * with start/end dates configured in Aspen's schedule term detail screen.
     * For YR or if no dates are found, falls back to the school year context dates.
     */
    private void resolveTermDates()
    {
        if (m_context == null)
        {
            return;
        }

        /*
         * No grade term selected — use full school year dates (YR equivalent)
         */
        if (m_gradeTerm == null)
        {
            m_startDate = m_context.getStartDate();
            m_endDate = m_context.getEndDate();
            return;
        }

        /*
         * Query GradeTermDate records for the selected grade term, scoped to
         * the selected school year. GradeTermDate records exist for every year,
         * so we filter to only those whose dates fall within the context year.
         */
        X2Criteria dateCriteria = new X2Criteria();
        dateCriteria.addEqualTo(GradeTermDate.COL_GRADE_TERM_OID, m_gradeTerm.getOid());
        dateCriteria.addGreaterOrEqualThan(GradeTermDate.COL_START_DATE, m_context.getStartDate());
        dateCriteria.addLessOrEqualThan(GradeTermDate.COL_END_DATE, m_context.getEndDate());

        QueryByCriteria dateQuery = new QueryByCriteria(GradeTermDate.class, dateCriteria);
        Collection<GradeTermDate> termDates = getBroker().getCollectionByQuery(dateQuery);

        for (GradeTermDate termDate : termDates)
        {
            PlainDate start = termDate.getStartDate();
            PlainDate end = termDate.getEndDate();

            if (start != null && (m_startDate == null || start.before(m_startDate)))
            {
                m_startDate = start;
            }
            if (end != null && (m_endDate == null || end.after(m_endDate)))
            {
                m_endDate = end;
            }
        }

        /*
         * Fallback to context dates if no GradeTermDate records found (e.g., YR)
         */
        if (m_startDate == null || m_endDate == null)
        {
            m_startDate = m_context.getStartDate();
            m_endDate = m_context.getEndDate();
        }
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getColumnNames()
     */
    @Override
    protected List getColumnNames()
    {
        return m_columnNames;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getColumnUserNames()
     */
    @Override
    protected List getColumnUserNames()
    {
        return m_columnUserNames;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getComment()
     */
    @Override
    protected String getComment()
    {
        return null;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getHeader()
     */
    @Override
    protected String getHeader()
    {
        return null;
    }

    /**
     * Returns a custom file name with .csv extension.
     *
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getCustomFileName()
     */
    @Override
    public String getCustomFileName()
    {
        return "AttendancePolicyExport.csv";
    }
}
