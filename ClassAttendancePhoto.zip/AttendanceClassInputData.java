/*
 * ====================================================================
 *
 * X2 Development Corporation
 *
 * Copyright (c) 2002-2003 X2 Development Corporation.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, is not permitted without express written agreement
 * from X2 Development Corporation.
 *
 * ====================================================================
 */

// Created by Andrew Bullock

import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
import com.follett.fsc.core.framework.persistence.SubQuery;
import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.X2BaseBean;
import com.follett.fsc.core.k12.tools.reports.QueryIteratorDataSource;
import com.follett.fsc.core.k12.tools.reports.ReportJavaSourceNet;
import com.follett.fsc.core.k12.web.ApplicationContext;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.MasterSchedule;
import com.x2dev.sis.model.beans.ScheduleTeacher;
import com.x2dev.sis.model.beans.SisStaff;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.StudentSchedule;
import com.x2dev.sis.tools.reports.ScheduleReportHelper;
import com.x2dev.utils.DateUtils;
import com.x2dev.utils.types.PlainDate;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.ojb.broker.query.QueryByCriteria;

/**
 * Prepares the data for the "Class Attendance List With Large Photos" report.
 * Lists students grouped by class section (StudentSchedule/MasterSchedule), scoped to
 * the currently selected class when run from Staff View -> Attendance -> Class tab.
 *
 * @author X2 Development Corporation
 */
public class AttendanceClassInputData extends ReportJavaSourceNet {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Name for the start date report parameter. The value is a PlainDate.
     */
    public static final String START_DATE_PARAM = "startDate";

    /**
     * Name for the "query by" report parameter (admin/school view only). Integer.
     * 0 = All, 1 = Teacher name, 2 = Course name, 3 = Current selection.
     */
    public static final String QUERY_BY_PARAM = "queryBy";

    /**
     * Name for the "query string" report parameter. String.
     */
    public static final String QUERY_STRING_PARAM = "queryString";

    /**
     * Name for the section info report parameter displayed in the page header. String.
     */
    public static final String SECTION_INFO_PARAM = "sectionInfo";

    private ScheduleReportHelper m_reportHelper;
    private String m_teacherOid;
    private String m_sectionOid;

    /**
     * Gather data.
     *
     * @return JRDataSource
     * @see com.follett.fsc.core.k12.tools.reports.ReportJavaSourceDori#gatherData()
     */
    @Override
    protected JRDataSource gatherData() {
        /*
         * Reset the start date to Monday and set it as a report parameter.
         */
        PlainDate startDate = DateUtils.getStartOfWeek((PlainDate) getParameter(START_DATE_PARAM));
        addParameter(START_DATE_PARAM, startDate);

        /*
         * Build a section info string for the page header (e.g. "Math 101 - Sec. 2 | Smith, John").
         * Only populated when scoped to a single section (staff view with selected class).
         */
        if (m_sectionOid != null) {
            MasterSchedule section = getBroker().getBeanByOid(MasterSchedule.class, m_sectionOid);
            if (section != null) {
                String info = section.getCourseView() != null ? section.getCourseView() : "";
                String sectionNumber = section.getSectionNumber();
                if (sectionNumber != null && sectionNumber.length() > 0) {
                    info += "  \u2014  Sec. " + sectionNumber;
                }
                SisStaff primaryStaff = section.getPrimaryStaff();
                if (primaryStaff != null && primaryStaff.getNameView() != null) {
                    info += "  |  " + primaryStaff.getNameView();
                }
                addParameter(SECTION_INFO_PARAM, info);
            }
        }

        X2Criteria criteria = new X2Criteria();

        if (m_teacherOid != null) {
            /*
             * Staff view: scope to the specific section the teacher currently has open.
             * m_sectionOid is captured from userData.getCurrentRecord(ScheduleTeacher.class)
             * in saveState — this is the teacher-section record for the class currently selected.
             */
            if (m_sectionOid != null) {
                criteria.addEqualTo(
                        "section" + PATH_DELIMITER + X2BaseBean.COL_OID,
                        m_sectionOid);
            } else {
                /*
                 * Fallback: show all sections for this teacher in the current schedule,
                 * using a ScheduleTeacher subquery (same pattern as ClassAttendanceHistoryData).
                 */
                X2Criteria subQueryCriteria = new X2Criteria();
                subQueryCriteria.addEqualTo(ScheduleTeacher.COL_STAFF_OID, m_teacherOid);
                subQueryCriteria.addEqualTo(
                        ScheduleTeacher.REL_SECTION + PATH_DELIMITER + MasterSchedule.COL_SCHEDULE_OID,
                        m_reportHelper.getScheduleOid());
                SubQuery subQuery = new SubQuery(
                        ScheduleTeacher.class, ScheduleTeacher.COL_SECTION_OID, subQueryCriteria);
                criteria.addIn(
                        "section" + PATH_DELIMITER + X2BaseBean.COL_OID,
                        subQuery);
            }
        } else {
            /*
             * School / admin view: always scope to the current schedule, then apply
             * the queryBy filter from the input form.
             */
            criteria.addEqualTo(
                    "section" + PATH_DELIMITER + MasterSchedule.COL_SCHEDULE_OID,
                    m_reportHelper.getScheduleOid());

            int queryBy = getParameter(QUERY_BY_PARAM) == null ? 0
                    : ((Integer) getParameter(QUERY_BY_PARAM)).intValue();

            switch (queryBy) {
                case 1: // Teacher name
                    criteria.addContainsIgnoreCase(
                            "section" + PATH_DELIMITER +
                                    "primaryStaff" + PATH_DELIMITER +
                                    SisStaff.COL_NAME_VIEW,
                            getParameter(QUERY_STRING_PARAM));
                    break;

                case 2: // Course name
                    criteria.addContainsIgnoreCase(
                            "section" + PATH_DELIMITER + "courseView",
                            getParameter(QUERY_STRING_PARAM));
                    break;

                case 3: // Current selection — criteria scoped to selected MasterSchedule(s)
                    SubQuery sectionSubQuery = new SubQuery(
                            MasterSchedule.class, X2BaseBean.COL_OID, getCurrentCriteria());
                    criteria.addIn("masterScheduleOid", sectionSubQuery);
                    break;

                default: // All
                    break;
            }
        }

        QueryByCriteria query = new QueryByCriteria(StudentSchedule.class, criteria);
        query.addOrderByAscending("section" + PATH_DELIMITER + "courseView");
        query.addOrderByAscending("section" + PATH_DELIMITER + "sectionNumber");
        query.addOrderByAscending("student" + PATH_DELIMITER + SisStudent.COL_NAME_VIEW);

        return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
    }

    /**
     * Save state.
     *
     * @param userData UserDataContainer
     * @see com.follett.fsc.core.k12.tools.ToolJavaSource#saveState(com.follett.fsc.core.k12.web.
     *      UserDataContainer)
     */
    @Override
    protected void saveState(UserDataContainer userData) {
        if (userData.getSessionNavConfig() != null &&
                ApplicationContext.STAFF.equals(
                        userData.getSessionNavConfig().getApplicationContext())) {
            m_teacherOid = userData.getStaffOid();

            /*
             * The current record in attendance.period.classes.input is a ScheduleTeacher bean
             * (the teacher-section assignment). Call getSection() to get the MasterSchedule.
             * This is the same pattern used by ClassAttendanceHistoryData.
             */
            ScheduleTeacher currentTeacherSection = userData.getCurrentRecord(ScheduleTeacher.class);
            if (currentTeacherSection != null) {
                m_sectionOid = currentTeacherSection.getSection().getOid();
            }
        }

        m_reportHelper = new ScheduleReportHelper(userData);
    }
}
