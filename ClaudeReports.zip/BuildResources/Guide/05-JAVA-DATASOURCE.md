# Aspen Report Generation — Java Data Source Development

---

## Basic Class Structure
```java
public class ReportNameData extends ReportJavaSourceNet {
    private static final long serialVersionUID = 1L;

    // Parameter constants
    public static final String QUERY_BY_PARAM = "queryBy";
    public static final String QUERY_STRING_PARAM = "queryString";
    public static final String SORT_PARAM = "sort";

    private ScheduleReportHelper m_reportHelper;
    private String m_teacherOid;

    @Override
    protected JRDataSource gatherData() throws Exception {
        // Implementation
    }

    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException {
        // Initialization
    }
}
```

---

## Advanced Report Structure (Section 504 Plan Example)
```java
public class Section504PlanData extends ReportJavaSourceNet {
    private static final long serialVersionUID = 1L;

    // Subreport constants
    public static final String EVALUATION_SUBREPORT_ID = "SYS-STD-021-EVAL";
    public static final String ACCOMMODATION_SUBREPORT_ID = "SYS-STD-021-ACC";
    public static final String ACCOMMODATION_CATEGORIES_SUBREPORT_ID = "SYS-STD-021-ACC-CAT";

    // Reference table constants
    public static final String CATEGORY_REFERENCE_TABLE_OID = "rtb504AccCat";

    // Parameter constants for complex data
    public static final String PARAM_DISABILITIES = "disabilities";
    public static final String PARAM_PARTICIPANTS = "participants";
    public static final String PARAM_ACCOMMODATIONS_BY_CATEGORY = "accByCat";
    public static final String PARAM_HAS_ACCOMMODATIONS_IN_TABLE = "hasAccommodationsInTable";

    // Subreport format parameters
    public static final String PARAM_EVALUATION_SUBREPORT_FORMAT = "evalFormat";
    public static final String PARAM_ACCOMMODATION_SUBREPORT_FORMAT = "accFormat";
    public static final String PARAM_ACCOMMODATION_CATEGORIES_SUBREPORT_FORMAT = "accCatFormat";

    private StudentEdPlan m_504Plan = null;

    @Override
    protected JRDataSource gatherData() throws Exception {
        DataDictionary dictionary = DataDictionary.getDistrictDictionary(
            getExtendedDictionary(), getBroker().getPersistenceKey());

        // Build complex parameter strings
        buildDisabilitiesParameter();
        buildParticipantsParameter();

        // Setup subreports
        setupEvaluationSubreport(dictionary);
        setupAccommodationSubreports(dictionary);

        // Return single-record data source
        return new SimpleBeanDataSource(m_504Plan, dictionary, getLocale());
    }

    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException {
        super.saveState(userData);
        m_504Plan = userData.getCurrentRecord(StudentEdPlan.class);
    }
}
```

---

## Data Gathering Pattern
```java
@Override
protected JRDataSource gatherData() {
    X2Criteria criteria = new X2Criteria();

    // Base criteria
    criteria.addEqualTo(StudentSection.COL_SCHEDULE_OID, m_reportHelper.getScheduleOid());

    // Security filtering
    if (!StringUtils.isEmpty(m_teacherOid)) {
        criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER +
                Section.COL_PRIMARY_STAFF_OID, m_teacherOid);
    }

    // Parameter-based filtering
    int queryBy = ((Integer) getParameter(QUERY_BY_PARAM)).intValue();
    switch (queryBy) {
        case 1: // Term code
            criteria.addEqualTo(/* term criteria */);
            break;
        case 2: // Course number
            criteria.addEqualTo(/* course criteria */);
            break;
        // Additional cases
    }

    // Build and execute query
    QueryByCriteria query = new QueryByCriteria(StudentSection.class, criteria);
    applyUserSort(query, (String) getParameter(SORT_PARAM));

    return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
}
```

---

## State Management
```java
@Override
protected void saveState(UserDataContainer userData) throws X2BaseException {
    // Check user context for security
    if (userData.getSessionNavConfig().getApplicationContext().equals(ApplicationContext.STAFF)) {
        m_teacherOid = userData.getStaffOid();
    }

    // Initialize report helper
    m_reportHelper = new ScheduleReportHelper(userData);
}
```

---

## Advanced Data Source Patterns

### 1. Single Record Reports (Forms/Documents)
```java
// Used for detailed individual records like Section 504 Plans
@Override
protected JRDataSource gatherData() throws Exception {
    StudentEdPlan plan = userData.getCurrentRecord(StudentEdPlan.class);
    return new SimpleBeanDataSource(plan, dictionary, getLocale());
}
```

### 2. Collection-Based Reports (Lists)
```java
// Used for multiple records like class lists
@Override
protected JRDataSource gatherData() throws Exception {
    QueryByCriteria query = new QueryByCriteria(StudentSection.class, criteria);
    return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
}
```

### 3. Hierarchical Reports with Subreports
```java
// Complex reports with embedded subreports
private void setupSubreports(DataDictionary dictionary) throws Exception {
    // Load subreport format
    Report subreport = ReportUtils.getReport(SUBREPORT_ID, getBroker());
    addParameter(PARAM_SUBREPORT_FORMAT,
                new ByteArrayInputStream(subreport.getCompiledFormat()));

    // Create data source for subreport
    Collection<Object> subreportData = mainRecord.getRelatedData(getBroker());
    addParameter(PARAM_SUBREPORT_DATA,
                new BeanCollectionDataSource(subreportData, dictionary, getLocale()));
}
```

### 4. Reference Code Integration
```java
// Working with reference tables and lookup codes
private Collection<ReferenceCode> getReferenceCategories() {
    Criteria refCodeCriteria = ReferenceManager.getCodesCriteria(
        REFERENCE_TABLE_OID,
        getOwnableCriteria(),
        true, true, false,
        getBroker().getPersistenceKey());

    QueryByCriteria query = new QueryByCriteria(ReferenceCode.class, refCodeCriteria);
    query.addOrderBy(ReferenceCode.COL_SEQUENCE_NUMBER, true);
    return getBroker().getCollectionByQuery(query);
}
```

### 5. Complex Parameter Building
```java
// Building comma-separated parameter strings
private void buildParticipantsParameter() {
    StudentEdPlanMeeting lastMeeting = m_504Plan.getLastMeeting(getBroker());
    if (lastMeeting != null) {
        StringBuilder participantString = new StringBuilder(128);

        Collection<StudentEdPlanMeetingParticipant> participants =
                lastMeeting.getStudentEdPlanMeetingParticipants(getBroker());
        for (StudentEdPlanMeetingParticipant participant : participants) {
            if (participantString.length() > 0) {
                participantString.append(", ");
            }
            participantString.append(participant.getNameView());
            if (!StringUtils.isEmpty(participant.getRoleCode())) {
                participantString.append(" - ");
                participantString.append(participant.getRoleCode());
            }
        }
        addParameter(PARAM_PARTICIPANTS, participantString.toString());
    }
}
```

### 6. Data Categorization and Grouping
```java
// Creating categorized data maps for complex reports
private Map<String, Collection<IepAccommodation>> categorizeAccommodations(
        Collection<ReferenceCode> categories, Collection<IepAccommodation> accommodations) {

    Map<String, Collection<IepAccommodation>> accommodationsByCat =
            new HashMap<String, Collection<IepAccommodation>>();

    // Initialize empty collections for each category
    for (ReferenceCode category : categories) {
        accommodationsByCat.put(category.getCode(), new ArrayList<IepAccommodation>());
    }

    // Assign accommodations to categories
    for (IepAccommodation accommodation : accommodations) {
        Collection<IepAccommodation> categoryAccommodations =
            accommodationsByCat.get(accommodation.getCategory());
        if (categoryAccommodations != null) {
            categoryAccommodations.add(accommodation);
        }
    }

    return accommodationsByCat;
}
```

### 7. Advanced IEP Form Patterns (Level 4: Enterprise Forms)
```java
// Multi-engine JasperReports support
public class IepForm23Data extends MaBeanReport {
    // Custom data source with broker access
    public class GoalDataSource extends BeanCollectionDataSource {
        private X2Broker m_bbroker;

        @Override
        protected Object getFieldValue(String fieldName) throws X2BaseException {
            if ("objectivesView".equals(fieldName)) {
                return ((IepGoal) getCurrentBean()).getObjectivesView(m_bbroker);
            }
            return super.getFieldValue(fieldName);
        }
    }

    // Multi-engine data source creation
    private Object getMappedCollectionDataSource(List list) {
        Report report = (Report) getJob().getTool();
        if (Report.REPORT_ENGINE_5_RELEASE.equals(report.getEngineVersion())) {
            return new net.sf.jasperreports5.engine.data.JRMapCollectionDataSource(list);
        } else if (Report.REPORT_ENGINE_6_RELEASE.equals(report.getEngineVersion())) {
            return new net.sf.jasperreports6.engine.data.JRMapCollectionDataSource(list);
        }
        return null;
    }

    // Multi-engine subreport format loading
    private Object getSubreportFormat(String formatId) {
        Report report = ReportUtils.getReport(formatId, getBroker());
        byte[] compiledFormat = report.getCompiledFormat();
        if (Report.REPORT_ENGINE_5_RELEASE.equals(report.getEngineVersion())) {
            return net.sf.jasperreports5.engine.util.JRLoader.loadObject(
                new ByteArrayInputStream(compiledFormat));
        } else if (Report.REPORT_ENGINE_6_RELEASE.equals(report.getEngineVersion())) {
            return net.sf.jasperreports6.engine.util.JRLoader.loadObject(
                new ByteArrayInputStream(compiledFormat));
        }
        return null;
    }
}
```

### 8. Document Saving and Export Functionality
```java
// Override publishResults for document saving
@Override
protected void publishResults() throws Exception {
    boolean saveToDocuments = getParameter("saveToDocumentsIEP") != null &&
            ((Boolean) getParameter("saveToDocumentsIEP")).booleanValue();

    ResultHandler resultHandler = getJob().getResultHandler();
    OutputStream pdfOutputStream = resultHandler.getOutputStream();

    if (saveToDocuments) {
        pdfOutputStream = prepareSaveToDocuments(pdfOutputStream);
    }

    // Generate report with engine-specific handling
    Report report = (Report) getJob().getTool();
    if (Report.REPORT_ENGINE_5_RELEASE.equals(report.getEngineVersion())) {
        exportResults5(reportPrint, getJob(), pdfOutputStream);
    } else if (Report.REPORT_ENGINE_6_RELEASE.equals(report.getEngineVersion())) {
        exportResults6(reportPrint, getJob(), pdfOutputStream);
    }

    if (saveToDocuments) {
        saveToDocuments(pdfOutputStream);
    }
}
```

---

## End-to-End Field Mapping: Java → JRXML

A complete traced example showing how data flows from Java data source to JRXML rendering:

**1. Java Data Source** — query returns `SisStudent` beans:
```java
QueryByCriteria query = new QueryByCriteria(SisStudent.class, criteria);
return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
```

**2. JRXML Field Declarations** — dot notation maps to getter methods on the bean:
```xml
<field name="nameView" class="java.lang.String"/>       <!-- → SisStudent.getNameView() -->
<field name="yog" class="java.lang.Integer"/>            <!-- → SisStudent.getYog() -->
<field name="localId" class="java.lang.String"/>         <!-- → SisStudent.getLocalId() -->
<field name="person.firstName" class="java.lang.String"/><!-- → SisStudent.getPerson().getFirstName() -->
```

**3. JRXML Expressions** — reference fields with `$F{...}`:
```xml
<textFieldExpression><![CDATA[$F{nameView}]]></textFieldExpression>
<textFieldExpression><![CDATA["Yr: " + $F{yog}]]></textFieldExpression>
<textFieldExpression><![CDATA[$F{person.firstName} != null ? $F{person.firstName} : ""]]></textFieldExpression>
```

**Key rule:** The `<field name="...">` must match the JavaBean property path starting from the bean type returned by the data source. `QueryIteratorDataSource` wrapping `SisStudent` means fields start from `SisStudent`'s properties.

> See `04-JRXML-FORMAT.md § Field Definition Best Practices` for more field patterns.

---

## Common Report Patterns by Purpose

> For complexity level definitions (Levels 1-4), see `00-AI-WORKFLOW.md`.

### Data Source Selection Guide

| Report Type | Primary Data Source | When to Use |
|-------------|-------------------|-------------|
| **QueryIteratorDataSource** | Multiple records from database query | Class lists, attendance reports, bulk data reports |
| **SimpleBeanDataSource** | Single record/object | Individual forms, detailed records, current record reports |
| **BeanCollectionDataSource** | Collection of objects | Subreports, categorized data, related record lists |

### 1. Class List Reports (Level 1)
- **Purpose**: Display students enrolled in sections
- **Key Tables**: STUDENT_SECTION, SECTION, STUDENT
- **Common Fields**: Student name, course, teacher, schedule
- **Grouping**: By section/course
- **Data Source**: QueryIteratorDataSource

### 2. Attendance Reports (Level 1-2)
- **Purpose**: Track student attendance patterns
- **Key Tables**: STUDENT_ATTENDANCE, STUDENT, SECTION
- **Common Fields**: Date, attendance code, student info
- **Filtering**: Date ranges, attendance types
- **Data Source**: QueryIteratorDataSource or BeanCollectionDataSource

### 3. Grade Reports (Level 2)
- **Purpose**: Display academic performance
- **Key Tables**: STUDENT_TRANSCRIPT, STUDENT, SECTION
- **Common Fields**: Grades, credits, GPA calculations
- **Grouping**: By term, student, or course
- **Data Source**: Mixed (main + subreports)

### 4. Staff Reports (Level 1-2)
- **Purpose**: Staff scheduling and assignments
- **Key Tables**: STAFF, SECTION, SCHEDULE
- **Common Fields**: Staff name, assignments, schedules
- **Filtering**: Department, position type
- **Data Source**: QueryIteratorDataSource

### 5. Special Education Reports (Level 3)
- **Purpose**: Generate formal accommodation plans and compliance documents
- **Key Tables**: STUDENT_ED_PLAN, IEP_ACCOMMODATION, IEP_DISABILITY, STUDENT_ED_PLAN_MEETING
- **Common Fields**: Student info, disabilities, accommodations, meeting participants, dates
- **Features**: Complex subreports, parameter-driven content, formal document formatting
- **Data Source**: SimpleBeanDataSource + multiple BeanCollectionDataSource subreports

---

## Report Layout Patterns

### 1. Tabular Layout (Lists)
```xml
<detail>
    <band height="16">
        <textField>
            <reportElement x="99" y="2" width="164" height="12"/>
            <textFieldExpression><![CDATA[$F{student}.getNameView()]]></textFieldExpression>
        </textField>
    </band>
</detail>
```

### 2. Form Layout (Documents)
```xml
<detail>
    <band height="208">
        <rectangle>
            <reportElement x="6" y="3" width="529" height="141"/>
        </rectangle>
        <staticText><text><![CDATA[Name:]]></text></staticText>
        <textField><textFieldExpression><![CDATA[$F{student.nameView}]]></textFieldExpression></textField>
    </band>
</detail>
```

### 3. Sectioned Layout (Complex Reports)
```xml
<group name="section1">
    <groupFooter>
        <band height="62">
            <staticText><text><![CDATA[Accommodations]]></text></staticText>
            <subreport>
                <dataSourceExpression><![CDATA[$P{accommodationData}]]></dataSourceExpression>
            </subreport>
        </band>
    </groupFooter>
</group>
```

---

## Attendance & Date Patterns

### Snapping a Date to Monday
Use `DateUtils.getStartOfWeek()` to normalize any user-provided start date to the Monday of that week. This is the standard pattern for weekly attendance input sheets:
```java
import com.x2dev.utils.DateUtils;
import com.x2dev.utils.types.PlainDate;

PlainDate startDate = DateUtils.getStartOfWeek((PlainDate) getParameter(START_DATE_PARAM));
addParameter(START_DATE_PARAM, startDate); // overwrite with snapped value
```
**Note on date types**: Use `PlainDate` in Java source for date parameters. The JRXML parameter should declare it as `java.util.Date` — Aspen handles the conversion.

### Overwriting Input Parameters
You can call `addParameter()` with the same name as an input parameter to replace its value before the JRXML renders. This is how the Monday-snap works: the user selects any date, the Java source resets it to Monday, and the JRXML sees the corrected value.

---

## School vs District Scoping

Use the built-in helper methods to scope queries correctly depending on whether the report is running in school or district context:
```java
if (isSchoolContext()) {
    // Running for a single school — filter by school OID
    criteria.addEqualTo(schoolYearHelper.getSchoolOidField(), getSchool().getOid());
} else {
    // Running district-wide — filter by organization
    criteria.addAndCriteria(getOrganizationCriteria(SisStudent.class));
}
```

### StudentContextReportHelper
`StudentContextReportHelper` resolves field paths in a context-aware, school-year-aware way. Use it for student list queries that need to be portable across school and district contexts:
```java
import com.x2dev.sis.tools.reports.StudentContextReportHelper;

StudentContextReportHelper schoolYearHelper =
    new StudentContextReportHelper(getOrganization(), getCurrentContext(), getBroker());

// Context-aware field accessors
criteria.addEqualTo(schoolYearHelper.getSchoolOidField(), getSchool().getOid());
criteria.addAndCriteria(schoolYearHelper.getActiveStudentCriteria());
criteria.addNotEmpty(schoolYearHelper.getHomeroomField(), getBroker().getPersistenceKey());

// Use the same field for ordering
query.addOrderByAscending(schoolYearHelper.getSchoolOidField());
query.addOrderByAscending(schoolYearHelper.getHomeroomField());
```

---

## Homeroom Reports

### Building the Homeroom-to-Staff Map
`ReportUtils.buildHomeroomToStaffMap()` queries all staff with homeroom assignments and returns a `Map<String, SisStaff>` keyed by homeroom code. Pass it as a parameter so the JRXML can look up the teacher name for each homeroom group:
```java
import com.follett.fsc.core.k12.tools.reports.ReportUtils;

X2Criteria staffCriteria = new X2Criteria();
// optionally scope to specific staff...

Map homeroomToStaff = ReportUtils.buildHomeroomToStaffMap(
    getBroker(), staffCriteria,
    getOrganization(),
    isSchoolContext() ? getSchool() : null);
addParameter(HOMEROOM_TO_STAFF_MAP, homeroomToStaff);
```

In the JRXML, look up the teacher name by homeroom key:
```xml
<textFieldExpression><![CDATA["Teacher: " +
    ($P{homeroomToStaffMap}.containsKey($V{homeroom})
        ? ((com.x2dev.sis.model.beans.SisStaff) $P{homeroomToStaffMap}.get($V{homeroom})).getNameView()
        : "")]]>
</textFieldExpression>
```

### Preventing All-Rows Match on Empty Filter
When a filter collection is empty (e.g., no homerooms matched the staff criteria), use `addNoMatchCriteria()` to return zero rows instead of all rows:
```java
if (!homeroomToStaff.isEmpty()) {
    criteria.addIn(schoolYearHelper.getHomeroomField(), homeroomToStaff.keySet());
} else {
    addNoMatchCriteria(criteria); // returns empty result set
}
```

---

## Fuzzy Text Filtering

Use `addContainsIgnoreCase()` for case-insensitive partial text search:
```java
// Teacher name search
criteria.addContainsIgnoreCase(
    "section" + PATH_DELIMITER + "primaryStaff" + PATH_DELIMITER + SisStaff.COL_NAME_VIEW,
    getParameter(QUERY_STRING_PARAM));

// Course name search
criteria.addContainsIgnoreCase(
    "section" + PATH_DELIMITER + "courseView",
    getParameter(QUERY_STRING_PARAM));
```

Use `addOrEqualTo()` to match either of two fields on the same bean (e.g., homeroom OR homeroom2):
```java
staffCriteria.addEqualTo(SisStaff.COL_HOMEROOM, getParameter(QUERY_STRING_PARAM));
staffCriteria.addOrEqualTo(SisStaff.COL_HOMEROOM2, getParameter(QUERY_STRING_PARAM));
```

---

## Current Selection Queries

Use `getCurrentCriteria()` to scope a query to whatever records the user has selected in the Aspen UI:
```java
case 3: // Current Selection
    SubQuery sectionSubQuery = new SubQuery(
        MasterSchedule.class, X2BaseBean.COL_OID, getCurrentCriteria());
    criteria.addIn("masterScheduleOid", sectionSubQuery);
    break;
```
For homeroom reports, `getCurrentCriteria()` can be assigned directly as the staff criteria:
```java
case 3:
    staffCriteria = getCurrentCriteria();
    break;
```

---

## Building a Computed Header String

For reports that need to display context-specific header info (e.g., class name + section + teacher), build the string in Java and inject it as a parameter rather than computing it in JRXML:
```java
if (m_sectionOid != null) {
    MasterSchedule section = getBroker().getBeanByOid(MasterSchedule.class, m_sectionOid);
    if (section != null) {
        String info = section.getCourseView() != null ? section.getCourseView() : "";
        if (section.getSectionNumber() != null && section.getSectionNumber().length() > 0) {
            info += "  \u2014  Sec. " + section.getSectionNumber(); // em dash
        }
        SisStaff staff = section.getPrimaryStaff();
        if (staff != null) {
            info += "  |  " + staff.getNameView();
        }
        addParameter(SECTION_INFO_PARAM, info);
    }
}
```

---

## Null-Safe ApplicationContext Check

Always guard the `getSessionNavConfig()` call — it can return `null` in some contexts:
```java
if (userData.getSessionNavConfig() != null &&
        ApplicationContext.STAFF.equals(
                userData.getSessionNavConfig().getApplicationContext())) {
    m_teacherOid = userData.getStaffOid();
    // ...
}
```

---

## OJB Criteria vs Raw SQL

Aspen supports two approaches for querying data. Use OJB criteria (shown throughout this guide) as the default; use raw SQL only when OJB cannot express the query.

### OJB Criteria (preferred)
Uses `X2Criteria` + `QueryByCriteria` with Aspen's object model. Provides type safety, automatic relationship traversal, and works with `QueryIteratorDataSource`.

```java
X2Criteria criteria = new X2Criteria();
criteria.addEqualTo(SisStudent.COL_ENROLLMENT_STATUS, "Active");
QueryByCriteria query = new QueryByCriteria(SisStudent.class, criteria);
return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
```

### Raw SQL (when needed)
Use `connection.prepareStatement()` for complex joins, aggregations, or queries that don't map cleanly to OJB criteria. Access the connection via `getBroker().borrowConnection()`:

```java
Connection connection = getBroker().borrowConnection();
try {
    String sql = "SELECT s.STD_NAME_VIEW, s.STD_YOG, s.STD_ID_LOCAL " +
                 "FROM STUDENT s " +
                 "WHERE s.STD_ENROLLMENT_STATUS = ? AND s.STD_SKL_OID = ?";
    PreparedStatement statement = connection.prepareStatement(sql);
    statement.setString(1, "Active");
    statement.setString(2, getSchool().getOid());
    ResultSet results = statement.executeQuery();
    // Process results into a ReportDataGrid or SimpleFormDataSource
} finally {
    getBroker().returnConnection();
}
```

**When to use raw SQL:**
- Complex multi-table joins with aggregation (COUNT, SUM, GROUP BY)
- UNION queries across different bean types
- Performance-critical queries where OJB generates inefficient SQL
- Queries involving database views or stored procedures

> See `04-JRXML-FORMAT.md` for connecting Java data source output to JRXML fields. See `08-QUICK-REFERENCE.md` for common import blocks.

---

## CSV Export Data Source (ExportJavaSource)

For CSV/delimited file exports (no JRXML needed), extend `ExportJavaSource` instead of `ReportJavaSourceNet`.

> See `01-ARCHITECTURE.md § Exports (CSV) vs Reports (PDF)` for the full comparison.

### ExportJavaSource Structure

```java
public class MyExportData extends ExportJavaSource {
    private static final long serialVersionUID = 1L;

    private List<String> m_columnNames;
    private List<String> m_columnUserNames;

    @Override
    protected DataGrid gatherData() {
        ReportDataGrid grid = new ReportDataGrid();

        // Query data and build rows
        for (SisStudent student : students) {
            grid.append();
            grid.set("StudentName", student.getNameView());
            grid.set("LASID", student.getLocalId());
        }

        grid.beforeTop();
        grid.sort(Arrays.asList("StudentName"), false);
        return grid;
    }

    @Override
    protected void initialize() throws X2BaseException {
        super.initialize();
        setIncludeHeaderRow(true);

        m_columnNames = new ArrayList<String>();
        m_columnNames.add("StudentName");
        m_columnNames.add("LASID");

        m_columnUserNames = new ArrayList<String>(m_columnNames);
    }

    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException {
        super.saveState(userData);
        runOnApplicationServer(); // Run on app server for performance
    }

    @Override protected List getColumnNames()     { return m_columnNames; }
    @Override protected List getColumnUserNames() { return m_columnUserNames; }
    @Override protected String getComment()       { return null; }
    @Override protected String getHeader()        { return null; }
}
```

### Key Differences from ReportJavaSourceNet

| Method / Pattern | Report (PDF) | Export (CSV) |
|-----------------|-------------|--------------|
| `gatherData()` return type | `JRDataSource` | `DataGrid` |
| Row creation | Automatic from query iterator | Manual: `grid.append()` then `grid.set()` |
| Column definition | JRXML `<field>` elements | `getColumnNames()` / `getColumnUserNames()` |
| Header row | JRXML column headers | `setIncludeHeaderRow(true)` in `initialize()` |
| Sorting | JRXML group/sort bands or query ORDER BY | `grid.sort(columnList, ascending)` |
| Required overrides | `gatherData()`, `saveState()` | `gatherData()`, `initialize()`, `saveState()`, `getColumnNames()`, `getColumnUserNames()`, `getComment()`, `getHeader()` |
| Output | PDF via JRXML | Single file only — no ZIP or multi-file support |

### ExportJavaSource Limitations

- **Single file output only**: `gatherData()` returns one `DataGrid` → one file. No mechanism to output ZIP archives or multiple files per run.
- **`getCurrentContext()` returns null in district view**: If your export runs from District View → Tools → Exports, you must use a `contextOid` input parameter to load the school year context (see Troubleshooting #27).
- **Mode-selector pattern**: For exports that produce multiple file types (e.g., SkillsPlus with 4 modes), use a `<select>` input to let users choose the mode. Each run produces one file. Set up separate scheduled jobs for automation.

### Bundle Definition for Exports

Exports use `<exports>` / `<export-definition>` tags (not `<reports>` / `<report-definition>`), and require a `package` attribute:

```xml
<tool-bundle create-date="YYYY-MM-DD">
  <exports package="com.x2dev.reports.yourstate.yourdistrict">
    <export-definition id="CUST-XXX-YYY" name="My Export – CSV"
        category="Category" javasource-file="MyExportData.java"
        input-file="MyExportInput.xml" weight="1" schedulable="false"
        custom-java="true" custom-input="true" custom-xml="true">
      <node key="student.std.list" school-view="true" />
    </export-definition>
  </exports>
</tool-bundle>
```

The Java file must live inside the package directory structure (e.g., `com/x2dev/reports/yourstate/yourdistrict/MyExportData.java`).

---

## Resolving Grade Term Dates

When a report/export needs to filter data by grading period (Q1–Q4, YR), use `GradeTermDate` to resolve the actual date range. **Do not use `ScheduleTermDate`** — it stores the full schedule year range for all terms.

```java
import com.x2dev.sis.model.beans.GradeTerm;
import com.x2dev.sis.model.beans.GradeTermDate;

/**
 * Resolves start/end dates for a selected GradeTerm within a specific school year.
 *
 * GradeTermDate records exist across all school years, so we must scope
 * to the selected DistrictSchoolYearContext to get only the current year's dates.
 * Falls back to the full context year dates for YR or if no records found.
 */
private void resolveTermDates()
{
    if (m_gradeTerm == null || m_context == null)
    {
        return;
    }

    X2Criteria dateCriteria = new X2Criteria();
    dateCriteria.addEqualTo(GradeTermDate.COL_GRADE_TERM_OID, m_gradeTerm.getOid());
    dateCriteria.addGreaterOrEqualThan(GradeTermDate.COL_START_DATE, m_context.getStartDate());
    dateCriteria.addLessOrEqualThan(GradeTermDate.COL_END_DATE, m_context.getEndDate());

    QueryByCriteria dateQuery = new QueryByCriteria(GradeTermDate.class, dateCriteria);
    Collection<GradeTermDate> termDates = getBroker().getCollectionByQuery(dateQuery);

    for (GradeTermDate termDate : termDates)
    {
        PlainDate start = termDate.getStartDate();
        PlainDate end = termDate.getEndDate();

        if (start != null && (m_startDate == null || start.before(m_startDate)))
        {
            m_startDate = start;
        }
        if (end != null && (m_endDate == null || end.after(m_endDate)))
        {
            m_endDate = end;
        }
    }

    // Fallback to context dates if no GradeTermDate records found (e.g., YR)
    if (m_startDate == null || m_endDate == null)
    {
        m_startDate = m_context.getStartDate();
        m_endDate = m_context.getEndDate();
    }
}
```

**Handling "Full Year" with a checkbox override:**

The grade term picklist may not include a "YR" option (it depends on `GradeTermAssociation` records). Use a "Full Year" checkbox to let users bypass the picklist entirely:

```java
private static final String FULL_YEAR_PARAM = "fullYear";

// In initialize():
Boolean fullYear = (Boolean) getParameter(FULL_YEAR_PARAM);
if (fullYear == null || !fullYear.booleanValue())
{
    String gradeTermOid = (String) getParameter(GRADE_TERM_OID_PARAM);
    if (!StringUtils.isEmpty(gradeTermOid))
    {
        m_gradeTerm = (GradeTerm) getBroker().getBeanByOid(GradeTerm.class, gradeTermOid);
    }
}
// When fullYear is true, m_gradeTerm stays null → resolveTermDates() uses full context year
```

> See `03-INPUT-DEFINITION.md § Using a checkbox to disable/override another input` for the XML side.

**Common mistakes to avoid:**
- Do **not** use `ScheduleTermDate` — it stores the full year range (8/1–7/31) for all terms
- Do **not** call `GradeTerm.getGradeTermMap()` — that method only exists on `ScheduleTerm` and will cause `ClassNotFoundException`
- Always scope `GradeTermDate` queries to the selected school year context, or you'll get dates from all years
- Boolean parameters from checkboxes can be `null` — always null-check before calling `.booleanValue()`

> See `02-DATABASE-SCHEMA.md § Scheduling & Grading Period Tables` for the full table comparison and `07-TROUBLESHOOTING.md` (#24-25) for related issues.

---

## DataDictionary API — Accessing Field Metadata

To access field metadata programmatically (e.g., for schema exports), use a hybrid of `DataFieldConfig` (bean layer) and `DataDictionaryField` (business layer). These two objects split the metadata:

| Property | DataFieldConfig | DataDictionaryField |
|---|---|---|
| Field OID (`psnNameFirst`) | `getDataFieldOid()` ✓ | ✗ not available |
| User Long Name | `getUserLongName()` ✓ | `getUserLongName()` ✓ |
| User Short Name | `getUserShortName()` ✓ | `getUserShortName()` ✓ |
| Java Name (`firstName`) | ✗ not available | `getJavaName()` ✓ |
| Java Type | ✗ not available | `getEffectiveJavaType()` ✓ |
| Database Name (`PSN_NAME_FIRST`) | ✗ not available | `getDatabaseName()` ✓ |

**Pattern**: Query `DataFieldConfig` beans for iteration, then look up each `DataDictionaryField` by OID:

```java
DataDictionary dictionary = DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey());
// dictionary.findDataDictionaryTableByClass(className) — works
// dictionary.findDataDictionaryField(oid) — works

// DataDictionaryTable.getFields() / getFieldsMap() do NOT exist
// DataTableConfig OJB property "className" is NOT a valid DB column
```

> See `07-TROUBLESHOOTING.md` (#26) for the full verified API reference and working code example.

---

## SisAddress API — Verified Methods

When accessing student/person physical address fields:

```java
SisAddress address = person.getPhysicalAddress();
if (address != null) {
    String streetNo = String.valueOf(address.getStreetNumber());  // returns int, not String
    String streetName = address.getAddressLine01();                // correct method name
    String city = address.getCity();
    String state = address.getState();
    String zip = address.getPostalCode();
}
```

**Methods that do NOT exist**: `getStreetLine01()`, `getStreetLine1()` — use `getAddressLine01()` instead.

---

## X2Criteria — Methods That Do NOT Exist

- `addNotContains()` — use `addNotLike()` with SQL wildcards: `criteria.addNotLike(field, "%keyword%")`
- When filtering boolean-like custom fields that may store `"Y"`, `"TRUE"`, or `"1"`, build OR criteria to match all variants (see Troubleshooting #30)

---

## Multi-School Queries

To query data across multiple schools (e.g., primary school + satellite school):

```java
List<String> schoolOids = new ArrayList<String>();
schoolOids.add(getSchool().getOid());
// Add additional school OIDs as needed
schoolOids.add(otherSchool.getOid());

criteria.addIn(SisStudent.COL_SCHOOL_OID, schoolOids);
```

Look up a school by exact name:
```java
X2Criteria criteria = new X2Criteria();
criteria.addEqualTo(SisSchool.COL_NAME, "Exact School Name");
SisSchool school = (SisSchool) getBroker().getBeanByQuery(
        new QueryByCriteria(SisSchool.class, criteria));
```

---

## Required Imports
```java
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.SisPerson;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.StudentSection;
import com.x2dev.sis.model.beans.Section;

import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
// Fallback if static import unavailable:
// private static final String PATH_DELIMITER = ".";
```

## Key Classes and Packages
```java
// Core Aspen Classes
com.follett.fsc.core.k12.tools.reports.ReportJavaSourceNet
com.follett.fsc.core.k12.tools.reports.QueryIteratorDataSource
com.follett.fsc.core.k12.tools.reports.BeanCollectionDataSource
com.follett.fsc.core.k12.tools.reports.SimpleBeanDataSource
com.follett.fsc.core.k12.tools.reports.ReportUtils
com.follett.fsc.core.framework.persistence.X2Criteria
com.follett.fsc.core.framework.persistence.SubQuery
com.x2dev.sis.tools.reports.ScheduleReportHelper

// Reference Code Management
com.follett.fsc.core.k12.beans.ReferenceCode
com.follett.fsc.core.k12.beans.Report
com.follett.fsc.core.k12.business.admin.ReferenceManager
com.follett.fsc.core.k12.business.dictionary.DataDictionary

// Common Model Beans
com.x2dev.sis.model.beans.SisStudent
com.x2dev.sis.model.beans.SisPerson
com.x2dev.sis.model.beans.SisStaff
com.x2dev.sis.model.beans.SisSchool
com.x2dev.sis.model.beans.SisAddress
com.x2dev.sis.model.beans.Section
com.x2dev.sis.model.beans.StudentSection
com.x2dev.sis.model.beans.StudentAttendance
com.x2dev.sis.model.beans.SchoolRoom

// Special Education Model Beans
com.x2dev.sis.model.beans.StudentEdPlan
com.x2dev.sis.model.beans.StudentEdPlanMeeting
com.x2dev.sis.model.beans.StudentEdPlanMeetingParticipant
com.x2dev.sis.model.beans.IepAccommodation
com.x2dev.sis.model.beans.IepDisability
com.x2dev.sis.model.beans.IepData
com.x2dev.sis.model.beans.IepGoal
com.x2dev.sis.model.beans.IepService
com.x2dev.sis.model.beans.IepPlacement
com.x2dev.sis.model.beans.IepMeeting
com.x2dev.sis.model.beans.IepTeamMember

// Multi-Engine JasperReports Support
net.sf.jasperreports5.engine.JasperFillManager
net.sf.jasperreports5.engine.JRDataSource
net.sf.jasperreports5.engine.data.JRMapCollectionDataSource
net.sf.jasperreports5.engine.util.JRLoader
net.sf.jasperreports6.engine.JasperFillManager
net.sf.jasperreports6.engine.JRDataSource
net.sf.jasperreports6.engine.data.JRMapCollectionDataSource
net.sf.jasperreports6.engine.util.JRLoader

// Scheduling & Grading Period Beans
com.x2dev.sis.model.beans.GradeTerm
com.x2dev.sis.model.beans.GradeTermDate
com.x2dev.sis.model.beans.Schedule
com.x2dev.sis.model.beans.ScheduleTerm
com.x2dev.sis.model.beans.ScheduleTermDate
com.follett.fsc.core.k12.beans.DistrictSchoolYearContext

// Utilities
com.x2dev.utils.StringUtils
com.x2dev.utils.X2BaseException
com.follett.fsc.core.k12.web.AppGlobals
```
