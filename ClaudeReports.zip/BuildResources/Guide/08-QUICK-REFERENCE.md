# Aspen Report Generation — Quick Reference

The most-used patterns in one place. For full context, see the numbered guide files. For starter files, see `BuildResources/Templates/`.

---

## Photo Loading (confirmed working)

```xml
<image onErrorType="Blank">
    <reportElement x="3" y="2" width="65" height="70"/>
    <imageExpression><![CDATA[$F{student.person} != null
        && $F{student.person}.getPrimaryPhoto() != null
        && $F{student.person}.getPrimaryPhoto().getPhoto() != null
        ? new java.io.ByteArrayInputStream($F{student.person}.getPrimaryPhoto().getPhoto())
        : null]]></imageExpression>
</image>
```
Use `onErrorType="Blank"` — always. If you only have the OID string (not the bean), use `"repo:" + $F{person.primaryPhotoOid}` instead.

---

## Alternating Row Shading

```xml
<rectangle>
    <reportElement mode="Opaque" x="3" y="0" width="530" height="74" backcolor="#EEF4FB">
        <printWhenExpression><![CDATA[$V{REPORT_COUNT} % 2 == 0]]></printWhenExpression>
    </reportElement>
    <graphicElement><pen lineWidth="0.0"/></graphicElement>
</rectangle>
```
`$V{REPORT_COUNT}` is built-in — no declaration needed.

---

## Date Snap to Monday (Java)

```java
import com.x2dev.utils.DateUtils;
import com.x2dev.utils.types.PlainDate;

PlainDate startDate = DateUtils.getStartOfWeek((PlainDate) getParameter(START_DATE_PARAM));
addParameter(START_DATE_PARAM, startDate); // overwrite so JRXML sees corrected date
```
Declare the parameter as `java.util.Date` in JRXML.

---

## Week Date Columns (JRXML)

```xml
<!-- Monday -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime()))]]></textFieldExpression>
<!-- Tuesday -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime() + 86400000L))]]></textFieldExpression>
<!-- Wednesday -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime() + 86400000L*2))]]></textFieldExpression>
```
`86400000` = ms per day. Use `86400000L` (long literal) to avoid int overflow.

---

## School vs District Scoping (Java)

```java
if (isSchoolContext()) {
    criteria.addEqualTo(schoolYearHelper.getSchoolOidField(), getSchool().getOid());
} else {
    criteria.addAndCriteria(getOrganizationCriteria(SisStudent.class));
}
```

---

## StudentContextReportHelper (student list queries)

```java
import com.x2dev.sis.tools.reports.StudentContextReportHelper;

StudentContextReportHelper schoolYearHelper =
    new StudentContextReportHelper(getOrganization(), getCurrentContext(), getBroker());

criteria.addEqualTo(schoolYearHelper.getSchoolOidField(), getSchool().getOid());
criteria.addAndCriteria(schoolYearHelper.getActiveStudentCriteria());
criteria.addNotEmpty(schoolYearHelper.getHomeroomField(), getBroker().getPersistenceKey());

query.addOrderByAscending(schoolYearHelper.getSchoolOidField());
query.addOrderByAscending(schoolYearHelper.getHomeroomField());
```

---

## Null-Safe ApplicationContext Check (Java)

```java
if (userData.getSessionNavConfig() != null &&
        ApplicationContext.STAFF.equals(
                userData.getSessionNavConfig().getApplicationContext())) {
    m_teacherOid = userData.getStaffOid();
}
```

---

## Scoping Class Attendance to Selected Section

```java
// In saveState():
ScheduleTeacher currentTeacherSection = userData.getCurrentRecord(ScheduleTeacher.class);
if (currentTeacherSection != null) {
    m_sectionOid = currentTeacherSection.getSection().getOid();
}

// In gatherData():
if (m_sectionOid != null) {
    criteria.addEqualTo("section" + PATH_DELIMITER + X2BaseBean.COL_OID, m_sectionOid);
}
QueryByCriteria query = new QueryByCriteria(StudentSchedule.class, criteria);
```
The current record in `attendance.period.classes.input` is a `ScheduleTeacher`, not `MasterSchedule`. Use `StudentSchedule` / `MasterSchedule` for OJB queries (not `StudentSection` / `Section`).

---

## Homeroom-to-Staff Map

```java
Map homeroomToStaff = ReportUtils.buildHomeroomToStaffMap(
    getBroker(), staffCriteria,
    getOrganization(),
    isSchoolContext() ? getSchool() : null);
addParameter(HOMEROOM_TO_STAFF_MAP, homeroomToStaff);

// Prevent all-rows match when filter returns empty
if (!homeroomToStaff.isEmpty()) {
    criteria.addIn(schoolYearHelper.getHomeroomField(), homeroomToStaff.keySet());
} else {
    addNoMatchCriteria(criteria);
}
```

---

## Standard Aspen Parameters (declare in JRXML, not in Input Definition)

```xml
<parameter name="school" class="com.x2dev.sis.model.beans.SisSchool"/>
<parameter name="organization" class="com.follett.fsc.core.k12.beans.Organization"/>
<parameter name="schoolContext" class="java.lang.Boolean"/>
<parameter name="currentContext" class="com.follett.fsc.core.k12.beans.DistrictSchoolYearContext" isForPrompting="false"/>
<parameter name="longDateFormat" class="java.text.DateFormat"/>
<parameter name="shortDateFormat" class="java.text.DateFormat"/>
```

---

## Group Header Field Evaluation

```xml
<textField evaluationTime="Group" evaluationGroup="homeroom" isBlankWhenNull="false">
    <reportElement printWhenGroupChanges="homeroom" .../>
    <textFieldExpression><![CDATA["Room: " + $F{homeroomCode}]]></textFieldExpression>
</textField>
```
Always use `evaluationTime="Group"` for fields in group headers — otherwise they show the previous row's value.

---

## Fuzzy Text Filter (Java)

```java
criteria.addContainsIgnoreCase(
    "section" + PATH_DELIMITER + "primaryStaff" + PATH_DELIMITER + SisStaff.COL_NAME_VIEW,
    getParameter(QUERY_STRING_PARAM));
```

---

## Current Selection Query (Java)

```java
case 3: // Current Selection
    SubQuery sectionSubQuery = new SubQuery(
        MasterSchedule.class, X2BaseBean.COL_OID, getCurrentCriteria());
    criteria.addIn("masterScheduleOid", sectionSubQuery);
    break;
```

---

## PATH_DELIMITER Import

```java
import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
// Fallback if unavailable:
// private static final String PATH_DELIMITER = ".";
```

---

## Field Definitions vs Method Calls in JRXML

Prefer explicit field definitions — dot notation maps to getter methods automatically:
```xml
<!-- Define at top of JRXML -->
<field name="student.nameView" class="java.lang.String"/>
<field name="student.person.primaryPhotoOid" class="java.lang.String"/>
<field name="section.roomView" class="java.lang.String"/>

<!-- Use in expressions -->
<textFieldExpression><![CDATA[$F{student.nameView}]]></textFieldExpression>
```
Avoid calling methods directly in expressions (`$F{student}.getNameView()`) — this can fail at compile time.

---

## Standard Import Blocks

### Student List / Attendance Report (most common)
```java
import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.QueryIterator;
import com.follett.fsc.core.k12.beans.X2BaseBean;
import com.follett.fsc.core.k12.tools.reports.QueryIteratorDataSource;
import com.follett.fsc.core.k12.tools.reports.ReportJavaSourceNet;
import com.follett.fsc.core.k12.tools.reports.ReportUtils;
import com.follett.fsc.core.k12.web.ApplicationContext;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.SisPerson;
import com.x2dev.sis.model.beans.SisStaff;
import com.x2dev.sis.tools.reports.StudentContextReportHelper;
import com.x2dev.utils.StringUtils;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.ojb.broker.query.QueryByCriteria;
import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
```

### Schedule / Section Reports (add to the above)
```java
import com.x2dev.sis.model.beans.MasterSchedule;
import com.x2dev.sis.model.beans.SchoolCourse;
import com.x2dev.sis.model.beans.Section;
import com.x2dev.sis.model.beans.StudentSchedule;
import com.x2dev.sis.model.beans.ScheduleTeacher;
import com.x2dev.sis.tools.reports.ScheduleReportHelper;
import com.follett.fsc.core.framework.persistence.SubQuery;
```

### Subreport / Complex Reports (add to the above)
```java
import com.follett.fsc.core.k12.tools.reports.BeanCollectionDataSource;
import com.follett.fsc.core.k12.tools.reports.SimpleBeanDataSource;
import com.follett.fsc.core.k12.beans.Report;
import com.follett.fsc.core.k12.business.dictionary.DataDictionary;
import java.io.ByteArrayInputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
```

---

## Navigation Node Keys Quick Reference

| Node Key | Context | Current Record Type |
|---|---|---|
| `attendance.daily.input` | Staff View → Attendance | — |
| `attendance.dailyHst.history` | Attendance history (school) | — |
| `attendance.dailyOfc.office` | Attendance office (school) | — |
| `attendance.dailyRos.hrmList` | Homeroom roster list (school) | — |
| `attendance.dailyRos.hrmList.roster` | Homeroom roster detail (school) | — |
| `attendance.dailyRos.clsList` | Class roster list (school) | — |
| `attendance.dailyRos.clsList.roster` | Class roster detail (school) | — |
| `attendance.period.classes.input` | Staff View → Class tab | **ScheduleTeacher** |
| `student.std.list` | Student list | — |
| `student.std.detail` | Student detail | **SisStudent** |
| `schedule.master.list` | Master schedule list | — |
| `schedule.master.detail` | Master schedule detail | **MasterSchedule** |
| `staff.stf.list` | Staff list | — |
| `staff.stf.detail` | Staff detail | **SisStaff** |

Use `staff-view="true"`, `school-view="true"`, or `district-view="true"` on `<node>` elements. See `BuildResources/bundle-definition-template.xml` for full docs.

---

## CSV Export Quick Reference

### ExportJavaSource Minimal Pattern
```java
public class MyExportData extends ExportJavaSource {
    private List<String> m_columnNames;
    private List<String> m_columnUserNames;

    @Override
    protected DataGrid gatherData() {
        ReportDataGrid grid = new ReportDataGrid();
        grid.append();
        grid.set("Column", value);
        grid.beforeTop();
        return grid;
    }

    @Override
    protected void initialize() throws X2BaseException {
        super.initialize();
        setIncludeHeaderRow(true);
        setValueDelimiter(',');
        setValueWrapper('"');
        m_columnNames = new ArrayList<String>();
        m_columnNames.add("Column");
        m_columnUserNames = new ArrayList<String>(m_columnNames);
    }

    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException {
        super.saveState(userData);
        runOnApplicationServer();
    }

    @Override public String getCustomFileName()   { return "MyExport.csv"; }
    @Override protected List getColumnNames()      { return m_columnNames; }
    @Override protected List getColumnUserNames()  { return m_columnUserNames; }
    @Override protected String getComment()        { return null; }
    @Override protected String getHeader()         { return null; }
}
```

### Export Import Block
```java
import com.follett.fsc.core.framework.persistence.SubQuery;
import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.DistrictSchoolYearContext;
import com.follett.fsc.core.k12.beans.X2BaseBean;
import com.follett.fsc.core.k12.tools.exports.ExportJavaSource;
import com.follett.fsc.core.k12.tools.reports.ReportDataGrid;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.GradeTerm;
import com.x2dev.sis.model.beans.GradeTermDate;
import com.x2dev.utils.DataGrid;
import com.x2dev.utils.StringUtils;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;
import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;
```

### Export Bundle Definition
```xml
<tool-bundle create-date="YYYY-MM-DD">
  <exports package="com.x2dev.reports.yourstate.yourdistrict">
    <export-definition id="CUST-XXX-YYY" name="Export Name – CSV"
        category="Category" javasource-file="ExportData.java"
        input-file="ExportInput.xml" weight="1" schedulable="false"
        custom-java="true" custom-input="true" custom-xml="true">
      <node key="student.std.list" school-view="true" />
    </export-definition>
  </exports>
</tool-bundle>
```

### Export Zip Structure
```
MyExport.zip
├── bundle-definition.xml              ← root level
└── com/x2dev/reports/yourstate/yourdistrict/  ← package directory
    ├── MyExportData.java
    └── MyExportInput.xml
```
**Important:** Input XML goes inside the package directory (not at root), otherwise Aspen throws `Missing file` error.

### Key CSV Settings
- `setValueDelimiter(',')` — comma-separated (default is tab)
- `setValueWrapper('"')` — wraps values in quotes
- `getCustomFileName()` — override to return `.csv` (default is `.txt`)
- `setIncludeHeaderRow(true)` — adds column names as first row

---

## Resolving Grade Term Date Ranges (Java)

Use `GradeTermDate` (not `ScheduleTermDate`) to get actual quarter boundaries:

```java
import com.x2dev.sis.model.beans.GradeTermDate;

X2Criteria dateCriteria = new X2Criteria();
dateCriteria.addEqualTo(GradeTermDate.COL_GRADE_TERM_OID, m_gradeTerm.getOid());
dateCriteria.addGreaterOrEqualThan(GradeTermDate.COL_START_DATE, m_context.getStartDate());
dateCriteria.addLessOrEqualThan(GradeTermDate.COL_END_DATE, m_context.getEndDate());

QueryByCriteria dateQuery = new QueryByCriteria(GradeTermDate.class, dateCriteria);
Collection<GradeTermDate> termDates = getBroker().getCollectionByQuery(dateQuery);
// Iterate to find min start / max end; fall back to context dates for YR
```

`ScheduleTermDate` stores the full year range (8/1–7/31) for ALL terms — it won't filter by quarter. `GradeTerm` does NOT have `getGradeTermMap()` — that's only on `ScheduleTerm`.

For full-year support, use a "Full Year" checkbox that skips the grade term and falls back to context dates:
```java
Boolean fullYear = (Boolean) getParameter("fullYear");
if (fullYear == null || !fullYear.booleanValue()) { /* load grade term */ }
// When fullYear is true, m_gradeTerm stays null → resolveTermDates() uses context year
```

---

## DataDictionary Field Metadata Access

`DataFieldConfig` and `DataDictionaryField` split field metadata across two objects:

```java
import com.follett.fsc.core.k12.beans.DataFieldConfig;
import com.follett.fsc.core.k12.business.dictionary.DataDictionary;
import com.follett.fsc.core.k12.business.dictionary.DataDictionaryField;

DataDictionary dictionary = DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey());

// DataFieldConfig getters (bean layer):
field.getDataFieldOid()    // ✓ "psnNameFirst"
field.getUserLongName()    // ✓ "First name"
field.getUserShortName()   // ✓ "FirstName"
field.getJavaName()        // ✗ does NOT exist
field.getDatabaseName()    // ✗ does NOT exist

// DataDictionaryField getters (business layer — via dictionary lookup):
DataDictionaryField ddField = dictionary.findDataDictionaryField(oid);
ddField.getJavaName()          // ✓ "firstName"
ddField.getEffectiveJavaType() // ✓ "java.lang.String"
ddField.getDatabaseName()      // ✓ "PSN_NAME_FIRST"
ddField.getDataFieldOid()      // ✗ does NOT exist — use DataFieldConfig

// DataDictionaryTable — cannot iterate fields:
// ddTable.getFields()    ✗ does NOT exist
// ddTable.getFieldsMap() ✗ does NOT exist
```

**ClassNotFoundException** for a custom class = Java compile error (Aspen swallows the real error).

---

## SisAddress API (verified)

```java
SisAddress address = person.getPhysicalAddress();
String streetNo = String.valueOf(address.getStreetNumber());  // returns int!
String streetName = address.getAddressLine01();                // NOT getStreetLine01()
String city = address.getCity();
String state = address.getState();
String zip = address.getPostalCode();
```

---

## District View Context — getCurrentContext() Returns Null

```java
// In Input XML: add contextOid picklist
// In initialize():
String contextOid = (String) getParameter("contextOid");
m_context = (DistrictSchoolYearContext) getBroker().getBeanByOid(
        DistrictSchoolYearContext.class, contextOid);
```

---

## Multi-School Query

```java
List<String> schoolOids = new ArrayList<String>();
schoolOids.add(getSchool().getOid());
schoolOids.add(otherSchool.getOid());
criteria.addIn(SisStudent.COL_SCHOOL_OID, schoolOids);
```

---

## Boolean-Like Custom Field OR Criteria

```java
X2Criteria techY = new X2Criteria();
techY.addEqualTo(fieldPath, "Y");
X2Criteria techTrue = new X2Criteria();
techTrue.addEqualTo(fieldPath, "TRUE");
X2Criteria techOne = new X2Criteria();
techOne.addEqualTo(fieldPath, "1");
techY.addOrCriteria(techTrue);
techY.addOrCriteria(techOne);
criteria.addAndCriteria(techY);
```

---

## X2Criteria — Methods That Don't Exist

- `addNotContains()` — use `addNotLike(field, "%keyword%")` instead

---

## Common Compilation Errors → Quick Fixes

| Error | Fix |
|---|---|
| `cannot find symbol: PATH_DELIMITER` | Add static import or define locally as `"."` |
| `weaker access privileges` on override | Change method to `protected` |
| `cannot find symbol: UserDataContainer` | Add `import com.follett.fsc.core.k12.web.UserDataContainer;` |
| `Attribute 'isBlankWhenNull' not allowed on image` | Remove attribute; handle null in the expression instead |
| Element bottom reaches outside band | Increase band height: `y + height + buffer` |
| `sectionOid` / `masterScheduleOid` column not found | Use `"section.oid"` (OJB relationship path) |
| `cannot find symbol: getStreetLine01()` | Use `getAddressLine01()` instead |
| `int cannot be converted to String` on `getStreetNumber()` | Wrap with `String.valueOf()` |
| `cannot find symbol: addNotContains` | Use `addNotLike(field, "%keyword%")` |
| `getCurrentContext()` returns null | Use `contextOid` input parameter (see District View Context above) |
