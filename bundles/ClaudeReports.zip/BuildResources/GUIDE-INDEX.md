# Follett Aspen X2 SIS Report Generation Guide

This guide has been split into focused subject files in `BuildResources/Guide/` for easier AI agent consumption. Start with `00-AI-WORKFLOW.md`.

## Guide Files

| File | Contents |
|---|---|
| [`Guide/00-AI-WORKFLOW.md`](Guide/00-AI-WORKFLOW.md) | **Start here** — step-by-step workflow, complexity levels, companion files reference, quick start checklist |
| [`Guide/01-ARCHITECTURE.md`](Guide/01-ARCHITECTURE.md) | System overview, core technologies, required components |
| [`Guide/02-DATABASE-SCHEMA.md`](Guide/02-DATABASE-SCHEMA.md) | All table/field mappings, query patterns, naming conventions, full schema reference |
| [`Guide/03-INPUT-DEFINITION.md`](Guide/03-INPUT-DEFINITION.md) | Input Definition XML structure, input types, conditional logic |
| [`Guide/04-JRXML-FORMAT.md`](Guide/04-JRXML-FORMAT.md) | JRXML structure, report bands, field expressions, advanced layout features, photo loading |
| [`Guide/05-JAVA-DATASOURCE.md`](Guide/05-JAVA-DATASOURCE.md) | Java data source patterns, common report types, required imports, key classes |
| [`Guide/06-BEST-PRACTICES.md`](Guide/06-BEST-PRACTICES.md) | Development process, best practices, advanced features (Level 4), resources and version info |
| [`Guide/07-TROUBLESHOOTING.md`](Guide/07-TROUBLESHOOTING.md) | 25 documented issues with root causes and solutions |
| [`Guide/08-QUICK-REFERENCE.md`](Guide/08-QUICK-REFERENCE.md) | Most-used patterns in one page — fastest lookup |
