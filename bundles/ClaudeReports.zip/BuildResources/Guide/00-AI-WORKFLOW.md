# Aspen Report Generation — AI Agent Workflow

This is the starting point for AI agents building Aspen reports. Read this first, then consult the subject-specific files as needed.

---

## Step-by-Step Workflow

### Step 1: Understand the Requirement
- Clarify what data the report/export needs to display
- Determine the **output type**: PDF report or CSV export?
- Determine the context (student list, individual record, compliance form, etc.)
- Identify the complexity level (see [Report Complexity Levels](#report-complexity-levels))

> **PDF vs CSV decision:** Use a **Report** (`ReportJavaSourceNet` + JRXML) for formatted printable output. Use an **Export** (`ExportJavaSource` + `DataGrid`) for data extracts, imports, and spreadsheet-friendly output. See `01-ARCHITECTURE.md § Exports (CSV) vs Reports (PDF)` for the full comparison.

### Step 2: Research the Data Model
- Consult `02-DATABASE-SCHEMA.md` for field mappings
- Reference `FullDatabaseSchema_cleaned.csv` for the complete field inventory of your target tables
- Identify the primary tables, relationships, and fields needed

### Step 3: Choose a Matching Example
Review the examples in `Report Examples/` to find the closest match:
- **Example 1** (Level 1 - Basic): Class list report with Input Definition, JRXML, and Java Source — use for simple list/query reports
- **Example 2** (Level 3 - Advanced): Section 504 Plan with JRXML and Java Source only (no Input Definition) — use for single-record forms that run from a current record context
- **Example 3** (Level 4 - Enterprise): MA IEP Form with Input Definition, JRXML, and Java Source — use for complex multi-engine compliance forms

Use the chosen example as a structural reference. For a minimal starting point, copy the files from `BuildResources/Templates/` and rename them.

### Step 4: Create the Report/Export Files

**For Reports (PDF):**
1. **Input Definition XML** — Define user parameters (may be omitted for current-record context reports; see `03-INPUT-DEFINITION.md`)
2. **Report Format Definition (JRXML)** — Design the layout (see `04-JRXML-FORMAT.md`)
3. **Java Data Source** — Extend `ReportJavaSourceNet`, implement data retrieval logic (see `05-JAVA-DATASOURCE.md`)

**For Exports (CSV):**
1. **Input Definition XML** — Same format as reports (place inside package directory)
2. **Java Data Source** — Extend `ExportJavaSource`, return `DataGrid` (see `05-JAVA-DATASOURCE.md § CSV Export Data Source`)
3. No JRXML needed

### Step 5: Validate and Review
- Cross-check field names against the database schema
- Ensure JRXML field definitions match the data source output
- Verify band heights accommodate all elements
- Check for null safety in expressions

### Step 6: Deployment
To deploy a report into Aspen:
1. Navigate to **System Administration > Reports** in the Aspen admin interface
2. Create a new report entry or locate the existing one to modify
3. Upload each of the three files to their respective slots (Input Definition, Format Definition, Java Source)
4. Aspen will compile the JRXML into a `.jasper` file and the Java source into a class file
5. Test the report from the appropriate context (student list, individual student record, etc.)
6. If changes are made after initial upload, you must **recompile** the format file for changes to take effect

---

## Report Complexity Levels

#### Level 1: Basic Reports (e.g., Class Lists)
- Simple input parameters
- Single main data source
- Direct field mappings
- Basic formatting
- Example: ClassListData

#### Level 2: Intermediate Reports (e.g., JRXML-only reports)
- No input definition XML (only JRXML and Java)
- Advanced layout with conditional formatting
- Multiple groups and sorting
- Static data sources
- Example: Simple form reports

#### Level 3: Advanced Reports (e.g., Section 504 Plans)
- Complex input parameters
- Multiple subreports
- Dynamic data source creation
- Reference code integration
- Advanced parameter passing
- Example: Section504PlanData

#### Level 4: Enterprise IEP Forms (e.g., MA IEP Forms)
- Multi-engine JasperReports support (5.5 and 6.19)
- Custom data source classes
- Complex form state management
- Document saving and export functionality
- Advanced accommodation processing
- Multiple subreport coordination
- Example: IepForm23Data

---

## What to Read — Decision Matrix

| Task | Read these |
|---|---|
| Building a CSV export | `01-ARCHITECTURE.md` (Exports section), `02-DATABASE-SCHEMA.md`, `03-INPUT-DEFINITION.md`, `05-JAVA-DATASOURCE.md` (ExportJavaSource section), `08-QUICK-REFERENCE.md` (CSV Export section) |
| Building a new student list report | `02-DATABASE-SCHEMA.md`, `03-INPUT-DEFINITION.md`, `04-JRXML-FORMAT.md`, `05-JAVA-DATASOURCE.md` (patterns 1-2) |
| Building a per-student form (no input form) | `03-INPUT-DEFINITION.md` (omit section), `04-JRXML-FORMAT.md`, `05-JAVA-DATASOURCE.md` (pattern 1) |
| Building a homeroom attendance report | `04-JRXML-FORMAT.md` (all sections), `05-JAVA-DATASOURCE.md` (Homeroom Reports section) |
| Building a class/section attendance report | `05-JAVA-DATASOURCE.md` (Homeroom Reports + School vs District sections), `07-TROUBLESHOOTING.md` (#21) |
| Adding student photos | `04-JRXML-FORMAT.md` (Photo Loading section), `07-TROUBLESHOOTING.md` (#19) |
| Debugging Java compilation errors | `07-TROUBLESHOOTING.md` (#16-18) |
| Debugging JRXML/XML errors | `07-TROUBLESHOOTING.md` (#13-15) |
| Filtering by grade term / quarter dates | `02-DATABASE-SCHEMA.md` (GradeTermDate section), `05-JAVA-DATASOURCE.md` (Resolving Grade Term Dates), `07-TROUBLESHOOTING.md` (#24-25) |
| Quick pattern lookup | `08-QUICK-REFERENCE.md` |
| Understanding bundle-definition.xml | `BuildResources/bundle-definition-template.xml` |

---

## Companion Files Reference

### Guide Files (`BuildResources/Guide/`)
| File | Purpose |
|---|---|
| `00-AI-WORKFLOW.md` | This file — start here |
| `01-ARCHITECTURE.md` | System overview, core technologies, required components |
| `02-DATABASE-SCHEMA.md` | All table/field mappings, query patterns, naming conventions |
| `03-INPUT-DEFINITION.md` | Input Definition XML structure and patterns |
| `04-JRXML-FORMAT.md` | JasperReports layout structure and advanced features |
| `05-JAVA-DATASOURCE.md` | Java data source patterns and common report types |
| `06-BEST-PRACTICES.md` | Development process, best practices, advanced features, resources |
| `07-TROUBLESHOOTING.md` | Troubleshooting guide for common errors |
| `08-QUICK-REFERENCE.md` | Most-used patterns in one page — fastest lookup |

### Starter Templates (`BuildResources/Templates/`)
Copy these skeleton files to begin a new report. Includes `bundle-definition.xml`, Input Definition, JRXML, and Java data source with school/district scoping, active student criteria, and common patterns pre-wired.

### Database Schema Files (`BuildResources/`)
- **`FullDatabaseSchema_cleaned.csv`** — Complete field inventory for all Aspen database tables, with Java field names, descriptions, data types, and database column names.
- **`FullDatabaseSchema&Setup.csv`** — Extended schema file including setup/configuration fields.
- **`GradeTermMap.csv`** — Grade term bitmap definitions (Q1–Q4, YR) showing `gradeTermMap` positional format.
- **`TermMapExpanded.csv`** — Expanded schedule term data showing that `ScheduleTermDate` stores full-year ranges for all terms (use `GradeTermDate` instead for actual quarter boundaries).

### Report Examples (`BuildResources/Report Examples/`)
| Example | Complexity | Files Included | Description |
|---------|-----------|----------------|-------------|
| Example 1 | Level 1 (Basic) | Input Definition, JRXML, Java Source | Class list report — demonstrates simple query-based lists with grouping |
| Example 2 | Level 3 (Advanced) | JRXML, Java Source | Section 504 Plan — demonstrates single-record forms with subreports. **No Input Definition** because it runs from a current student education plan record context. |
| Example 3 | Level 4 (Enterprise) | Input Definition, JRXML, Java Source | MA IEP Form — demonstrates multi-engine support, complex accommodation processing, and document saving |

> **Note — Level 2 example:** No dedicated Level 2 example exists in this collection yet. For Level 2 use cases (JRXML + Java only, no input form, simple conditional formatting), adapt one of the existing Level 1 examples by adding conditional formatting logic.

---

## Quick Start Checklist

### For New Reports (PDF):
- [ ] Define report requirements and data sources
- [ ] Create input definition XML with required parameters
- [ ] Design JRXML layout with appropriate bands and fields
- [ ] Implement Java data source (`ReportJavaSourceNet`) with proper criteria building
- [ ] Test with sample data and various parameter combinations
- [ ] Validate output formats (PDF, Excel, etc.)
- [ ] Deploy and configure in Aspen system

### For New Exports (CSV):
- [ ] Define export requirements and data sources
- [ ] Create input definition XML with required parameters (place in package directory)
- [ ] Implement Java data source (`ExportJavaSource`) with `DataGrid`, column definitions, and CSV settings
- [ ] Override `getCustomFileName()` to return `.csv` filename
- [ ] Create `bundle-definition.xml` with `<exports>` / `<export-definition>` tags
- [ ] Package zip: `bundle-definition.xml` at root, all other files in package directory
- [ ] Deploy and test in Aspen

### For Modifying Existing Reports:
- [ ] Backup original report files
- [ ] Identify required changes in each component
- [ ] Update input definition if new parameters needed
- [ ] Modify JRXML for layout/formatting changes
- [ ] Update Java logic for data source modifications
- [ ] Test thoroughly with existing and new scenarios
- [ ] Document changes for future maintenance
