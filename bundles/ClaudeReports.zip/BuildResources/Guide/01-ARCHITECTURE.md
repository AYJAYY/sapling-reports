# Aspen Report Generation — System Architecture & Required Components

---

## Overview

Follett Aspen X2 SIS is a comprehensive Student Information System that uses JasperReports for custom report generation. The system provides nearly 200 standard reports with extensive customization capabilities, allowing developers to create professional reports through a three-component architecture:

- **Input Definition XML**: Defines user parameters and options
- **Report Format Definition (JRXML)**: Defines the visual layout and formatting
- **Java Data Source**: Handles data retrieval and business logic

---

## System Architecture

### Core Technologies
- **Platform**: Java-based with .NET integration
- **Database**: Microsoft SQL Server
- **Reporting Engines**: JasperReports 6.19.1 (primary; 5.5.0 legacy only for Level 4 multi-engine forms)
- **Report Designer**: Jaspersoft Studio (Eclipse-based; use for JR 6.x reports)
- **Version**: Aspen 6.9.x

### Key Features
- Source code access to workflow engine and report customization
- RESTful API support for data integration
- Live database extraction capabilities
- Context-specific reporting on each page
- State and federal reporting compliance
- Multi-format output support (PDF, Excel, etc.)

---

## Required Components

Every Aspen report requires three core files:

### 1. Input Definition XML
- Defines user interface parameters
- Specifies data filtering options
- Controls report behavior settings
- File naming: `[ReportName] - Input Definition.xml`

### 2. Report Format Definition (JRXML)
- JasperReports XML template
- Defines layout, styling, and data presentation
- Contains bands for different report sections
- File naming: `[ReportName] - Report Format Definition.jrxml`

### 3. Java Data Source
- Handles database queries and data processing
- Implements business logic for report generation
- Extends `ReportJavaSourceNet` class
- File naming: `[ReportName] - Java Source Code.java`

---

## Exports (CSV) vs Reports (PDF)

Aspen supports two distinct tool types: **Reports** (PDF output via JasperReports) and **Exports** (CSV/delimited file output). They share the same bundle deployment mechanism but differ in structure.

### Key Differences

| Aspect | Report (PDF) | Export (CSV) |
|--------|-------------|--------------|
| **Java base class** | `ReportJavaSourceNet` | `ExportJavaSource` |
| **`gatherData()` returns** | `JRDataSource` | `DataGrid` |
| **JRXML layout file** | Required | Not used |
| **Bundle XML tag** | `<reports>` / `<report-definition>` | `<exports>` / `<export-definition>` |
| **Bundle attributes** | Has `design-file`, `engine-version` | No `design-file` or `engine-version` |
| **Package attribute** | Not used on `<reports>` tag | `package="com.x2dev.reports.yourstate.yourdistrict"` on `<exports>` tag |
| **Java file location** | Directly in report folder | Inside package directory (e.g., `com/x2dev/reports/yourstate/yourdistrict/`) |
| **Custom flags** | Typically `custom-java="false"` | Typically `custom-java="true"`, `custom-input="true"`, `custom-xml="true"` |

### Export File Structure (3 files, no JRXML)

| File | Purpose |
|------|---------|
| `bundle-definition.xml` | Registers the export with Aspen (uses `<exports>` / `<export-definition>`) |
| `*Input.xml` | Input Definition — same format as reports |
| `*Data.java` | Java data source — extends `ExportJavaSource`, returns `DataGrid` |

### Export Java Data Source Pattern

```java
public class MyExportData extends ExportJavaSource {
    private List<String> m_columnNames;
    private List<String> m_columnUserNames;

    @Override
    protected DataGrid gatherData() {
        ReportDataGrid grid = new ReportDataGrid();
        // Query data, build rows
        grid.append();
        grid.set("ColumnName", value);
        grid.beforeTop();
        return grid;
    }

    @Override
    protected void initialize() throws X2BaseException {
        super.initialize();
        setIncludeHeaderRow(true);
        // Define column names
    }

    @Override protected List getColumnNames()     { return m_columnNames; }
    @Override protected List getColumnUserNames() { return m_columnUserNames; }
    @Override protected String getComment()       { return null; }
    @Override protected String getHeader()        { return null; }
}
```

### Export bundle-definition.xml Pattern

```xml
<tool-bundle create-date="YYYY-MM-DD">
  <exports package="com.x2dev.reports.yourstate.yourdistrict">
    <export-definition id="CUST-XXX-YYY" name="Export Name – CSV"
        category="Category" javasource-file="ExportData.java"
        input-file="ExportInput.xml" weight="1" schedulable="false"
        custom-java="true" custom-input="true" custom-xml="true">
      <node key="student.std.list" school-view="true" />
    </export-definition>
  </exports>
</tool-bundle>
```

> See the `Report Examples/` folder for complete working examples.

### Grade Term Date Resolution

When an export or report needs to filter by grading period (Q1–Q4, YR), use `GradeTermDate` to resolve the actual date range — **not** `ScheduleTermDate`, which stores the full schedule year range for all terms. See `02-DATABASE-SCHEMA.md § Scheduling & Grading Period Tables` for details.
