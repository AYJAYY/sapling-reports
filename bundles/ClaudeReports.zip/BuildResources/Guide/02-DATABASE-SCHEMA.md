# Aspen Report Generation — Database Schema

---

## Table Prefixes and Organization

The Aspen database uses a three-letter prefix system to organize tables by functional area:

### Core Entity Tables
- **PSN** (Person): Base person information for all system users
- **STD** (Student): Student-specific data and academic information
- **STF** (Staff): Staff member information, positions, and assignments
- **ADR** (Address): Physical and mailing addresses (accessed via `SisAddress` bean)
- **SKL** (School): School records (accessed via `SisSchool` bean)
- **RMS** (Room/School): Room and facility information

### Academic and Scheduling Tables
- **ATT** (Attendance): Student attendance records and codes
- **TRN** (Transportation): Student transportation records and routing
- **CND** (Conduct): Disciplinary incidents and actions
- **ACT** (Activities): Student activities and participation

### System Tables
- **USR** (User): System user accounts and permissions
- **CTJ** (Contact Join): Relationship tables for contacts
- **SFP** (Staff Position): Staff position assignments

---

## Key Field Structure and Naming Conventions

### Standard Field Types
```
Format: [table_prefix][FieldName] -> [DB_PREFIX]_[FIELD_NAME]
Examples:
- psnNameFirst -> PSN_NAME_FIRST (java.lang.String)
- stdYog -> STD_YOG (int)
- attDate -> ATT_DATE (java.sql.Date)
- stfDeptCode -> STF_DEPARTMENT_CODE (java.lang.String)
```

### Custom Field Extensions
Each table supports custom fields (fieldA001–A100, fieldB001–B100, fieldC001–C100, fieldD001–D100). These are district-specific — run the DEVResources schema export to discover what your district uses each field for.

---

## Important Table Fields

### Person (PSN) Table Fields
```java
// Core identification
PSN_PERSON_ID       -> personId (java.lang.String)
PSN_NAME_FIRST      -> firstName (java.lang.String)
PSN_NAME_LAST       -> lastName (java.lang.String)
PSN_DOB             -> dob (java.sql.Date)
PSN_GENDER_CODE     -> genderCode (java.lang.String)

// Indicators for user types
PSN_STUDENT_IND     -> studentIndicator (boolean)
PSN_STAFF_IND       -> staffIndicator (boolean)
PSN_CONTACT_IND     -> contactIndicator (boolean)
PSN_USER_IND        -> userIndicator (boolean)

// Contact information
PSN_EMAIL_01        -> email01 (java.lang.String)
PSN_PHONE_01        -> phone01 (java.lang.String)
PSN_ADRS_VIEW       -> addressView (java.lang.String)
```

### Student (STD) Table Fields
```java
// Academic tracking
STD_YOG             -> yog (int) - Year of Graduation
STD_GRADE_LEVEL     -> gradeLevel (java.lang.String)
STD_ACADEMIC_TRACK_TYPE_CODE -> academicTrackType (java.lang.String)

// Status indicators
STD_ENROLLMENT_STATUS -> enrollmentStatus (java.lang.String)
STD_504_STATUS      -> section504StatusCode (java.lang.String)
STD_504_LAST_END_DATE -> section504LastEndDate (java.sql.Date)

// Custom fields — district-specific, run DEVResources export to see your mappings
// STD_FIELDA_001 through STD_FIELDD_100 -> Various custom fields
```

### Staff (STF) Table Fields
```java
// Organizational structure
STF_DEPARTMENT_CODE -> departmentCode (java.lang.String)
STF_BARGAINING_UNIT -> bargainingUnit (java.lang.String)
STF_CALENDAR_ID     -> calendarId (java.lang.String)

// Contact and directory information
STF_ADRS_VIEW       -> addressView (java.lang.String)

// Custom fields — district-specific, run DEVResources export to see your mappings
// STF_FIELDA_001 through STF_FIELDD_100 -> Various custom fields
```

### Attendance (ATT) Table Fields
```java
// Core attendance data
ATT_DATE            -> date (java.sql.Date)
ATT_CODE_VIEW       -> codeView (java.lang.String)
ATT_PORTION_ABSENT  -> portionAbsent (java.math.BigDecimal)

// Attendance indicators
ATT_ABSENT_IND      -> absentIndicator (boolean)
ATT_TARDY_IND       -> tardyIndicator (boolean)
ATT_EXCUSED_IND     -> excusedIndicator (boolean)
ATT_DISMISSED_IND   -> dismissedIndicator (boolean)

// Additional data
ATT_REASON_CODE     -> reasonCode (java.lang.String)
ATT_COMMENT         -> comment (java.lang.String)
ATT_TIME_VIEW       -> timeView (java.lang.String)
```

### Room (RMS) Table Fields
```java
// Room identification
RMS_ROOM_NUMBER     -> roomNumber (java.lang.String)
RMS_BUILDING_CODE   -> buildingCode (java.lang.String)
RMS_DEPARTMENT_CODE -> departmentCode (java.lang.String)
RMS_LOCATION_CODE   -> locationCode (java.lang.String)

// Capacity and features
RMS_MAX_CAPACITY    -> maxCapacity (int)

// Custom fields — district-specific, run DEVResources export to see your mappings
// RMS_FIELDA_001 through RMS_FIELDD_100 -> Various custom fields

// Scheduling flags
RMS_SCHD_INCLUDE_IND -> scheduleIncludeIndicator (boolean)
RMS_EXAM_INCLUDE_IND -> examIncludeIndicator (boolean)
RMS_SCHD_USE_TYPE   -> scheduleUseType (int)
```

### Scheduling Tables — Key Fields and Relationships

```java
// Schedule (SCH) — represents a school's schedule for a school year
Schedule.COL_SCHOOL_OID             -> schoolOid (links to SisSchool)
Schedule.COL_DISTRICT_CONTEXT_OID   -> districtContextOid (links to school year)

// MasterSchedule (MST) — a section in the master schedule
MasterSchedule.COL_SCHEDULE_OID     -> scheduleOid (links to Schedule)
MasterSchedule.COL_SECTION_NUMBER   -> sectionNumber
MasterSchedule.COL_DESCRIPTION      -> description
MasterSchedule.REL_PRIMARY_STAFF    -> primaryStaff (SisStaff relationship)
MasterSchedule.REL_SCHOOL_COURSE    -> schoolCourse (SchoolCourse relationship)

// SchoolCourse (CSK) — a course offered at a school
SchoolCourse.COL_NUMBER             -> number (course number)
SchoolCourse.COL_DESCRIPTION        -> description
SchoolCourse.COL_DEPARTMENT_CODE    -> departmentCode

// StudentSchedule (SSC) — a student's enrollment in a section
StudentSchedule.REL_SECTION         -> section (MasterSchedule relationship)
StudentSchedule.REL_STUDENT         -> student (SisStudent relationship)
StudentSchedule.REL_SCHEDULE        -> schedule (Schedule relationship)

// ScheduleTeacher (MTC) — a teacher's assignment to a section
ScheduleTeacher.REL_SECTION         -> section (MasterSchedule relationship)
ScheduleTeacher.COL_STAFF_OID       -> staffOid
ScheduleTeacher.COL_SECTION_OID     -> sectionOid
```

**Important**: `StudentSection` / `Section` (from documentation) may NOT be OJB-queryable in some Aspen versions. Use `StudentSchedule` / `MasterSchedule` for OJB queries instead.

---

## Database Access Patterns
```java
// Standard criteria building with table prefixes
X2Criteria criteria = new X2Criteria();
criteria.addEqualTo(StudentSection.COL_SCHEDULE_OID, scheduleOid);

// Relationship traversal using PATH_DELIMITER
criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER +
                   Section.COL_PRIMARY_STAFF_OID, teacherOid);

// Working with Person indicators
criteria.addEqualTo(SisPerson.COL_STUDENT_INDICATOR, Boolean.TRUE);

// Date range queries
criteria.addGreaterOrEqualThan(StudentAttendance.COL_DATE, startDate);
criteria.addLessOrEqualThan(StudentAttendance.COL_DATE, endDate);

// Custom field queries
criteria.addEqualTo(SisStudent.COL_FIELD_A001, customValue);
```

### Common Query Patterns by Report Type

#### Student List Reports
```java
// Base student query
X2Criteria criteria = new X2Criteria();
criteria.addEqualTo(SisStudent.REL_PERSON + PATH_DELIMITER +
                   SisPerson.COL_STUDENT_INDICATOR, Boolean.TRUE);
criteria.addEqualTo(SisStudent.COL_ENROLLMENT_STATUS, "Active");
```

#### Staff Directory Reports
```java
// Active staff query
X2Criteria criteria = new X2Criteria();
criteria.addEqualTo(SisStaff.REL_PERSON + PATH_DELIMITER +
                   SisPerson.COL_STAFF_INDICATOR, Boolean.TRUE);
criteria.addNotNull(SisStaff.COL_DEPARTMENT_CODE);
```

#### Attendance Reports
```java
// Attendance in date range
X2Criteria criteria = new X2Criteria();
criteria.addBetween(StudentAttendance.COL_DATE, startDate, endDate);
criteria.addEqualTo(StudentAttendance.COL_ABSENT_INDICATOR, Boolean.TRUE);
```

---

## Using the CSV Schema Files

`BuildResources/FullDatabaseSchema_cleaned.csv` contains the complete field inventory.

### CSV Column Legend

| Column | Description | Example |
|---|---|---|
| `OID` | Internal field identifier (table prefix + Java name) | `psnEmail02` |
| `Long Name` | Human-readable field description | `Alternate email` |
| `Short Name` | Abbreviated label (used in Aspen UI) | `Email2` |
| `Java Name` | JavaBean property name — use this in criteria and JRXML field definitions | `email02` |
| `Java Type` | Java data type | `java.lang.String` |
| `Database Name` | SQL Server column name — use only for raw SQL queries | `PSN_EMAIL_02` |

The most useful columns for report development are **Java Name** (for OJB criteria and JRXML fields) and **Database Name** (for raw SQL). The **OID** column's prefix tells you which table the field belongs to (e.g., `psn` = Person, `std` = Student).

### Search Strategies

- **By table**: search for the table prefix (e.g., `STD_` for student fields, `PSN_` for person fields)
- **By Java field name**: search for the camelCase name (e.g., `nameView`, `primaryPhotoOid`)
- **By DB column**: search for the uppercase column name (e.g., `PSN_PHO_OID_PRIMARY`)
- **Custom fields**: search `FIELDA`, `FIELDB`, `FIELDC`, or `FIELDD` to find all custom field slots for a table

> See `05-JAVA-DATASOURCE.md § End-to-End Field Mapping` for how Java field names connect to JRXML expressions.

`FullDatabaseSchema&Setup.csv` additionally includes setup/configuration fields — use it when looking for district-configuration or reference table fields not found in the cleaned version.

---

## Full Database Schema Reference

### Table Prefixes Legend
- **ACT**: Activities and Extracurricular
- **ATT**: Attendance Records
- **CND**: Conduct and Disciplinary Records
- **CTJ**: Course/Teacher Junctions
- **PSN**: Person Records (Students, Staff, Contacts)
- **RMS**: Room and Space Management
- **SFP**: Staff Position Records
- **STD**: Student Records
- **STF**: Staff Records
- **TRN**: Transportation Records
- **USR**: User and Security Records

### PSN - Person Records (Students, Staff, Contacts, Parents)

| Java Field | Description | Short Name | Java Type | Database Column |
|------------|-------------|------------|-----------|-----------------|
| email02 | Alternate email | Email2 | java.lang.String | PSN_EMAIL_02 |
| contactIndicator | Contact | Contact | boolean | PSN_CONTACT_IND |
| dob | Date of birth | DOB | java.sql.Date | PSN_DOB |
| firstName | First name | FirstName | java.lang.String | PSN_NAME_FIRST |
| genderCode | Gender | Gender | java.lang.String | PSN_GENDER_CODE |
| emailGoogle | Google Docs email | Gmail | java.lang.String | PSN_EMAIL_G |
| hispanicLatinoIndicator | Hispanic or Latino | HispanicLatino | boolean | PSN_HISPANIC_LATINO_IND |
| personId | Identifier | ID | java.lang.String | PSN_PERSON_ID |
| lastName | Last name | LastName | java.lang.String | PSN_NAME_LAST |
| middleName | Middle name | MiddleName | java.lang.String | PSN_NAME_MIDDLE |
| phone02 | Phone 2 | Phone2 | java.lang.String | PSN_PHONE_02 |
| phone03 | Phone 3 | Phone3 | java.lang.String | PSN_PHONE_03 |
| primaryPhotoOid | Photo | Photo | java.lang.String | PSN_PHO_OID_PRIMARY |
| email01 | Primary email | Email1 | java.lang.String | PSN_EMAIL_01 |
| phone01 | Primary Phone 1 | Phone1 | java.lang.String | PSN_PHONE_01 |
| privateIndicator | Private | Private | boolean | PSN_PRIVATE_IND |
| raceView | Race | Race | java.lang.String | PSN_RACE_VIEW |
| securityCode | Security code | SecurityCode | java.lang.String | PSN_SECURITY_CODE |
| semiprivateIndicator | Semiprivate | Semiprivate | boolean | PSN_SEMIPRIVATE_IND |
| staffIndicator | Staff | Staff | boolean | PSN_STAFF_IND |
| studentIndicator | Student | Student | boolean | PSN_STUDENT_IND |
| nameSuffixCode | Suffix | Suffix | java.lang.String | PSN_NAME_SUFFIX_CODE |
| nameTitleCode | Title | Title | java.lang.String | PSN_NAME_TITLE_CODE |
| useMailAddressIndicator | Use mailing address | UseMailAdrs | boolean | PSN_USE_MAIL_ADDRESS_IND |
| userIndicator | User | User | boolean | PSN_USER_IND |

### STD - Student Records

**Core Student Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| studentNumber | Student Number | java.lang.String | STD_ID_LOCAL |
| nameView | Full Name | java.lang.String | STD_NAME_VIEW |
| gradeLevel | Grade Level | java.lang.String | STD_GRADE_LEVEL |
| yog | Year of Graduation | int | STD_YOG |
| genderCode | Gender | java.lang.String | STD_GENDER_CODE |
| hispanicLatinoIndicator | Hispanic/Latino | boolean | STD_HISPANIC_LATINO_IND |
| raceView | Race | java.lang.String | STD_RACE_VIEW |
| calendarCode | Calendar | java.lang.String | STD_CALENDAR_CODE |
| homeLanguageCode | Home Language | java.lang.String | STD_HOME_LANGUAGE_CODE |
| spedStatusCode | Special Education Status | java.lang.String | STD_SPED_STATUS_CODE |
| section504StatusCode | 504 Status | java.lang.String | STD_504_STATUS |
| ellStatusCode | ELL Status | java.lang.String | STD_ELL_STATUS_CODE |
| enrollmentStatusCode | Enrollment Status | java.lang.String | STD_ENROLLMENT_STATUS |
| stateId | State ID | java.lang.String | STD_ID_STATE |
| lunchStatusCode | Lunch Status | java.lang.String | STD_LUNCH_STATUS_CODE |
| transportationCode | Transportation | java.lang.String | STD_TRANSPORTATION_CODE |
| homeroomCode | Homeroom | java.lang.String | STD_HOMEROOM |
| counselorOid | Counselor OID | java.lang.String | STD_CNS_OID_PRIMARY |
| graduationDate | Graduation Date | java.sql.Date | STD_GRADUATION_DATE |

### STF - Staff Records

**Core Staff Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| nameView | Full Name | java.lang.String | STF_NAME_VIEW |
| localId | Staff ID | java.lang.String | STF_ID_LOCAL |
| stateId | State ID | java.lang.String | STF_ID_STATE |
| hireDate | Hire Date | java.sql.Date | STF_HIRE_DATE |
| statusCode | Status | java.lang.String | STF_STATUS |
| homeroom | Homeroom | java.lang.String | STF_HOMEROOM |
| homeroom2 | Homeroom 2 | java.lang.String | STF_HOMEROOM2 |
| spedIndicator | Special Education | boolean | STF_SPED_IND |
| spedRole | Special Education Role | java.lang.String | STF_SPED_ROLE |
| serviceProviderIndicator | Service Provider | boolean | STF_SERVICE_PROVIDER_IND |
| archived | Is Archived | boolean | STF_ARCHIVED_IND |
| departmentCode | Department | java.lang.String | STF_DEPARTMENT_CODE |
| titleCode | Title | java.lang.String | STF_TITLE_CODE |
| emailAddress | Email | java.lang.String | STF_EMAIL |
| guid | GUID | java.lang.String | STF_GUID |

### ATT - Attendance Records

**Core Attendance Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| date | Attendance Date | java.sql.Date | ATT_DATE |
| portionAbsent | Portion Absent | java.math.BigDecimal | ATT_PORTION_ABSENT |
| absentIndicator | Absent | boolean | ATT_ABSENT_IND |
| tardyIndicator | Tardy | boolean | ATT_TARDY_IND |
| dismissedIndicator | Dismissed Early | boolean | ATT_DISMISSED_IND |
| attendanceCode | Attendance Code | java.lang.String | ATT_CODE |
| reasonCode | Reason Code | java.lang.String | ATT_REASON_CODE |
| excusedIndicator | Excused | boolean | ATT_EXCUSED_IND |
| otherCode | Other Code | java.lang.String | ATT_OTHER_CODE |
| comment | Comment | java.lang.String | ATT_COMMENT |
| periodView | Period | java.lang.String | ATT_PERIOD_VIEW |
| timeIn | Time In | java.sql.Time | ATT_TIME_IN |
| timeOut | Time Out | java.sql.Time | ATT_TIME_OUT |

### RMS - Room and Space Management

**Core Room Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| roomNumber | Room Number | java.lang.String | RMS_ROOM_NUMBER |
| description | Description | java.lang.String | RMS_DESCRIPTION |
| buildingCode | Building | java.lang.String | RMS_BUILDING_CODE |
| departmentCode | Department | java.lang.String | RMS_DEPARTMENT_CODE |
| locationCode | Location Code | java.lang.String | RMS_LOCATION_CODE |
| capacity | Capacity | int | RMS_CAPACITY |
| examIncludeIndicator | Include in Exams | boolean | RMS_EXAM_INCLUDE_IND |
| scheduleIncludeIndicator | Include in Scheduling | boolean | RMS_SCHD_INCLUDE_IND |
| activeIndicator | Active | boolean | RMS_ACTIVE_IND |

### CND - Conduct and Disciplinary Records

**Core Conduct Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| incidentDate | Incident Date | java.sql.Date | CND_INCIDENT_DATE |
| incidentId | Incident ID | java.lang.String | CND_INCIDENT_ID |
| incidentCode | Incident Code | java.lang.String | CND_INCIDENT_CODE |
| actionCode | Action Code | java.lang.String | CND_ACTION_CODE |
| suspensionIndicator | Suspension | boolean | CND_SUSPENSION_IND |
| inSchoolSuspensionIndicator | In-School Suspension | boolean | CND_IN_SCHOOL_SUSPENSION_IND |
| startDate | Start Date | java.sql.Date | CND_START_DATE |
| endDate | End Date | java.sql.Date | CND_END_DATE |
| penaltyDays | Penalty Days | java.math.BigDecimal | CND_PENALTY_TIME |
| comment | Comment | java.lang.String | CND_COMMENT |
| location | Location | java.lang.String | CND_LOCATION |

### TRN - Transportation Records

**Core Transportation Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| transportationCode | Transportation Code | java.lang.String | TRN_TRANSPORTATION_CODE |
| busNumber | Bus Number | java.lang.String | TRN_BUS_NUMBER |
| route | Route | java.lang.String | TRN_ROUTE |
| stopDescription | Stop Description | java.lang.String | TRN_STOP_DESCRIPTION |
| pickupTime | Pickup Time | java.sql.Time | TRN_PICKUP_TIME |
| dropoffTime | Dropoff Time | java.sql.Time | TRN_DROPOFF_TIME |
| distance | Distance | java.math.BigDecimal | TRN_DISTANCE |
| activeIndicator | Active | boolean | TRN_ACTIVE_IND |

### ACT - Activities and Extracurricular

**Core Activity Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| activityCode | Activity Code | java.lang.String | ACT_ACTIVITY_CODE |
| activityName | Activity Name | java.lang.String | ACT_ACTIVITY_NAME |
| description | Description | java.lang.String | ACT_DESCRIPTION |
| categoryCode | Category Code | java.lang.String | ACT_CATEGORY_CODE |
| sponsorName | Sponsor Name | java.lang.String | ACT_SPONSOR_NAME |
| meetingLocation | Meeting Location | java.lang.String | ACT_MEETING_LOCATION |
| meetingTime | Meeting Time | java.lang.String | ACT_MEETING_TIME |
| startDate | Start Date | java.sql.Date | ACT_START_DATE |
| endDate | End Date | java.sql.Date | ACT_END_DATE |
| activeIndicator | Active | boolean | ACT_ACTIVE_IND |

### SFP - Staff Position Records

**Core Staff Position Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| positionCode | Position Code | java.lang.String | SFP_POSITION_CODE |
| jobCode | Job Code | java.lang.String | SFP_JOB_CODE |
| departmentCode | Department Code | java.lang.String | SFP_DEPARTMENT_CODE |
| locationCode | Location Code | java.lang.String | SFP_LOCATION_CODE |
| fte | FTE | java.math.BigDecimal | SFP_FTE |
| startDate | Start Date | java.sql.Date | SFP_START_DATE |
| endDate | End Date | java.sql.Date | SFP_END_DATE |
| salaryAmount | Salary Amount | java.math.BigDecimal | SFP_SALARY_AMOUNT |
| activeIndicator | Active | boolean | SFP_ACTIVE_IND |

### USR - User and Security Records

**Core User Fields:**
| Java Field | Description | Java Type | Database Column |
|------------|-------------|-----------|----------------|
| loginName | Login Name | java.lang.String | USR_LOGIN_NAME |
| emailAddress | Email Address | java.lang.String | USR_EMAIL_ADDRESS |
| enabledIndicator | Enabled | boolean | USR_ENABLED_IND |
| administratorIndicator | Administrator | boolean | USR_ADMINISTRATOR_IND |
| lastLoginDate | Last Login Date | java.sql.Timestamp | USR_LAST_LOGIN_DATE |
| passwordExpirationDate | Password Expiration | java.sql.Date | USR_PASSWORD_EXPIRATION_DATE |
| failedLoginAttempts | Failed Login Attempts | int | USR_FAILED_LOGIN_ATTEMPTS |
| lockedIndicator | Locked | boolean | USR_LOCKED_IND |
| createDate | Create Date | java.sql.Timestamp | USR_CREATE_DATE |
| lastModifiedDate | Last Modified | java.sql.Timestamp | USR_LAST_MODIFIED_DATE |

---

## Scheduling & Grading Period Tables

### GradeTerm and GradeTermDate — Resolving Term Date Ranges

Aspen uses two separate table hierarchies for schedule terms and grade terms. Understanding the distinction is critical when filtering data by grading period.

| Bean | Purpose | Key Fields |
|------|---------|------------|
| `GradeTerm` | Defines grading periods (Q1–Q4, YR) | `gradeTermId` (e.g., "Q1"), `gradeTermNum` (1-based), `oid` |
| `GradeTermDate` | Stores **actual start/end dates** for each grading period | `gradeTermOid`, `startDate`, `endDate` |
| `ScheduleTerm` | Defines schedule terms with bitmap maps | `gradeTermMap` (positional bitmap, e.g., "1000"=Q1) |
| `ScheduleTermDate` | Stores the **schedule-level date range** (full year for all terms) | `startDate`, `endDate` — typically 8/1–7/31 for ALL terms |

**Critical distinction**: `ScheduleTermDate` stores the full schedule year range (e.g., 8/1/2025–7/31/2026) for **every** term — Q1 through YR all share the same dates. To get the actual quarter boundaries (e.g., Q3: 1/21/2026–3/31/2026), you must query `GradeTermDate`.

### gradeTermMap Bitmap Format

The `gradeTermMap` field on `ScheduleTerm` is a positional bitmap string, **not** a comma-separated list of OIDs:

| Code | Name | gradeTermMap |
|------|------|-------------|
| Q1 | Quarter 1 | `1000` |
| Q2 | Quarter 2 | `0100` |
| Q3 | Quarter 3 | `0010` |
| Q4 | Quarter 4 | `0001` |
| YR | Full Year | `1111` |

Reference data files: `BuildResources/GradeTermMap.csv` and `BuildResources/TermMapExpanded.csv`.

### GradeTermDate Query Pattern (Java)

To resolve the actual date range for a specific grading period within a specific school year:

```java
import com.x2dev.sis.model.beans.GradeTerm;
import com.x2dev.sis.model.beans.GradeTermDate;

// m_gradeTerm = selected GradeTerm bean (e.g., Q3)
// m_context = selected DistrictSchoolYearContext

X2Criteria dateCriteria = new X2Criteria();
dateCriteria.addEqualTo(GradeTermDate.COL_GRADE_TERM_OID, m_gradeTerm.getOid());
dateCriteria.addGreaterOrEqualThan(GradeTermDate.COL_START_DATE, m_context.getStartDate());
dateCriteria.addLessOrEqualThan(GradeTermDate.COL_END_DATE, m_context.getEndDate());

QueryByCriteria dateQuery = new QueryByCriteria(GradeTermDate.class, dateCriteria);
Collection<GradeTermDate> termDates = getBroker().getCollectionByQuery(dateQuery);
```

**Important**: GradeTermDate records exist across all school years. Always scope to the selected `DistrictSchoolYearContext` dates to avoid pulling dates from prior years.

> See `05-JAVA-DATASOURCE.md § Resolving Grade Term Dates` for the complete pattern with fallback logic.

---

## Field Naming Conventions

### Standard Field Patterns
- **fieldA001-D100**: Custom fields — district-specific, use DEVResources export to discover mappings
- **xxxIndicator**: Boolean flags (true/false)
- **xxxCode**: Reference codes linking to lookup tables
- **xxxOid**: Object identifiers for foreign key relationships
- **xxxDate**: Date fields (java.sql.Date)
- **xxxTimestamp**: Timestamp fields with time component
- **nameView**: Computed full names (read-only)
- **xxxView**: Computed/calculated fields (read-only)

### Common Relationship Patterns
```java
// Student to Person relationship
student.getPerson().getFirstName()

// Using PATH_DELIMITER for complex relationships
StudentSection.REL_STUDENT + PATH_DELIMITER + SisStudent.REL_PERSON + PATH_DELIMITER + SisPerson.COL_FIRST_NAME

// Reference code lookups
student.getGradeLevel() // Returns code
student.getGradeLevelReference().getDescription() // Returns description
```

### Essential Field Mappings by Table (Java Constant → DB Column)
```java
// PERSON Table (PSN prefix)
SisPerson.COL_PERSON_ID          -> "PSN_PERSON_ID"
SisPerson.COL_NAME_FIRST         -> "PSN_NAME_FIRST"
SisPerson.COL_NAME_LAST          -> "PSN_NAME_LAST"
SisPerson.COL_DOB                -> "PSN_DOB"
SisPerson.COL_STUDENT_INDICATOR  -> "PSN_STUDENT_IND"
SisPerson.COL_STAFF_INDICATOR    -> "PSN_STAFF_IND"

// STUDENT Table (STD prefix)
SisStudent.COL_YOG               -> "STD_YOG"
SisStudent.COL_GRADE_LEVEL       -> "STD_GRADE_LEVEL"
SisStudent.COL_ENROLLMENT_STATUS -> "STD_ENROLLMENT_STATUS"

// STAFF Table (STF prefix)
SisStaff.COL_DEPARTMENT_CODE     -> "STF_DEPARTMENT_CODE"
SisStaff.COL_BARGAINING_UNIT     -> "STF_BARGAINING_UNIT"
SisStaff.COL_CALENDAR_ID         -> "STF_CALENDAR_ID"

// ATTENDANCE Table (ATT prefix)
StudentAttendance.COL_DATE       -> "ATT_DATE"
StudentAttendance.COL_ABSENT_INDICATOR -> "ATT_ABSENT_IND"
StudentAttendance.COL_TARDY_INDICATOR  -> "ATT_TARDY_IND"
StudentAttendance.COL_EXCUSED_INDICATOR -> "ATT_EXCUSED_IND"

// ROOM Table (RMS prefix)
SchoolRoom.COL_ROOM_NUMBER       -> "RMS_ROOM_NUMBER"
SchoolRoom.COL_BUILDING_CODE     -> "RMS_BUILDING_CODE"
SchoolRoom.COL_MAX_CAPACITY      -> "RMS_MAX_CAPACITY"
```

### Custom Field Access Pattern
```java
// Custom fields follow the pattern: TableClass.COL_FIELD_X### -> "TBL_FIELDX_###"
// Example: SisStudent.COL_FIELD_A001 -> "STD_FIELDA_001"
// Run the DEVResources schema export to discover what each field means in your district.
```

### Usage Tips
1. **Always use Java field names** in criteria and data source methods
2. **Database column names** are for reference and direct SQL queries only
3. **Custom fields (fieldA001-D100)** are district-specific — run the DEVResources export to see mappings
4. **Indicator fields** are boolean and should be checked with Boolean.TRUE/FALSE
5. **Date fields** use java.sql.Date, not java.util.Date
6. **OID fields** are String type object identifiers for relationships
7. **View fields** are computed and typically read-only
