# Aspen Report Generation — Input Definition Structure

---

## Basic XML Structure
```xml
<tool-input allow-school-select="true" district-support="false" context="com.x2dev.sis.model.beans.Section">
    <!-- SELECT OPTIONS -->
    <input name="queryBy" data-type="integer" display-type="select" display-name="report.schedule.query">
        <option value="5" display-name="report.shared.query.currentSelection" context-dependent="true"/>
        <option value="0" display-name="report.shared.query.all"/>
        <!-- Additional options -->
    </input>

    <!-- TEXT INPUT -->
    <input name="queryString" data-type="string" display-type="text" display-name="report.shared.queryString" />

    <!-- CHECKBOX -->
    <input name="includeStudyClass" data-type="boolean" display-type="checkbox" display-name="report.shared.includeStudyClass" default-value="false"/>

    <!-- SORT OPTIONS -->
    <input name="sort" data-type="string" display-type="select" display-name="report.shared.sort">
        <option value="section.courseView, student.nameView, student.yog" display-name="report.schedule.sort.course"/>
        <!-- Additional sort options -->
    </input>
</tool-input>
```

---

## Input Types and Attributes
- **data-type**: `integer`, `string`, `boolean`, `date`
- **display-type**: `select`, `text`, `checkbox`, `date`
- **display-name**: Localization key for UI labels
- **default-value**: Default parameter value (`"today"` is valid for date inputs)
- **context-dependent**: Links to current user context

### Date Input Example
```xml
<input name="startDate" data-type="date" display-type="date"
       display-name="report.shared.startDate" default-value="today"/>
```

---

## Conditional Logic

### Disabling inputs based on parent selection
```xml
<disable input-name="queryString" if-parent-equals="5" />
<disable input-name="queryString" if-parent-equals="0" />
```

### Using a checkbox to disable/override another input

A checkbox can disable a picklist or other input, acting as an override toggle. The `<disable>` element goes inside the checkbox input and references the target input by name:

```xml
<!-- Checkbox disables the grade term picklist when checked -->
<input name="fullYear" data-type="boolean" display-type="checkbox"
       display-name="Full Year" default-value="false">
  <disable input-name="gradeTermOid" if-parent-equals="true" />
</input>

<input name="gradeTermOid" data-type="string" display-type="picklist"
       display-name="report.shared.term" default-value="currentGradeTerm">
  <picklist field-id="gtmGrdTermID">
    <field id="gtmGrdTermID" sort="true" />
    <field id="gtmGrdTermNum" />
    <filter field="relGtmGtaOid.gtaSklOID" operator="equals" source="session" value="school.oid" />
    <filter field="relGtmGtaOid.gtaCtxOID" operator="equals" source="input" value="contextOid" />
  </picklist>
</input>
```

In the Java data source, check the boolean parameter (with null safety) before reading the disabled input:
```java
Boolean fullYear = (Boolean) getParameter(FULL_YEAR_PARAM);
if (fullYear == null || !fullYear.booleanValue())
{
    // Read the picklist value only when checkbox is unchecked
    String gradeTermOid = (String) getParameter(GRADE_TERM_OID_PARAM);
    if (!StringUtils.isEmpty(gradeTermOid))
    {
        m_gradeTerm = (GradeTerm) getBroker().getBeanByOid(GradeTerm.class, gradeTermOid);
    }
}
```

**Note**: When a picklist input is disabled by a checkbox, Aspen may still pass the picklist's last-selected value. Always check the checkbox parameter first in Java to determine whether to use the picklist value.

### Picklist inputs

Picklist inputs query Aspen beans and display results in a dropdown. They support filtering and sorting:

```xml
<input name="gradeTermOid" data-type="string" display-type="picklist"
       display-name="report.shared.term" default-value="currentGradeTerm">
  <picklist field-id="gtmGrdTermID">
    <field id="gtmGrdTermID" sort="true" />
    <field id="gtmGrdTermNum" />
    <filter field="relGtmGtaOid.gtaSklOID" operator="equals" source="session" value="school.oid" />
    <filter field="relGtmGtaOid.gtaCtxOID" operator="equals" source="input" value="contextOid" />
  </picklist>
</input>
```

**Key attributes:**
- `field-id` — the bean field used as the picklist value (OID)
- `<field>` — columns displayed in the dropdown; `sort="true"` sorts by that column
- `<filter>` — restricts which records appear; `source="session"` reads from the user session, `source="input"` reads from another input parameter
- `default-value="currentGradeTerm"` — Aspen resolves this to the current active grade term

**Important**: The grade term picklist filters by `GradeTermAssociation` records (`relGtmGtaOid`). Only grade terms that have an association record for the selected school and context will appear. This is why "YR" (Full Year) may not show in the dropdown — it may lack a `GradeTermAssociation` record. Use a "Full Year" checkbox as an override (see pattern above).

### Hiding inputs based on user context
Use `<condition action="hide">` to hide inputs entirely for certain application contexts (e.g., hide admin-only filters from staff view, since staff view auto-scopes to the current teacher/section):
```xml
<input name="queryBy" data-type="integer" display-type="select" display-name="report.shared.query.masterSchedule">
  <condition action="hide" expression="getSessionNavConfig().getApplicationContext().equals(ApplicationContext.STAFF)" />
  <option value="3" display-name="report.shared.query.currentSelection" context-dependent="true" />
  <option value="0" display-name="report.shared.query.all"/>
  <option value="1" display-name="report.shared.query.teacherName"/>
</input>
<input name="queryString" data-type="string" display-type="text" display-name="report.shared.queryString">
  <condition action="hide" expression="getSessionNavConfig().getApplicationContext().equals(ApplicationContext.STAFF)" />
</input>
```
`hide` removes the input from the UI entirely; `disable` keeps it visible but greyed out.

---

## When to Omit the Input Definition

The Input Definition file can be omitted entirely for reports that run from a **current record context** (e.g., a report launched directly from a student's 504 plan record). In these cases, the report receives its data through `userData.getCurrentRecord()` in the Java data source rather than through user-configurable parameters.

See Example 2 in `Report Examples/` for a complete report that uses no Input Definition.

---

## `context` Attribute on `<tool-input>`

The `context` attribute declares the primary bean type the report operates on. Common values:
- `com.x2dev.sis.model.beans.Section` — for schedule/class-based reports
- `com.x2dev.sis.model.beans.SisStaff` — for attendance input reports that query by homeroom or teacher
- Omit entirely for reports that run from a current record context with no input form
