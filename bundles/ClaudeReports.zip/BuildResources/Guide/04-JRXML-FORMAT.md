# Aspen Report Generation — JasperReports Format Definition (JRXML)

---

## JRXML Format Versions: DTD vs XSD Schema

JRXML files can use two different XML validation formats. Both are supported by Aspen:

- **DTD format (older)**: Uses a `<!DOCTYPE jasperReport ...>` declaration at the top. Examples 1 and 2 in the `Report Examples/` folder use this format. This is the JasperReports 5.5.0-era format.
- **XSD Schema format (newer)**: Uses an `xmlns` namespace declaration on the `<jasperReport>` element (e.g., `xmlns="http://jasperreports.sourceforge.net/jasperreports"`). Example 3 uses this format. This is the JasperReports 6.x-era format.

**Guidance**: For new reports targeting JasperReports 6.19.1 (the primary Aspen engine), either format works — the XSD schema format is preferred for new development. When modifying an existing report, match the format it already uses.

---

## JRXML Structure
```xml
<?xml version="1.0" encoding="UTF-8"?>
<jasperReport
    name="ReportName"
    columnCount="1"
    printOrder="Vertical"
    orientation="Portrait"
    pageWidth="595"
    pageHeight="842"
    columnWidth="535"
    leftMargin="30"
    rightMargin="30"
    topMargin="20"
    bottomMargin="20">

    <!-- Parameters -->
    <parameter name="school" class="com.x2dev.sis.model.beans.SisSchool"/>
    <parameter name="organization" class="com.follett.fsc.core.k12.beans.Organization"/>

    <!-- Fields -->
    <field name="student" class="com.x2dev.sis.model.beans.SisStudent"/>
    <field name="section" class="com.x2dev.sis.model.beans.Section"/>

    <!-- Variables -->
    <variable name="studentCount" class="java.lang.Integer" resetType="Group" resetGroup="section" calculation="Count"/>

    <!-- Report Sections -->
    <pageHeader><!-- Header content --></pageHeader>
    <groupHeader><!-- Group header content --></groupHeader>
    <detail><!-- Detail row content --></detail>
    <groupFooter><!-- Group footer content --></groupFooter>
</jasperReport>
```

---

## Key Report Bands
- **pageHeader**: Appears at top of each page
- **groupHeader**: Appears when group value changes
- **detail**: Repeated for each data row
- **groupFooter**: Appears at end of each group
- **pageFooter**: Appears at bottom of each page

---

## Field Expressions
```xml
<!-- Student name display -->
<textFieldExpression class="java.lang.String">
    <![CDATA[$F{student}.getNameView()]]>
</textFieldExpression>

<!-- Course and description -->
<textFieldExpression class="java.lang.String">
    <![CDATA[$F{section}.getCourseView() + ($F{section}.getDescription() == null ? "" : ": " + $F{section}.getDescription())]]>
</textFieldExpression>

<!-- Complex conditional expressions -->
<textFieldExpression class="java.lang.String">
    <![CDATA[!StringUtils.isEmpty($F{student.person.physicalAddress.addressLine02}) ?
             $F{student.person.physicalAddress.addressLine02} :
             $F{student.person.physicalAddress.addressLine03}]]>
</textFieldExpression>

<!-- Organization name with alternate name -->
<textFieldExpression class="java.lang.String">
    <![CDATA[$P{organization}.getName() +
             (StringUtils.isEmpty($F{a:student.school.organization1.alternate-name}) ?
              "" : (", " + $F{a:student.school.organization1.alternate-name}))]]>
</textFieldExpression>
```

---

## Advanced JRXML Features

### 1. Multiple Report Groups
```xml
<!-- Section 504 Plan uses 8 different groups for sectioned content -->
<group name="1">
    <groupExpression><![CDATA["Group 1"]]></groupExpression>
    <groupHeader><band height="0"/></groupHeader>
    <groupFooter>
        <!-- Other Accommodations section -->
    </groupFooter>
</group>

<group name="2">
    <groupExpression><![CDATA["Group 2"]]></groupExpression>
    <groupFooter>
        <!-- Accommodations table with subreport -->
        <subreport isUsingCache="true">
            <dataSourceExpression><![CDATA[$P{accCatData}]]></dataSourceExpression>
            <subreportExpression class="java.io.InputStream">
                <![CDATA[$P{accCatFormat}]]>
            </subreportExpression>
        </subreport>
    </groupFooter>
</group>
```

### 2. Conditional Printing
```xml
<!-- Print section only if data exists -->
<staticText>
    <reportElement key="staticText-50">
        <printWhenExpression>
            <![CDATA[new Boolean(!StringUtils.isEmpty($F{a:504-other-accommodations}) &&
                                $P{hasAccommodationsInTable}.booleanValue())]]>
        </printWhenExpression>
    </reportElement>
    <text><![CDATA[Other Accommodations]]></text>
</staticText>
```

### 3. Subreport Integration
```xml
<subreport isUsingCache="true">
    <reportElement x="15" y="20" width="507" height="40"/>
    <parametersMapExpression><![CDATA[$P{REPORT_PARAMETERS_MAP}]]></parametersMapExpression>

    <!-- Pass specific parameters to subreport -->
    <subreportParameter name="accData">
        <subreportParameterExpression><![CDATA[$P{accByCat}]]></subreportParameterExpression>
    </subreportParameter>

    <!-- Data source for subreport -->
    <dataSourceExpression><![CDATA[$P{evalData}]]></dataSourceExpression>

    <!-- Subreport format from parameter -->
    <subreportExpression class="java.io.InputStream">
        <![CDATA[$P{evalFormat}]]>
    </subreportExpression>
</subreport>
```

### 4. Complex Field References
```xml
<!-- Accessing nested object properties -->
<field name="student.primaryContact.contact.nameView" class="java.lang.String"/>
<field name="student.person.physicalAddress.addressLine02" class="java.lang.String"/>

<!-- Custom alias fields (using 'a:' prefix) -->
<field name="a:student.school.organization1.alternate-name" class="java.lang.String"/>
<field name="a:504-meeting-summary" class="java.lang.String"/>
<field name="a:504-disability-effect" class="java.lang.String"/>
```

### 5. Advanced Text Formatting
```xml
<textField isStretchWithOverflow="true" isBlankWhenNull="true"
           evaluationTime="Now" isPrintWhenDetailOverflows="true">
    <reportElement x="14" y="24" width="507" height="40"/>
    <textElement verticalAlignment="Top">
        <font pdfFontName="Helvetica" isBold="false"/>
    </textElement>
    <textFieldExpression class="java.lang.String">
        <![CDATA[$F{a:504-student-history-eval}]]>
    </textFieldExpression>
</textField>
```

### 6. Page Layout Features
```xml
<!-- Last page footer with signature lines -->
<lastPageFooter>
    <band height="186">
        <rectangle>
            <reportElement x="6" y="5" width="529" height="154"/>
            <graphicElement>
                <pen lineWidth="0.25" lineStyle="Solid"/>
            </graphicElement>
        </rectangle>

        <!-- Signature lines -->
        <line direction="TopDown">
            <reportElement x="14" y="41" width="338" height="0"/>
        </line>

        <staticText>
            <text><![CDATA[Signature of Parent, Guardian, or Student (if 18 years or older)]]></text>
        </staticText>
    </band>
</lastPageFooter>
```

### 7. SubDataset Definitions
```xml
<!-- Define reusable data structures -->
<subDataset name="SubDataset1">
    <!-- Field definitions for subreports -->
</subDataset>
```

---

## Field Definition Best Practices

Prefer explicit field definitions over direct method calls in expressions — dot notation maps to getter methods automatically and is safer:

```xml
<!-- Define fields at the top of the JRXML -->
<field name="section.roomView" class="java.lang.String"/>
<field name="section.primaryPeriodView" class="java.lang.String"/>
<field name="student.nameView" class="java.lang.String"/>
<field name="student.person.primaryPhotoOid" class="java.lang.String"/>

<!-- Then reference them in expressions -->
<textFieldExpression class="java.lang.String">
    <![CDATA["Room: " + ($F{section.roomView} != null ? $F{section.roomView} : "TBD")]]>
</textFieldExpression>
```

**Common field definition patterns:**
```xml
<!-- Basic object fields -->
<field name="student" class="com.x2dev.sis.model.beans.SisStudent"/>
<field name="section" class="com.x2dev.sis.model.beans.Section"/>

<!-- Direct property access -->
<field name="student.gradeLevel" class="java.lang.String"/>
<field name="student.yog" class="java.lang.Integer"/>

<!-- View method access -->
<field name="student.nameView" class="java.lang.String"/>
<field name="section.courseView" class="java.lang.String"/>

<!-- Nested object navigation -->
<field name="student.person.firstName" class="java.lang.String"/>
<field name="student.person.primaryPhotoOid" class="java.lang.String"/>
<field name="section.primaryStaff.nameView" class="java.lang.String"/>
```

### Standard Aspen-Provided Parameters

These parameters are automatically injected by Aspen into every report — declare them in JRXML but do not add them to the Input Definition:

```xml
<parameter name="school" class="com.x2dev.sis.model.beans.SisSchool"/>
<parameter name="organization" class="com.follett.fsc.core.k12.beans.Organization"/>
<parameter name="schoolContext" class="java.lang.Boolean"/>
<parameter name="currentContext" class="com.follett.fsc.core.k12.beans.DistrictSchoolYearContext" isForPrompting="false"/>
<parameter name="longDateFormat" class="java.text.DateFormat"/>
<parameter name="shortDateFormat" class="java.text.DateFormat"/>
```

- **`schoolContext`** — `true` when running from a single school, `false` in district view. Use to conditionally show/hide the school name in headers.
- **`longDateFormat` / `shortDateFormat`** — pre-configured formatters; use for consistent date display rather than formatting dates manually.
- **`currentContext`** — the active school year; used with `StudentContextAttributesManager` for multi-year-aware queries.

**Conditional school name display (common page header pattern):**
```xml
<!-- Show school name only in school context -->
<textField>
    <reportElement>
        <printWhenExpression><![CDATA[$P{schoolContext}]]></printWhenExpression>
    </reportElement>
    <textFieldExpression><![CDATA[$P{school}.getName()]]></textFieldExpression>
</textField>

<!-- Show school ID + name in district-wide runs (inside school group header) -->
<textField evaluationTime="Group" evaluationGroup="school">
    <reportElement>
        <printWhenExpression><![CDATA[new Boolean(!$P{schoolContext}.booleanValue())]]></printWhenExpression>
    </reportElement>
    <textFieldExpression><![CDATA[$V{school}.getSchoolId() + " - " + $V{school}.getName()]]></textFieldExpression>
</textField>
```

### Alternating Row Shading (Zebra Stripe)
```xml
<detail>
    <band height="75">
        <rectangle>
            <reportElement mode="Opaque" x="3" y="0" width="530" height="74" backcolor="#EEF4FB">
                <printWhenExpression><![CDATA[$V{REPORT_COUNT} % 2 == 0]]></printWhenExpression>
            </reportElement>
            <graphicElement><pen lineWidth="0.0"/></graphicElement>
        </rectangle>
        <!-- row content -->
    </band>
</detail>
```
`$V{REPORT_COUNT}` is a built-in JasperReports variable that increments for each detail row. Even rows get the shaded background; odd rows are white.

### Group Header Field Evaluation
Fields rendered inside a group header must use `evaluationTime="Group"` and `evaluationGroup="groupName"` to ensure they display the current group's value (not the previous row's):
```xml
<textField evaluationTime="Group" evaluationGroup="section" isBlankWhenNull="false">
    <reportElement printWhenGroupChanges="section" .../>
    <textFieldExpression><![CDATA["Teacher: " + ($F{section.primaryStaff} != null ? $F{section.primaryStaff}.getNameView() : "")]]></textFieldExpression>
</textField>
```

### Nested Group Hierarchy (School → Section/Homeroom)
For district-wide reports that break by school then by sub-group, use nested groups. The outer group handles the school page break; the inner group handles per-section or per-homeroom pages:
```xml
<!-- Outer: one new page per school (hidden in school context) -->
<group name="school" isStartNewPage="true" isResetPageNumber="true" isReprintHeaderOnEachPage="true">
    <groupExpression><![CDATA[$F{section.schoolCourse.school} != null ? $F{section.schoolCourse.school}.getName() : ""]]></groupExpression>
    <groupHeader>
        <band height="17">
            <!-- school name label, only visible in district context -->
        </band>
    </groupHeader>
    <groupFooter><band splitType="Stretch"/></groupFooter>
</group>

<!-- Inner: one new page per section or homeroom -->
<group name="section" isStartNewPage="true" isResetPageNumber="true" isReprintHeaderOnEachPage="true">
    <groupExpression><![CDATA[$F{section.oid}]]></groupExpression>
    <groupHeader>
        <!-- column headers, section info -->
    </groupHeader>
    <groupFooter>
        <!-- totals row (Male/Female/Non-Binary/Total counts) -->
    </groupFooter>
</group>
```

### Date Arithmetic in Expressions
To auto-populate weekday column dates from a Monday start date (millisecond offset):
```xml
<!-- Monday -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime()))]]></textFieldExpression>
<!-- Tuesday (+1 day) -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime() + 60*1000*60*24))]]></textFieldExpression>
<!-- Wednesday (+2 days) -->
<textFieldExpression><![CDATA[$P{shortDateFormat}.format(new java.sql.Date($P{startDate}.getTime() + 60*1000*60*24*2))]]></textFieldExpression>
```

### Photo Loading

The confirmed working approach for student photos is to read the photo blob bytes directly via `getPrimaryPhoto().getPhoto()` with a full null-chain guard, wrapped in a `ByteArrayInputStream`. Use `onErrorType="Blank"` on the image element so missing photos render as blank rather than throwing an error:

```xml
<image onErrorType="Blank">
    <reportElement x="3" y="2" width="65" height="70"/>
    <imageExpression><![CDATA[$F{student.person} != null
        && $F{student.person}.getPrimaryPhoto() != null
        && $F{student.person}.getPrimaryPhoto().getPhoto() != null
        ? new java.io.ByteArrayInputStream($F{student.person}.getPrimaryPhoto().getPhoto())
        : null]]></imageExpression>
</image>
```

When the data source bean is the student directly (not a join bean), the field reference shortens:
```xml
<imageExpression><![CDATA[new ByteArrayInputStream($F{person}.getPrimaryPhoto().getPhoto())]]></imageExpression>
```
Note: this shorter form assumes `person` and `primaryPhoto` are non-null; add null checks if students without photos are possible.

The `repo:` prefix approach (documented in `07-TROUBLESHOOTING.md` issue #19) applies when you only have the photo OID string available — the `ByteArrayInputStream` approach is preferred when you have direct bean access.

---

## Cross-References

- **Field naming and database lookups** → `02-DATABASE-SCHEMA.md`
- **Java data source patterns (how data reaches the JRXML)** → `05-JAVA-DATASOURCE.md § End-to-End Field Mapping`
- **Photo troubleshooting** → `07-TROUBLESHOOTING.md` (issues #19-20)
- **Quick pattern lookup** → `08-QUICK-REFERENCE.md`
