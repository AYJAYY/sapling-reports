# Aspen Report Generation — Best Practices, Advanced Features & Resources

---

## Report Development Process

### Step 1: Define Input Parameters
Create input definition XML with user-configurable options:
- Query filters (dropdown selections)
- Text input fields
- Boolean checkboxes
- Sort options

### Step 2: Design Report Layout
Create JRXML format definition with:
- Page setup and dimensions
- Report bands (header, detail, footer, etc.)
- Data fields and formatting
- Grouping and sorting specifications

### Step 3: Implement Data Source

**For Reports (PDF):** Create Java class extending `ReportJavaSourceNet`:
- Override `gatherData()` to return `JRDataSource`
- Build database criteria and execute queries

**For Exports (CSV):** Create Java class extending `ExportJavaSource`:
- Override `gatherData()` to return `DataGrid`
- Override `getColumnNames()`, `getColumnUserNames()`, `getComment()`, `getHeader()`
- Override `getCustomFileName()` for `.csv` extension
- Call `setIncludeHeaderRow(true)`, `setValueDelimiter(',')`, `setValueWrapper('"')` in `initialize()`
- See `05-JAVA-DATASOURCE.md § CSV Export Data Source` for full pattern

### Step 4: Testing and Deployment
- Test with sample data
- Validate parameter handling
- Check formatting across different outputs
- Test multi-engine compatibility (JasperReports 5.5 vs 6.19)
- Validate document saving functionality if enabled
- Deploy to Aspen system

---

## Best Practices

### Database Access
1. **Use Criteria Objects**: Build queries with X2Criteria for type safety
2. **Relationship Traversal**: Use PATH_DELIMITER for joining related tables
3. **Parameter Validation**: Always validate input parameters
4. **Security Filtering**: Implement proper access controls based on user context

### Performance Optimization
1. **Efficient Queries**: Minimize database calls and use appropriate indexes
2. **Data Filtering**: Apply filters at the database level, not in Java
3. **Grouping Strategy**: Use report grouping instead of multiple queries
4. **Caching**: Leverage report helper classes for common operations

### Code Organization
1. **Constants**: Define parameter and field names as constants
2. **Separation of Concerns**: Keep data logic separate from presentation
3. **Error Handling**: Implement proper exception handling

### UI Design
1. **User-Friendly Parameters**: Provide clear labels and reasonable defaults
2. **Conditional Inputs**: Use disable conditions to simplify interface
3. **Validation**: Validate parameters before query execution
4. **Localization**: Use display-name keys for internationalization

---

## Advanced Features Summary

### Level 4: Enterprise IEP Forms
The most sophisticated reports in Aspen X2 SIS demonstrate enterprise-level patterns:

**Multi-Engine Support**:
- JasperReports 5.5.0 and 6.19 compatibility
- Runtime engine detection and appropriate class loading
- Dual export pipelines for different engine versions

**Advanced Data Sources**:
- Custom data source classes extending BeanCollectionDataSource
- Broker-enabled field value resolution
- Complex goal and service data processing

**Document Management**:
- Automatic document saving to student records
- PDF generation with metadata
- File naming conventions with student identification
- Document type and category management

**Complex Form Processing**:
- Multi-section IEP forms with conditional content
- Accommodation categorization and area mapping
- Service frequency and duration calculations
- Grade level and age calculations based on IEP dates

**State Management**:
- Details view vs. blank form handling
- Form storage initialization patterns
- Dynamic form definition loading

**Performance Optimizations**:
- Reference code preloading and caching
- Efficient accommodation processing
- Memory management for large form datasets

---

## Resources

### Version Information
- **Aspen Version**: 6.9.x
- **JasperReports Engine**: 6.19.1 (the bundled engine for this Aspen instance — target this for all new reports)
- **Legacy Engine**: 5.5.0 (only needed for Level 4 multi-engine forms that must support both engines simultaneously)

### Official Documentation
- **Aspen Report Administration Help**: https://ma-beverly.myfollett.com/aspen/help/Content/System_Administration/Reports.htm
- **JasperReports Community**: https://community.jaspersoft.com/project/jasperreports-library
- **JasperReports Documentation**: https://jasperreports.sourceforge.net/

### Development Tools
- **Jaspersoft Studio**: Eclipse-based report development environment — use this for JasperReports 6.x (the engine used by this Aspen instance)
- **iReport Designer**: Legacy visual designer for JasperReports 5.x only — do not use for new reports
- **Aspen System Administration**: Built-in report management, compilation, and testing tools

### Support Resources
- **Follett Community Forums**: Weekly webinars and support calls
- **Aspen Answers**: Biweekly calls with product management
- **Technical Support**: Direct support for custom development issues
