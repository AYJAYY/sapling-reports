# Aspen Report Generation — Troubleshooting

---

## Common Issues

### 1. Parameter Not Found
```java
// Problem: Parameter returns null
Object param = getParameter("paramName");

// Solution: Check input definition XML
<input name="paramName" data-type="string" display-type="text"/>
```

### 2. Relationship Path Errors
```java
// Problem: Invalid path to related data
criteria.addEqualTo("section.primaryStaff.name", teacherName);

// Solution: Use proper PATH_DELIMITER syntax
criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER +
                   Section.REL_PRIMARY_STAFF + PATH_DELIMITER +
                   SisStaff.COL_NAME_VIEW, teacherName);
```

### 3. Report Shows No Data
- Verify database criteria matches expected data
- Check security filters aren't overly restrictive
- Ensure proper table relationships in query
- Validate parameter values are correctly passed

### 4. Format Issues
- Check JRXML field types match data source types
- Verify band heights accommodate content
- Ensure proper grouping configuration
- Test with different data volumes

### 5. Subreport Issues
```java
// Problem: Subreport not displaying data
Report subreport = ReportUtils.getReport(SUBREPORT_ID, getBroker());
if (subreport == null) {
    // Subreport ID not found in system
}

// Solution: Verify subreport ID exists and is accessible
// Check that subreport has proper data source parameter
addParameter(PARAM_SUBREPORT_DATA,
    new BeanCollectionDataSource(collection, dictionary, getLocale()));
```

### 6. Reference Code Problems
```java
// Problem: Reference codes not found
Collection<ReferenceCode> codes = getBroker().getCollectionByQuery(query);
if (codes.isEmpty()) {
    // Reference table may not exist or have no active codes
}

// Solution: Verify reference table OID and check active status
Criteria criteria = ReferenceManager.getCodesCriteria(
    REFERENCE_TABLE_OID, getOwnableCriteria(),
    true,  // include enabled codes
    true,  // include disabled codes if needed
    false, // don't include deleted codes
    getBroker().getPersistenceKey());
```

### 7. Complex Field Expression Errors
```java
// Problem: Nested field access returns null
$F{student.primaryContact.contact.nameView}

// Solution: Add null checks in JRXML expressions
<textFieldExpression class="java.lang.String">
    <![CDATA[($F{student.primaryContact} != null &&
              $F{student.primaryContact.contact} != null) ?
             $F{student.primaryContact.contact.nameView} : ""]]>
</textFieldExpression>
```

### 8. Parameter Type Mismatches
```java
// Problem: Parameter type mismatch between Java and JRXML
addParameter("booleanParam", "true"); // Wrong - passing String

// Solution: Use correct parameter types
addParameter("booleanParam", Boolean.TRUE); // Correct - passing Boolean
addParameter("collectionParam", dataSourceCollection); // Use proper data source
```

### 9. Multi-Engine Compatibility Issues
```java
// Problem: Report fails with different JasperReports versions
// Wrong - hardcoded to single engine
net.sf.jasperreports5.engine.JRDataSource dataSource =
    new net.sf.jasperreports5.engine.JREmptyDataSource();

// Solution: Check engine version and use appropriate classes
Report report = (Report) getJob().getTool();
if (Report.REPORT_ENGINE_5_RELEASE.equals(report.getEngineVersion())) {
    data = new net.sf.jasperreports5.engine.JREmptyDataSource(0);
    return new net.sf.jasperreports5.engine.data.JRMapCollectionDataSource(list);
} else if (Report.REPORT_ENGINE_6_RELEASE.equals(report.getEngineVersion())) {
    data = new net.sf.jasperreports6.engine.JREmptyDataSource(0);
    return new net.sf.jasperreports6.engine.data.JRMapCollectionDataSource(list);
}
```

### 10. Document Saving Failures
```java
// Problem: Document saving fails without proper error handling
// Solution: Validate file creation and document metadata
if (m_saveToDocumentsResultFile.isFile()) {
    Student student = ((IepData) owner).getStudent();
    if (student != null) {
        com.follett.fsc.core.k12.beans.Document document =
            createDocumentIEP(true, student.getPerson(), student,
                              student.getSchool(), m_saveToDocumentsResultFile);
        getBroker().saveBeanForced(document);
    }
    m_saveToDocumentsResultFile.delete();
}
```

### 11. Custom Data Source Issues
```java
// Problem: Custom data source classes not properly extending base classes
public class GoalDataSource extends BeanCollectionDataSource {
    private X2Broker m_broker;

    public GoalDataSource(Collection<IepGoal> goals, DataDictionary dictionary, Locale locale) {
        super(goals, dictionary, locale);
    }

    // Override methods must call super and handle broker properly
    @Override
    protected Object getFieldValue(String fieldName) throws X2BaseException {
        if ("objectivesView".equals(fieldName)) {
            return ((IepGoal) getCurrentBean()).getObjectivesView(m_broker);
        }
        return super.getFieldValue(fieldName); // Important: call super
    }
}
```

### 12. Form Storage and State Management Issues
```java
// Problem: Form storage not properly initialized for different contexts
@Override
public X2BaseBean getFormStorage() {
    X2BaseBean storage = null;
    if (m_isDetailsView) {
        // Use existing IEP data for details view
        storage = getFormOwner();
    } else {
        // Use new/blank storage for form creation
        storage = super.getFormStorage();
    }
    return storage;
}

// Check if form is blank to avoid processing empty data
@Override
public boolean isBlank() {
    return getFormStorage().getOid() == null;
}
```

---

## JRXML Compilation Errors

### 13. Invalid Attributes on Elements

**Problem: SAXParseException with invalid attributes**
```
org.xml.sax.SAXParseException; cvc-complex-type.3.2.2:
Attribute 'isBlankWhenNull' is not allowed to appear in element 'image'.
```

**Solution: Use correct attributes for each element type**
```xml
<!-- Wrong - isBlankWhenNull not valid for image elements -->
<image isBlankWhenNull="true">
    <imageExpression>...</imageExpression>
</image>

<!-- Correct - handle null images in expression -->
<image>
    <imageExpression class="java.lang.String">
        <![CDATA[$F{photoOid} != null ? "/path/" + $F{photoOid} : null]]>
    </imageExpression>
</image>
```

### 14. Invalid Variable References in Attributes

**Problem: Variable expressions in reportElement attributes**
```
org.xml.sax.SAXParseException; cvc-datatype-valid.1.2.1:
'$V{photoWidth}' is not a valid value for 'NMTOKEN'.
```

**Solution: Use static values in reportElement attributes**
```xml
<!-- Wrong - dynamic variables in attributes -->
<reportElement x="25" y="25" width="$V{photoWidth}" height="$V{photoHeight}"/>

<!-- Correct - use static values -->
<reportElement x="25" y="25" width="150" height="180"/>
```

**Alternative: Use conditional logic with static sizes**
```xml
<image>
    <reportElement x="25" y="25" width="100" height="120">
        <printWhenExpression>
            <![CDATA[$P{photoSize}.equals("small")]]>
        </printWhenExpression>
    </reportElement>
</image>

<image>
    <reportElement x="25" y="25" width="150" height="180">
        <printWhenExpression>
            <![CDATA[$P{photoSize}.equals("medium")]]>
        </printWhenExpression>
    </reportElement>
</image>
```

### 15. Band Height Validation Errors

**Problem: Elements extending beyond band boundaries**
```
Report design not valid: Element bottom reaches outside band area:
y=25 height=180 band-height=200
```

**Solution: Ensure band height accommodates all elements**
```xml
<!-- Wrong - insufficient band height -->
<detail>
    <band height="200">
        <image>
            <reportElement x="25" y="25" width="150" height="180"/>
            <!-- Bottom edge: 25 + 180 = 205 > 200 band height -->
        </image>
    </band>
</detail>

<!-- Correct - adequate band height with buffer -->
<detail>
    <band height="220">
        <image>
            <reportElement x="25" y="25" width="150" height="180"/>
            <!-- Bottom edge: 25 + 180 = 205 < 220 band height -->
        </image>
    </band>
</detail>
```

**Band Height Calculation:**
```
Required Band Height = Max(Element Y + Element Height) + Buffer
Buffer = 10-20px recommended for proper spacing
```

### 16. Method Resolution Errors in Field Expressions

**Problem: Cannot find symbol errors during report compilation**
```
error: cannot find symbol
symbol: method getRoom()
location: interface com.x2dev.sis.model.beans.Section

error: cannot find symbol
symbol: method getPrimaryPeriod()
location: interface com.x2dev.sis.model.beans.Section
```

**Root Cause**: Using incorrect method names or navigation paths in JRXML field expressions

**Solution: Use correct Aspen model bean view methods**
```xml
<!-- Wrong - methods don't exist on Section interface -->
<textFieldExpression class="java.lang.String">
    <![CDATA["Room: " + ($F{section}.getRoom() != null ?
             $F{section}.getRoom().getRoomNumber() : "TBD")]]>
</textFieldExpression>

<!-- Correct - use view methods that return formatted strings -->
<textFieldExpression class="java.lang.String">
    <![CDATA["Room: " + ($F{section}.getRoomView() != null ?
             $F{section}.getRoomView() : "TBD")]]>
</textFieldExpression>
```

**Common Aspen View Methods:**
```java
// Instead of navigating relationships manually:
section.getRoom().getRoomNumber()           // May cause compilation errors
section.getPrimaryStaff().getNameView()    // Complex navigation

// Use pre-computed view methods:
section.getRoomView()                       // Returns room number directly
section.getPrimaryStaffView()               // Returns staff name directly
section.getCourseView()                     // Returns course number/name
section.getTermView()                       // Returns term information
section.getPrimaryPeriodView()              // Returns period name

// Student (SisStudent)
student.getNameView()                       // Full formatted name
student.getGradeLevelView()                 // Grade level with formatting
student.getYog()                           // Year of graduation (direct field)

// Person (SisPerson)
person.getNameView()                        // Full formatted name
person.getAddressView()                     // Formatted address

// Staff (SisStaff)
staff.getNameView()                         // Full formatted name
staff.getDepartmentView()                   // Department name/description
```

### 17. Field Definition and Expression Mapping Issues

**Problem: Method calls in expressions still fail even with correct method names**
```
error: cannot find symbol
symbol: method getRoomView()
location: interface com.x2dev.sis.model.beans.Section
```

**Root Cause**: JasperReports field expressions using method calls instead of field references, or missing field definitions in JRXML

**Solution: Use explicit field definitions with field references**

Step 1 — Add explicit field definitions in JRXML:
```xml
<field name="section.roomView" class="java.lang.String"/>
<field name="section.primaryPeriodView" class="java.lang.String"/>
<field name="student.nameView" class="java.lang.String"/>
<field name="student.person.primaryPhotoOid" class="java.lang.String"/>
```

Step 2 — Use field references in expressions, not method calls:
```xml
<!-- Wrong - Direct method calls in expressions -->
<textFieldExpression class="java.lang.String">
    <![CDATA["Room: " + ($F{section}.getRoomView() != null ?
             $F{section}.getRoomView() : "TBD")]]>
</textFieldExpression>

<!-- Correct - Field references -->
<textFieldExpression class="java.lang.String">
    <![CDATA["Room: " + ($F{section.roomView} != null ?
             $F{section.roomView} : "TBD")]]>
</textFieldExpression>
```

**Field Naming Convention for Nested Properties:**
```xml
<!-- Dot notation maps to getter methods automatically -->
<field name="student.nameView" class="java.lang.String"/>           <!-- student.getNameView() -->
<field name="student.person.firstName" class="java.lang.String"/>   <!-- student.getPerson().getFirstName() -->
<field name="section.primaryStaff.nameView" class="java.lang.String"/> <!-- section.getPrimaryStaff().getNameView() -->
```

**Field vs Expression Decision Matrix:**
| Use Case | Approach | Example |
|----------|----------|---------|
| Simple property access | Field reference | `$F{student.gradeLevel}` |
| Method calls on fields | Field reference | `$F{student.nameView}` |
| Complex calculations | Expression with fields | `$F{student.yog} - 2024` |
| Conditional logic | Expression with fields | `$F{student.gradeLevel}.equals("12") ? "Senior" : "Underclass"` |
| String concatenation | Expression with fields | `$F{student.person.firstName} + " " + $F{student.person.lastName}` |

---

## Java Source Compilation Errors

### 18. Missing Constants and Methods

**Problem: Java compilation fails with "cannot find symbol" errors**
```
error: cannot find symbol
symbol: variable PATH_DELIMITER
location: class com.x2dev.reports.sys.std.SubstituteClassListData

error: cannot find symbol
symbol: variable COL_PRIMARY_STAFF_VIEW
location: interface com.x2dev.sis.model.beans.Section
```

**Root Cause**: Missing imports, constants, or attempting to use non-existent fields/methods on Aspen model interfaces

**Step 1: Add Missing Imports and Constants**
```java
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.SisPerson;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.model.beans.StudentSection;
import com.x2dev.sis.model.beans.Section;

import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;

public class ReportData extends ReportJavaSourceNet {
    // PATH_DELIMITER is available via the static import above.
    // Fallback: If the static import is unavailable in your environment,
    // you can define it locally:
    //   private static final String PATH_DELIMITER = ".";
}
```

**Step 2: Fix Method Override Signatures**
```java
// Wrong - private method cannot override protected
private void applyUserSort(QueryByCriteria query, String sortParam) {

// Correct - proper override with correct access modifier
@Override
protected void applyUserSort(QueryByCriteria query, String sortParam) {

// Wrong - fully qualified class name in parameter
protected void saveState(com.follett.fsc.core.k12.web.UserDataContainer userData) {

// Correct - use imported class name
protected void saveState(UserDataContainer userData) {
```

**Step 3: Use Correct Field References and Relationship Navigation**
```java
// Wrong - non-existent constants
criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER +
                   Section.COL_PRIMARY_STAFF_VIEW, teacherName);

// Correct - proper relationship traversal
criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER +
                   Section.REL_PRIMARY_STAFF + PATH_DELIMITER +
                   "nameView", teacherName);
```

**Step 4: Fix StudentManager Method Calls**
```java
// Wrong - complex method call that may not exist
criteria.addEqualTo(SisStudent.COL_ENROLLMENT_STATUS,
    StudentManager.getActiveStudentCodeValue(getOrganization(),
                                           getBroker().getPersistenceKey()));

// Correct - use simple string constant
criteria.addEqualTo(SisStudent.COL_ENROLLMENT_STATUS, "Active");
```

**Step 5: Remove References to Non-existent Relationship Constants**
```java
// Wrong - REL_ROOM may not exist on Section interface
query.addPrefetchedRelationship(StudentSection.REL_SECTION + PATH_DELIMITER +
                               Section.REL_ROOM);

// Correct - only include existing relationships
query.addPrefetchedRelationship(StudentSection.REL_SECTION);
query.addPrefetchedRelationship(StudentSection.REL_SECTION + PATH_DELIMITER +
                               Section.REL_PRIMARY_STAFF);
```

**Common Compilation Error Patterns and Solutions:**

| Error Type | Cause | Solution |
|------------|-------|----------|
| `cannot find symbol: PATH_DELIMITER` | Missing import or constant | Add `import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;` or define `private static final String PATH_DELIMITER = ".";` |
| `cannot find symbol: COL_*_VIEW` | Non-existent view constant | Use relationship traversal or existing fields |
| `cannot find symbol: REL_*` | Non-existent relationship | Check model bean documentation or use alternatives |
| `weaker access privileges` | Wrong method access modifier | Use `@Override protected` instead of `private` |
| `cannot find symbol: UserDataContainer` | Missing import | Add `import com.follett.fsc.core.k12.web.UserDataContainer;` |

**Alternative Approaches When Direct Field Access Fails:**
```java
// If direct field constants don't exist, use string literals with caution
criteria.addEqualTo(StudentSection.REL_SECTION + PATH_DELIMITER + "courseView", courseCode);

// Use subqueries for complex filtering when direct relationships aren't available
SubQuery staffSubQuery = new SubQuery(SisStaff.class, SisStaff.COL_PERSON_OID, staffCriteria);
criteria.addIn(StudentSection.REL_SECTION + PATH_DELIMITER + Section.COL_PRIMARY_STAFF_OID, staffSubQuery);

// Use multiple criteria with OR logic for flexible matching
X2Criteria alternateCriteria = new X2Criteria();
alternateCriteria.addLike(StudentSection.REL_SECTION + PATH_DELIMITER + Section.COL_DESCRIPTION, "%" + searchTerm + "%");
criteria.addOrCriteria(alternateCriteria);
```

---

## Photo and Image Issues

### 19. Photo Loading — Two Working Approaches

**Approach A (preferred): `ByteArrayInputStream` from blob — use when you have direct bean access**

Read the photo bytes directly from the person bean. This is the confirmed production approach used in the attendance reports:
```xml
<image onErrorType="Blank">
    <reportElement x="3" y="2" width="65" height="70"/>
    <imageExpression><![CDATA[$F{student.person} != null
        && $F{student.person}.getPrimaryPhoto() != null
        && $F{student.person}.getPrimaryPhoto().getPhoto() != null
        ? new java.io.ByteArrayInputStream($F{student.person}.getPrimaryPhoto().getPhoto())
        : null]]></imageExpression>
</image>
```
Always include the full null-chain guard. `onErrorType="Blank"` ensures missing photos render as blank rather than throwing an error.

**Approach B: `repo:` prefix — use when you only have the photo OID string**

If you only have access to the OID string (e.g., `person.primaryPhotoOid`) rather than the bean:
```xml
<imageExpression class="java.lang.String">
    <![CDATA[$F{person.primaryPhotoOid} != null ?
            "repo:" + $F{person.primaryPhotoOid} : null]]>
</imageExpression>
```

**Wrong — direct file path does not work:**
```xml
<imageExpression class="java.lang.String">
    <![CDATA[$F{person.primaryPhotoOid} != null ?
            "/aspen/photos/" + $F{person.primaryPhotoOid} : null]]>
</imageExpression>
```
This fails with: `JRException: Byte data not found at : /aspen/photos/PHO00000147lSV`

**Summary**: Use Approach A when the data source bean gives you direct object access. Use Approach B when you're working from a field that only exposes the OID string.

---

## Caching and Deployment Issues

### 20. Changes Not Reflected After JRXML Modifications
**Problem**: Report still uses old compiled version after JRXML changes.

**Root Cause**: Aspen compiles JRXML files into `.jasper` files for performance. When you modify the JRXML source, the system may continue using the cached compiled version.

**Solution: Force recompilation**
1. In the Aspen administration interface, navigate to the report format
2. Use the "Compile" or "Recompile" function to regenerate the `.jasper` file from your updated JRXML
3. Clear any cached report results if a cache clearing function is available
4. Run the report again and verify your changes are reflected

Always recompile format files in Aspen after making JRXML changes. Aspen uses compiled `.jasper` files at runtime, not the raw JRXML source.

---

## Navigation Context Issues

### 21. Scoping a Class Attendance Report to the Selected Section (`attendance.period.classes.input`)

**Problem**: Report running from `attendance.period.classes.input` shows all of the teacher's classes instead of only the currently selected class section.

**Root Cause**: In the `attendance.period.classes.input` nav context, the "current record" is a **`ScheduleTeacher`** bean (the teacher-section assignment record), not `MasterSchedule` or `Section`. Calling `getCurrentRecord(MasterSchedule.class)` or `getCurrentRecord(Section.class)` returns null, causing the code to fall back to a teacher-wide query.

**Solution: Use `ScheduleTeacher` as the current record and call `.getSection()`**

```java
// In saveState():
ScheduleTeacher currentTeacherSection = userData.getCurrentRecord(ScheduleTeacher.class);
if (currentTeacherSection != null) {
    m_sectionOid = currentTeacherSection.getSection().getOid();
}
```

**Also confirmed**: `StudentSection` / `Section` (from documentation) are NOT OJB-queryable in some Aspen versions. The correct OJB-mapped beans for student enrollment queries are `StudentSchedule` / `MasterSchedule`.

**OJB property names on `StudentSchedule`**:
- `"sectionOid"` — **invalid** (SQL error: column not found)
- `"masterScheduleOid"` — **invalid** (SQL error: column not found)
- `"section.oid"` — **correct** (navigates the OJB relationship to MasterSchedule)

**Complete working pattern:**
```java
// saveState: capture current section via ScheduleTeacher
ScheduleTeacher currentTeacherSection = userData.getCurrentRecord(ScheduleTeacher.class);
if (currentTeacherSection != null) {
    m_sectionOid = currentTeacherSection.getSection().getOid();
}

// gatherData: scope to section using relationship path
if (m_sectionOid != null) {
    // Scope to single selected section
    criteria.addEqualTo("section" + PATH_DELIMITER + X2BaseBean.COL_OID, m_sectionOid);
} else {
    // Fallback: all sections for this teacher using ScheduleTeacher subquery
    X2Criteria subQueryCriteria = new X2Criteria();
    subQueryCriteria.addEqualTo(ScheduleTeacher.COL_STAFF_OID, m_teacherOid);
    subQueryCriteria.addEqualTo(
            ScheduleTeacher.REL_SECTION + PATH_DELIMITER + MasterSchedule.COL_SCHEDULE_OID,
            m_reportHelper.getScheduleOid());
    SubQuery subQuery = new SubQuery(
            ScheduleTeacher.class, ScheduleTeacher.COL_SECTION_OID, subQueryCriteria);
    criteria.addIn("section" + PATH_DELIMITER + X2BaseBean.COL_OID, subQuery);
}

QueryByCriteria query = new QueryByCriteria(StudentSchedule.class, criteria);
```

**Valid `ScheduleTeacher` constants** (confirmed working):
- `ScheduleTeacher.COL_STAFF_OID`
- `ScheduleTeacher.COL_SECTION_OID`
- `ScheduleTeacher.REL_SECTION`

**Key Learning**: Always look at an existing Aspen report that runs successfully from the same nav node as a reference.

---

## Export-Specific Issues

### 22. Export Bundle Import Fails with "Missing file" Error

**Problem**: Importing an export bundle throws `InvalidToolBundleException: Missing file *Input.xml`

**Root Cause**: For exports with `<exports package="com.x2dev.reports.yourstate.yourdistrict">`, Aspen looks for **all referenced files** (Java source AND Input XML) inside the package directory, not at the zip root.

**Solution: Place all files except `bundle-definition.xml` inside the package directory**
```
MyExport.zip
├── bundle-definition.xml              ← root level ONLY
└── com/x2dev/reports/yourstate/yourdistrict/  ← package directory
    ├── MyExportData.java              ← inside package
    └── MyExportInput.xml              ← inside package (NOT at root!)
```

### 23. Export Downloads as .txt Instead of .csv

**Problem**: The exported file has a `.txt` extension and is tab-delimited instead of comma-separated.

**Root Cause**: `ExportJavaSource` defaults to tab-delimited `.txt` output.

**Solution: Set CSV formatting in `initialize()` and override `getCustomFileName()`**
```java
@Override
protected void initialize() throws X2BaseException {
    super.initialize();
    setIncludeHeaderRow(true);
    setValueDelimiter(',');    // comma instead of tab
    setValueWrapper('"');      // wrap values in quotes
}

@Override
public String getCustomFileName() {
    return "MyExport.csv";     // force .csv extension
}
```

---

## Grade Term / Date Range Issues

### 24. Term Dropdown Not Filtering Attendance by Date Range

**Problem**: A grade term selector (Q1–Q4, YR) exists in the input definition, but the report/export shows data from all terms regardless of selection.

**Root Cause**: Using `ScheduleTermDate` to resolve term date ranges. `ScheduleTermDate` stores the **full schedule year range** (e.g., 8/1/2025–7/31/2026) for **every** term — Q1 through YR all share the same dates. This means filtering by `ScheduleTermDate` effectively applies no date restriction.

**Solution: Use `GradeTermDate` instead of `ScheduleTermDate`**

`GradeTermDate` stores the actual grading period boundaries (e.g., Q3: 1/21/2026–3/31/2026).

```java
import com.x2dev.sis.model.beans.GradeTermDate;

X2Criteria dateCriteria = new X2Criteria();
dateCriteria.addEqualTo(GradeTermDate.COL_GRADE_TERM_OID, m_gradeTerm.getOid());
// Scope to selected school year — GradeTermDate records exist across ALL years
dateCriteria.addGreaterOrEqualThan(GradeTermDate.COL_START_DATE, m_context.getStartDate());
dateCriteria.addLessOrEqualThan(GradeTermDate.COL_END_DATE, m_context.getEndDate());

QueryByCriteria dateQuery = new QueryByCriteria(GradeTermDate.class, dateCriteria);
Collection<GradeTermDate> termDates = getBroker().getCollectionByQuery(dateQuery);

for (GradeTermDate termDate : termDates) {
    // Use min start / max end across matching records
    PlainDate start = termDate.getStartDate();
    PlainDate end = termDate.getEndDate();
    if (start != null && (m_startDate == null || start.before(m_startDate))) {
        m_startDate = start;
    }
    if (end != null && (m_endDate == null || end.after(m_endDate))) {
        m_endDate = end;
    }
}

// Fallback for YR or missing records
if (m_startDate == null || m_endDate == null) {
    m_startDate = m_context.getStartDate();
    m_endDate = m_context.getEndDate();
}
```

**Key pitfalls encountered during development:**
1. `GradeTerm` does **not** have a `getGradeTermMap()` method — that method is only on `ScheduleTerm`. Attempting to call it causes `ClassNotFoundException`.
2. `gradeTermMap` is a positional bitmap string ("1000"=Q1, "0100"=Q2, etc.), **not** a comma-separated list of OIDs.
3. GradeTermDate records exist for **every school year** the system has been active. Without scoping to the context year's dates, a Q3 query may return dates from all four years of a student's enrollment.

> See `02-DATABASE-SCHEMA.md § Scheduling & Grading Period Tables` for the full table comparison and bitmap format.

### 25. GradeTerm.getGradeTermMap() — ClassNotFoundException

**Problem**: Java source compiles but throws `ClassNotFoundException` at runtime when calling `m_gradeTerm.getGradeTermMap()`.

**Root Cause**: `GradeTerm` does not have a `getGradeTermMap()` method. That method exists only on `ScheduleTerm`.

**Solution**: Use `GradeTermDate` to look up term dates by `GradeTerm` OID (see issue #24 above). Do not attempt to compare bitmap strings via `GradeTerm`.

### 26. DataDictionary API — Method Availability Pitfalls

**Problem**: Attempting to access field metadata (java name, java type, database name) through `DataFieldConfig` getters or iterating fields via `DataDictionaryTable` fails with compile errors or `ClassNotFoundException`.

**Root Cause**: Aspen splits field metadata across two layers:
- `DataFieldConfig` (bean) — has `getDataFieldOid()`, `getUserLongName()`, `getUserShortName()` but NOT `getJavaName()`, `getJavaType()`, `getDatabaseName()`
- `DataDictionaryField` (business wrapper) — has `getJavaName()`, `getEffectiveJavaType()`, `getDatabaseName()` but NOT `getDataFieldOid()`
- `DataDictionaryTable.getFields()` and `getFieldsMap()` do NOT exist — you cannot iterate fields from a table object
- `DataTableConfig` OJB property `"className"` is NOT a valid DB column — causes runtime SQL error

**Solution**: Use a hybrid approach:
1. Query all `DataFieldConfig` beans (empty criteria) and group by OID prefix in Java
2. Use `DataDictionary.findDataDictionaryField(oid)` to look up `DataDictionaryField` for java name, type, and DB name

```java
DataDictionary dictionary = DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey());

// Query all DataFieldConfig beans
Collection<DataFieldConfig> allFields = getBroker().getCollectionByQuery(
        new QueryByCriteria(DataFieldConfig.class, new X2Criteria()));

for (DataFieldConfig field : allFields) {
    String oid = field.getDataFieldOid();        // works on DataFieldConfig
    String longName = field.getUserLongName();    // works on DataFieldConfig

    DataDictionaryField ddField = dictionary.findDataDictionaryField(oid);
    if (ddField != null) {
        String javaName = ddField.getJavaName();           // works on DataDictionaryField
        String javaType = ddField.getEffectiveJavaType();  // works on DataDictionaryField
        String dbName = ddField.getDatabaseName();         // works on DataDictionaryField
    }
}
```

**Key reminder**: `ClassNotFoundException` for a custom class in Aspen means the Java source failed to compile — Aspen swallows the actual compile error.

---

### 27. getCurrentContext() Returns Null in District View

**Problem**: Export returns empty results or throws NullPointerException when run from District View → Tools → Exports.

**Root Cause**: `getCurrentContext()` returns `null` when running in district context. The method only works in school context.

**Solution: Use a `contextOid` input parameter**
```xml
<!-- In Input Definition XML -->
<input name="contextOid" data-type="string" display-type="picklist"
       display-name="report.shared.schoolYear"
       default-value="organization.currentContextOid"
       default-value-source="session">
  <picklist field-id="ctxSchoolYear">
    <field id="ctxSchoolYear" sort="true" />
    <field id="ctxContextName" />
  </picklist>
</input>
```

```java
// In initialize():
String contextOid = (String) getParameter("contextOid");
if (!StringUtils.isEmpty(contextOid)) {
    m_context = (DistrictSchoolYearContext) getBroker().getBeanByOid(
            DistrictSchoolYearContext.class, contextOid);
}
```

### 28. SisAddress Method Name Errors

**Problem**: Compile errors when accessing student address fields — `getStreetLine01()`, `getStreetLine1()` not found.

**Root Cause**: The correct method name is `getAddressLine01()`. Also, `getStreetNumber()` returns `int`, not `String`.

**Solution**:
```java
SisAddress address = person.getPhysicalAddress();
if (address != null) {
    String streetNo = String.valueOf(address.getStreetNumber());  // int → String
    String streetName = address.getAddressLine01();                // correct method
    String city = address.getCity();
    String state = address.getState();
    String zip = address.getPostalCode();
}
```

### 29. addNotContains Does Not Exist on X2Criteria

**Problem**: Compile error: `cannot find symbol: method addNotContains`.

**Root Cause**: `X2Criteria` does not have an `addNotContains()` method.

**Solution: Use `addNotLike()` with SQL wildcard pattern**
```java
// Wrong:
criteria.addNotContains(SchoolCourse.COL_DESCRIPTION, "SomeValue");

// Correct:
criteria.addNotLike(SchoolCourse.COL_DESCRIPTION, "%SomeValue%");
```

### 30. Boolean-Like Custom Fields — Inconsistent Values

**Problem**: Criteria filtering on a custom boolean field returns no results, even though data exists.

**Root Cause**: Custom fields configured as checkboxes or boolean-like values may store different string representations depending on how data was entered: `"Y"`, `"TRUE"`, or `"1"`.

**Solution: Use OR criteria to match all variants**
```java
private X2Criteria buildBooleanTrueCriteria(String fieldPath) {
    X2Criteria criteriaY = new X2Criteria();
    criteriaY.addEqualTo(fieldPath, "Y");

    X2Criteria criteriaTrue = new X2Criteria();
    criteriaTrue.addEqualTo(fieldPath, "TRUE");

    X2Criteria criteriaOne = new X2Criteria();
    criteriaOne.addEqualTo(fieldPath, "1");

    criteriaY.addOrCriteria(criteriaTrue);
    criteriaY.addOrCriteria(criteriaOne);
    return criteriaY;
}
```

### 31. ExportJavaSource Cannot Output Multiple Files

**Problem**: Need to generate multiple CSV files (e.g., 4 different export types) from a single export.

**Root Cause**: `ExportJavaSource` is hard-wired to return a single `DataGrid` that becomes a single output file. There is no override point to write ZIP content or multiple files.

**Solution**: Use a mode-selector dropdown input parameter. Users run the export once per mode. For automation, create separate scheduled jobs in Aspen — one per export mode — all pointing to the same export definition with different parameter values.

---

## Debugging Tips
1. **Log Parameter Values**: Add logging to verify parameter receipt
2. **Test Criteria Separately**: Execute queries independently to verify results
3. **Validate Relationships**: Confirm table relationships in database schema
4. **Use Simple Test Data**: Start with minimal dataset for debugging
5. **JRXML Validation**: Always validate JRXML syntax before deployment
6. **Element Positioning**: Use a grid or ruler to plan element positions and band heights
7. **Incremental Testing**: Test reports with minimal elements first, then add complexity
8. **Start Simple**: Begin with basic field access before adding complex relationships
9. **Verify Constants**: Check model bean interfaces for available constants
10. **Follow Patterns**: Study existing Aspen reports for proven field access patterns
