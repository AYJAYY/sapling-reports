# Report Examples

Place 3–5 exported report bundles from your Aspen system here. These give Claude Code real working examples to reference when building new reports.

## How to Export Report Bundles

1. Log into Aspen as a district administrator
2. Go to **Admin > Tools > Exports/Reports**
3. Find a working report you want to use as a reference
4. Click the report, then select **Export Bundle** from the Options menu
5. Save the `.zip` file to this folder and extract it

## What to Export

Pick reports that are similar to what you want to build:

- A **simple student list** report (good Level 1 reference)
- An **attendance or schedule** report with date filters (good Level 2–3 reference)
- A **grouped report** with subtotals or multiple sections (good Level 3–4 reference)

The more variety you provide, the better Claude Code can match patterns to your requests.
