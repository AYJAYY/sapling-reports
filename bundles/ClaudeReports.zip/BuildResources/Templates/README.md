# Report Skeleton Templates

Minimal working starter files for creating a new Aspen report bundle. Copy this entire folder to a new report directory and rename the files to match your report.

## Files

| File | Purpose |
|---|---|
| `bundle-definition.xml` | Bundle registration — set report ID, name, category, nav nodes |
| `TemplateReportInput.xml` | Input Definition — query-by dropdown, text filter, sort, date picker stub |
| `TemplateReport.jrxml` | JRXML layout — page header, column headers, detail band with alternating rows, page footer |
| `TemplateReportData.java` | Java data source — school/district scoping, active student criteria, query-by switch, staff context |

## Quick Start

1. Copy this folder: `cp -r Templates/ "../NewReportName/"`
2. Rename files: replace `TemplateReport` with your report name in all filenames
3. Update `bundle-definition.xml`: set `id`, `name`, `category`, file references, and nav nodes
4. Update `TemplateReportInput.xml`: add/modify input parameters
5. Update `TemplateReportData.java`: adjust criteria, query logic, and data fields
6. Update `TemplateReport.jrxml`: modify layout, fields, and expressions
7. Package as `.zip` and import via **Admin → Tools → Exports/Reports**

## References

- Full attribute docs: `BuildResources/bundle-definition-template.xml`
- Workflow guide: `BuildResources/Guide/00-AI-WORKFLOW.md`
- Quick patterns: `BuildResources/Guide/08-QUICK-REFERENCE.md`
