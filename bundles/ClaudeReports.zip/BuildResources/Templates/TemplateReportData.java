/*
 * SKELETON TEMPLATE — Java Data Source
 * Replace "TemplateReport" with your report name throughout.
 * See Guide/05-JAVA-DATASOURCE.md for patterns and Guide/08-QUICK-REFERENCE.md for quick lookups.
 */

import com.follett.fsc.core.framework.persistence.SubQuery;
import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.QueryIterator;
import com.follett.fsc.core.k12.beans.X2BaseBean;
import com.follett.fsc.core.k12.tools.reports.QueryIteratorDataSource;
import com.follett.fsc.core.k12.tools.reports.ReportJavaSourceNet;
import com.follett.fsc.core.k12.tools.reports.ReportUtils;
import com.follett.fsc.core.k12.web.ApplicationContext;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.SisStudent;
import com.x2dev.sis.tools.reports.StudentContextReportHelper;
import com.x2dev.utils.StringUtils;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.ojb.broker.query.QueryByCriteria;

import static com.follett.fsc.core.k12.business.ModelProperty.PATH_DELIMITER;

/**
 * Data source for the TemplateReport report.
 */
public class TemplateReportData extends ReportJavaSourceNet {
    private static final long serialVersionUID = 1L;

    // Input parameter name constants — must match the Input Definition XML <id> values
    private static final String QUERY_BY_PARAM = "queryBy";
    private static final String QUERY_STRING_PARAM = "queryString";
    private static final String SORT_PARAM = "sort";

    // Member variables
    private StudentContextReportHelper m_schoolYearHelper;
    private String m_staffOid;

    /**
     * Gathers data for the report. Build criteria, execute query, return data source.
     */
    @Override
    protected JRDataSource gatherData() throws Exception {
        X2Criteria criteria = new X2Criteria();

        // --- School/district scoping ---
        if (isSchoolContext()) {
            criteria.addEqualTo(
                m_schoolYearHelper.getSchoolOidField(),
                getSchool().getOid());
        } else {
            criteria.addAndCriteria(getOrganizationCriteria(SisStudent.class));
        }

        // --- Active students only ---
        criteria.addAndCriteria(m_schoolYearHelper.getActiveStudentCriteria());

        // --- Query-by parameter filtering ---
        int queryBy = ((Integer) getParameter(QUERY_BY_PARAM)).intValue();
        switch (queryBy) {
            case 0: // All
                break;

            // TODO: Add additional query-by cases here
            // case 1: // By specific field
            //     criteria.addEqualTo(FIELD, getParameter(QUERY_STRING_PARAM));
            //     break;

            default:
                break;
        }

        // --- Build and execute query ---
        QueryByCriteria query = new QueryByCriteria(SisStudent.class, criteria);

        // TODO: Add ordering
        // query.addOrderByAscending(SisStudent.COL_NAME_VIEW);

        applyUserSort(query, (String) getParameter(SORT_PARAM));

        return new QueryIteratorDataSource(getBroker().getIteratorByQuery(query));
    }

    /**
     * Saves session state. Called before gatherData().
     * Use this to capture the user's context (staff view, current record, etc.).
     */
    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException {
        super.saveState(userData);

        m_schoolYearHelper = new StudentContextReportHelper(
            getOrganization(), getCurrentContext(), getBroker());

        // Capture staff OID if running in staff view
        if (userData.getSessionNavConfig() != null
                && ApplicationContext.STAFF.equals(
                    userData.getSessionNavConfig().getApplicationContext())) {
            m_staffOid = userData.getStaffOid();
        }
    }
}
