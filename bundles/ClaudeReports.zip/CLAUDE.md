# CLAUDE.md — Aspen X2 Custom Reports & Exports

Custom JasperReports bundle reports and CSV exports for the **Follett Aspen X2** Student Information System (SIS).

---

---

## IMPORTANT — Safety & Guidance Rules

### Data Privacy
- **NEVER ask the user to paste student records, PII, or real data into this conversation.** This includes names, student IDs, dates of birth, addresses, grades, attendance records, or any data that could identify a student or staff member.
- If you need to understand what data looks like, ask for **field names, column headers, or anonymized/fake examples** — never real records.
- If the user pastes what appears to be real student or staff data, **immediately warn them** to avoid sharing PII with AI tools and suggest they use anonymized samples instead.
- Schema metadata (field definitions, table structures, column names) is safe to share — it contains no student data.

### User Guidance
- Always assume the user is **not a Java developer**. They are Aspen administrators using AI to generate code. Explain decisions in plain language when relevant.
- **Ask clarifying questions** before generating code. At minimum, confirm: what data they need, which Aspen view/nav node it runs from, and what filters/parameters the user should see.
- When you need information from their Aspen system (custom field mappings, school names, term structures), tell them **exactly where to find it** in the Aspen UI or how to run the DEVResources export.
- After generating or modifying code, **always remind them to upload and test** — there is no local compile step. Errors only surface at runtime in Aspen.

### Error Handling
- When the user pastes an error from Aspen, **do not guess**. Read the error carefully, check against the troubleshooting guide (`Guide/07-TROUBLESHOOTING.md`), and explain the root cause before applying a fix.
- `ClassNotFoundException` always means a **compile error** — Aspen swallows the real error. Focus on imports, method names, and API availability.
- If you're unsure whether a method or class exists in the Aspen API, **say so** and suggest a safe alternative. Do not assume undocumented methods work.

### Code Quality
- Always use the patterns documented in `BuildResources/Guide/` — they are tested against live Aspen instances.
- Include `version-number`, `version-date`, and `version-year` on every bundle definition.
- Always call `grid.beforeTop()` before returning a `DataGrid` in exports.
- Never hardcode school OIDs, student OIDs, or other instance-specific identifiers. Always query them dynamically or accept them as input parameters.

---

## Quick Facts

- **Engine**: JasperReports **6.19.1** (all new reports target this version)
- **Database**: Microsoft SQL Server, accessed via Aspen's internal OJB broker
- **No local build step** — Java and JRXML files compile server-side when uploaded to Aspen
- **Deployment**: `Admin → Tools → Exports/Reports → Import Bundle` (upload the `.zip`)
- **Two bundle types**: Reports (PDF via JRXML) and Exports (CSV via `ExportJavaSource`)

---

## Report Architecture

Every report is a bundle of four files:

| File | Purpose |
|---|---|
| `bundle-definition.xml` | Registers the report with Aspen (ID, name, category, nav nodes, engine version) |
| `*Input.xml` | Input Definition — user-facing parameter form |
| `*.jrxml` | JasperReports layout — visual design |
| `*Data.java` | Java data source — extends `ReportJavaSourceNet`, queries SQL Server |

---

## Export Architecture (CSV)

Exports output CSV instead of PDF. **No JRXML file needed.**

| File | Purpose |
|---|---|
| `bundle-definition.xml` | Uses `<exports>` / `<export-definition>` with `package` attribute |
| `*Input.xml` | Input Definition — same format as reports, lives inside package directory |
| `*Data.java` | Java data source — extends `ExportJavaSource`, returns `DataGrid` |

Key differences from reports:
- Extends `ExportJavaSource` (not `ReportJavaSourceNet`); `gatherData()` returns `DataGrid`
- Must override: `getColumnNames()`, `getColumnUserNames()`, `getComment()`, `getHeader()`
- Use `setIncludeHeaderRow(true)`, `setValueDelimiter(',')`, `setValueWrapper('"')` in `initialize()`
- Override `getCustomFileName()` to return a `.csv` filename
- All files except `bundle-definition.xml` live inside the package directory (e.g., `com/x2dev/reports/yourstate/yourdistrict/`)

---

## AI Development Guide

All reference materials for building new reports are in `BuildResources/`:

**Start here:** `BuildResources/Guide/00-AI-WORKFLOW.md`

| File | Contents |
|---|---|
| `Guide/00-AI-WORKFLOW.md` | Step-by-step workflow, complexity levels, decision matrix, quick start checklist |
| `Guide/01-ARCHITECTURE.md` | System overview and required components |
| `Guide/02-DATABASE-SCHEMA.md` | Table/field mappings, query patterns, full schema reference |
| `Guide/03-INPUT-DEFINITION.md` | Input Definition XML structure |
| `Guide/04-JRXML-FORMAT.md` | JRXML layout, band patterns, photo loading, alternating rows |
| `Guide/05-JAVA-DATASOURCE.md` | Java data source patterns, imports, key classes |
| `Guide/06-BEST-PRACTICES.md` | Best practices, advanced features, resources |
| `Guide/07-TROUBLESHOOTING.md` | 30+ documented issues with root causes and solutions |
| `Guide/08-QUICK-REFERENCE.md` | Most-used patterns in one page — start here for quick lookups |
| `FullDatabaseSchema_cleaned.csv` | Complete field inventory — **generate your own** by running the DEVResources export |
| `GradeTermMap.csv` | Grade term bitmap definitions — **generate your own** by running the DEVResources export |
| `TermMapExpanded.csv` | Schedule term data — **generate your own** by running the DEVResources export |
| `Templates/` | Skeleton starter files — copy and rename to begin a new report |
| `Report Examples/` | Place 3–5 exported report bundles from your Aspen system here as structural references |
| `bundle-definition-template.xml` | Annotated bundle-definition.xml template |

---

## Key Conventions

- Java field naming: `[tablePrefix][FieldName]` — e.g. `psnNameFirst`, `stdYog`, `attDate`
- Table prefixes: `PSN` (Person), `STD` (Student), `STF` (Staff), `ATT` (Attendance), `CND` (Conduct)
- Gender codes: `M` = Male, `F` = Female, `N` = Non-Binary
- Always use `PlainDate` in Java for date parameters; declare as `java.util.Date` in JRXML
- Use `onErrorType="Blank"` on all image elements; load photos via `ByteArrayInputStream`
- **GradeTermDate vs ScheduleTermDate**: Use `GradeTermDate` for actual quarter date ranges; `ScheduleTermDate` stores full-year dates for ALL terms
- **Navigation nodes**: When creating a new report or export, always ask the user which navigation node(s) it should appear under (e.g., `student.std.list`, `attendance.daily.input`) and which views to enable (`staff-view`, `school-view`). Do not guess — the user must specify where the report should be accessible.
- **Bundle versioning**: Always include `version-number`, `version-date`, and `version-year` attributes on `<report-definition>` and `<export-definition>` elements in `bundle-definition.xml`. Update these on every release (bump version, set date to today, set year to current school year e.g. `"2025-2026"`).
- **DataDictionary API**: Use `DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey())` and `dictionary.findDataDictionaryTableByClass(className)` for metadata access. `DataFieldConfig` getters: `getDataFieldOid()`, `getUserLongName()`, `getUserShortName()` work; `getJavaName()`, `getJavaType()`, `getDatabaseName()` do NOT — use `DataDictionaryField` via `dictionary.findDataDictionaryField(oid)` for those. `DataDictionaryTable.getFields()` and `getFieldsMap()` do NOT exist. `DataTableConfig` OJB property `"className"` is NOT a valid column.
- **District view context**: `getCurrentContext()` returns `null` when running an export from District View. Always use a `contextOid` input parameter and load the `DistrictSchoolYearContext` bean via `getBroker().getBeanByOid()`.
- **SisAddress API**: `getStreetNumber()` returns `int` (wrap with `String.valueOf()`). Use `getAddressLine01()` for street name (`getStreetLine01()` / `getStreetLine1()` do NOT exist). Use `getCity()`, `getState()`, `getPostalCode()` for remaining address fields.
- **X2Criteria limitations**: `addNotContains()` does NOT exist. Use `addNotLike()` with SQL wildcard patterns (e.g., `"%keyword%"`).
- **Boolean-like custom fields**: Custom fields may store `"Y"`, `"TRUE"`, or `"1"` depending on district configuration. Use OR criteria to match all variants.
- **ExportJavaSource single-file limitation**: `ExportJavaSource` can only output a single `DataGrid` → single file per run. No ZIP or multi-file output. Use a mode-selector dropdown input to let users pick which file to export, then set up multiple scheduled jobs for automation.
- **Multi-school queries**: Use `addIn(COL_SCHOOL_OID, schoolOidList)` to query across multiple schools. Look up schools by name with `addEqualTo(SisSchool.COL_NAME, "exact name")`.

---

## Exports/DEVResources/ — Schema & Term Reference Export

`Exports/DEVResources/` contains a utility Aspen export that auto-generates the reference data files in `BuildResources/`. Three selectable modes:

| Mode | Output | Replaces |
|---|---|---|
| Data Dictionary Schema | `DataDictionarySchema.csv` | `FullDatabaseSchema_cleaned.csv` |
| Grade Term Map | `GradeTermMap.csv` | `GradeTermMap.csv` |
| Schedule Term Details | `ScheduleTermMap.csv` | `TermMapExpanded.csv` |

---

## Detailed guidance: `BuildResources/CLAUDE.md`
