/*
 * ====================================================================
 *
 * Custom Aspen X2 Export — Schema & Term Reference
 *
 * Exports Data Dictionary field definitions, grade term maps, or
 * schedule term details as CSV. Replaces manually-exported reference
 * files (FullDatabaseSchema_cleaned.csv, GradeTermMap.csv,
 * TermMapExpanded.csv) with an on-demand automated export.
 *
 * ====================================================================
 *
 * COMPILE NOTES — DataDictionary API
 *
 * The schema export uses DataDictionary, DataDictionaryTable, and
 * DataDictionaryField classes exclusively (no DataFieldConfig queries).
 *
 * Confirmed working:
 *   DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey())
 *   dictionary.findDataDictionaryTableByClass(className)
 *
 * If ddTable.getFieldsMap() doesn't compile, try:
 *   ddTable.getFields()  — may return Collection or Map
 *   ddTable.getFieldList()
 *
 * See gatherSchemaData() for DataDictionaryField getter alternatives.
 *
 * term.getName()  — returns "Quarter 1" etc.
 *   Alt: term.getDescription()
 *
 * ====================================================================
 */
package com.x2dev.reports.ma.devresources;

import com.follett.fsc.core.framework.persistence.X2Criteria;
import com.follett.fsc.core.k12.beans.DistrictSchoolYearContext;
import com.follett.fsc.core.k12.beans.DataFieldConfig;
import com.follett.fsc.core.k12.business.dictionary.DataDictionary;
import com.follett.fsc.core.k12.business.dictionary.DataDictionaryField;
import com.follett.fsc.core.k12.tools.exports.ExportJavaSource;
import com.follett.fsc.core.k12.tools.reports.ReportDataGrid;
import com.follett.fsc.core.k12.web.UserDataContainer;
import com.x2dev.sis.model.beans.Schedule;
import com.x2dev.sis.model.beans.ScheduleTerm;
import com.x2dev.sis.model.beans.ScheduleTermDate;
import com.x2dev.utils.DataGrid;
import com.x2dev.utils.StringUtils;
import com.x2dev.utils.X2BaseException;
import com.x2dev.utils.types.PlainDate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.ojb.broker.query.QueryByCriteria;

/**
 * Schema & Term Reference Export.
 *
 * Three export modes selectable via input parameter:
 * <ul>
 *   <li><b>schema</b> — Data Dictionary fields for core tables (replaces FullDatabaseSchema_cleaned.csv)</li>
 *   <li><b>gradeterms</b> — Grade term bitmap map (replaces GradeTermMap.csv)</li>
 *   <li><b>scheduleterms</b> — Schedule term details with dates (replaces TermMapExpanded.csv)</li>
 * </ul>
 */
public class SchemaReferenceExportData extends ExportJavaSource
{
    private static final long serialVersionUID = 1L;

    // ── Input parameter names ──────────────────────────────────────────
    private static final String MODE_PARAM        = "exportMode";
    private static final String CONTEXT_OID_PARAM = "contextOid";

    // ── Export modes ───────────────────────────────────────────────────
    private static final String MODE_SCHEMA         = "schema";
    private static final String MODE_GRADE_TERMS    = "gradeterms";
    private static final String MODE_SCHEDULE_TERMS = "scheduleterms";

    /*
     * Tables to include in the schema export, in display order.
     * Each entry: { databaseTableName, fullyQualifiedJavaClassName }
     * These match the tables shown in Aspen's Data Dictionary page.
     */
    private static final String[][] TABLES =
    {
        {"PERSON",                   "com.x2dev.sis.model.beans.SisPerson"},
        {"SCHOOL_ROOM",              "com.x2dev.sis.model.beans.SchoolRoom"},
        {"STAFF",                    "com.x2dev.sis.model.beans.SisStaff"},
        {"STAFF_POSITION",           "com.x2dev.sis.model.beans.StaffPosition"},
        {"STUDENT",                  "com.x2dev.sis.model.beans.SisStudent"},
        {"STUDENT_ATTENDANCE",       "com.x2dev.sis.model.beans.StudentAttendance"},
        {"STUDENT_CONDUCT_ACTION",   "com.x2dev.sis.model.beans.ConductAction"},
        {"STUDENT_CONDUCT_INCIDENT", "com.x2dev.sis.model.beans.ConductIncident"},
        {"STUDENT_CONTACT",          "com.follett.fsc.core.k12.beans.StudentContact"},
        {"STUDENT_TRANSCRIPT",       "com.x2dev.sis.model.beans.Transcript"},
        {"USER_INFO",                "com.x2dev.sis.model.beans.SisUser"},
    };

    /*
     * Prefix-to-table mapping for OID-based field grouping.
     * DataFieldConfig OIDs start with these prefixes (e.g. "psnNameFirst").
     */
    private static final String[][] OID_PREFIXES =
    {
        {"psn", "PERSON",                   "com.x2dev.sis.model.beans.SisPerson"},
        {"rms", "SCHOOL_ROOM",              "com.x2dev.sis.model.beans.SchoolRoom"},
        {"stf", "STAFF",                    "com.x2dev.sis.model.beans.SisStaff"},
        {"sfp", "STAFF_POSITION",           "com.x2dev.sis.model.beans.StaffPosition"},
        {"std", "STUDENT",                  "com.x2dev.sis.model.beans.SisStudent"},
        {"att", "STUDENT_ATTENDANCE",       "com.x2dev.sis.model.beans.StudentAttendance"},
        {"act", "STUDENT_CONDUCT_ACTION",   "com.x2dev.sis.model.beans.ConductAction"},
        {"cnd", "STUDENT_CONDUCT_INCIDENT", "com.x2dev.sis.model.beans.ConductIncident"},
        {"ctj", "STUDENT_CONTACT",          "com.follett.fsc.core.k12.beans.StudentContact"},
        {"trn", "STUDENT_TRANSCRIPT",       "com.x2dev.sis.model.beans.Transcript"},
        {"usr", "USER_INFO",                "com.x2dev.sis.model.beans.SisUser"},
    };

    // ── Schema CSV columns ─────────────────────────────────────────────
    private static final String COL_TABLE      = "Table";
    private static final String COL_CLASS_NAME = "Class Name";
    private static final String COL_OID        = "OID";
    private static final String COL_LONG_NAME  = "Long Name";
    private static final String COL_SHORT_NAME = "Short Name";
    private static final String COL_JAVA_NAME  = "Java Name";
    private static final String COL_JAVA_TYPE  = "Java Type";
    private static final String COL_DB_NAME    = "Database Name";

    // ── Grade term CSV columns ─────────────────────────────────────────
    private static final String COL_CODE        = "Code";
    private static final String COL_NAME        = "Name";
    private static final String COL_BASE_MAP    = "BaseMap";
    private static final String COL_GTM_MAP     = "GradeTermMap";
    private static final String COL_COVERED_TPY = "CoveredTPY";
    private static final String COL_BASE_TPY    = "BaseTPY";

    // ── Schedule term CSV columns (extends grade term columns) ─────────
    private static final String COL_SCHED_NAME = "ScheduleName";
    private static final String COL_START      = "Start";
    private static final String COL_END        = "End";
    private static final String COL_COMMENT    = "Comment";

    // ── Member variables ───────────────────────────────────────────────
    private String                       m_mode;
    private DistrictSchoolYearContext     m_context;
    private List<String>                 m_columnNames;
    private List<String>                 m_columnUserNames;

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#gatherData()
     */
    @Override
    protected DataGrid gatherData()
    {
        ReportDataGrid grid = new ReportDataGrid();

        if (MODE_SCHEMA.equals(m_mode))
        {
            gatherSchemaData(grid);
        }
        else if (MODE_GRADE_TERMS.equals(m_mode))
        {
            gatherGradeTermData(grid);
        }
        else if (MODE_SCHEDULE_TERMS.equals(m_mode))
        {
            gatherScheduleTermData(grid);
        }

        grid.beforeTop();
        return grid;
    }

    /**
     * Queries ALL DataFieldConfig beans, groups by OID prefix to identify
     * the table, then looks up DataDictionaryField for java name, type,
     * and database column name.
     *
     * Confirmed working on DataFieldConfig:
     *   getDataFieldOid(), getUserLongName(), getUserShortName()
     *
     * Confirmed compiling on DataDictionaryField (via findDataDictionaryField):
     *   getJavaName(), getEffectiveJavaType(), getDatabaseName()
     *
     * If any DDField getter fails, try:
     *   getJavaName()          → getBeanPath()
     *   getEffectiveJavaType() → getJavaType(), getUserType()
     *   getDatabaseName()      → getDatabaseFieldName()
     */
    private void gatherSchemaData(ReportDataGrid grid)
    {
        DataDictionary dictionary =
                DataDictionary.getDistrictDictionary(getBroker().getPersistenceKey());

        /*
         * Build prefix lookup map: "psn" → {"psn", "PERSON", "com.x2dev..."}
         */
        Map<String, String[]> prefixMap = new HashMap<String, String[]>();
        for (int t = 0; t < OID_PREFIXES.length; t++)
        {
            prefixMap.put(OID_PREFIXES[t][0], OID_PREFIXES[t]);
        }

        /*
         * Query ALL DataFieldConfig beans. No criteria filter needed —
         * we group by OID prefix in Java to avoid OJB property path issues.
         */
        QueryByCriteria query =
                new QueryByCriteria(DataFieldConfig.class, new X2Criteria());

        Collection<DataFieldConfig> allFields =
                getBroker().getCollectionByQuery(query);

        if (allFields == null)
        {
            return;
        }

        /*
         * Collect rows grouped by table so we can output in table order.
         * Key = prefix, Value = list of grid row data.
         */
        Map<String, List<String[]>> tableRows =
                new HashMap<String, List<String[]>>();

        for (DataFieldConfig field : allFields)
        {
            String oid = field.getDataFieldOid();
            if (oid == null || oid.length() < 3)
            {
                continue;
            }

            String prefix = oid.substring(0, 3);
            String[] tableInfo = prefixMap.get(prefix);

            if (tableInfo == null)
            {
                continue;
            }

            /*
             * Look up DataDictionaryField for java name, type, DB name.
             */
            String javaName = "";
            String javaType = "";
            String dbName = "";

            DataDictionaryField ddField = dictionary.findDataDictionaryField(oid);
            if (ddField != null)
            {
                javaName = ddField.getJavaName();
                javaType = ddField.getEffectiveJavaType();
                dbName = ddField.getDatabaseName();
            }

            String[] row = new String[]
            {
                tableInfo[1],                          // table name
                tableInfo[2],                          // class name
                oid,                                   // OID
                field.getUserLongName(),                // long name
                field.getUserShortName(),               // short name
                javaName,                              // java name
                javaType,                              // java type
                dbName                                 // database name
            };

            List<String[]> rows = tableRows.get(prefix);
            if (rows == null)
            {
                rows = new ArrayList<String[]>();
                tableRows.put(prefix, rows);
            }
            rows.add(row);
        }

        /*
         * Output rows in table order (matching OID_PREFIXES order).
         */
        for (int t = 0; t < OID_PREFIXES.length; t++)
        {
            String prefix = OID_PREFIXES[t][0];
            List<String[]> rows = tableRows.get(prefix);

            if (rows == null)
            {
                continue;
            }

            for (String[] row : rows)
            {
                grid.append();
                grid.set(COL_TABLE, row[0]);
                grid.set(COL_CLASS_NAME, row[1]);
                grid.set(COL_OID, row[2]);
                grid.set(COL_LONG_NAME, row[3]);
                grid.set(COL_SHORT_NAME, row[4]);
                grid.set(COL_JAVA_NAME, row[5]);
                grid.set(COL_JAVA_TYPE, row[6]);
                grid.set(COL_DB_NAME, row[7]);
            }
        }
    }

    /**
     * Queries ScheduleTerm beans for the active schedule and outputs
     * the grade term bitmap map (code, name, base map, grade term map, TPY).
     *
     * Uses ScheduleTerm because GradeTerm does NOT have getGradeTermMap().
     */
    private void gatherGradeTermData(ReportDataGrid grid)
    {
        Schedule activeSchedule = findActiveSchedule();

        if (activeSchedule == null)
        {
            return;
        }

        Collection<ScheduleTerm> terms = getScheduleTerms(activeSchedule);

        for (ScheduleTerm term : terms)
        {
            grid.append();
            grid.set(COL_CODE, term.getCode());
            grid.set(COL_NAME, term.getName());
            grid.set(COL_BASE_MAP, term.getBaseTermMap());
            grid.set(COL_GTM_MAP, term.getGradeTermMap());
            grid.set(COL_COVERED_TPY, String.valueOf(term.getCoveredTermsPerYear()));
            grid.set(COL_BASE_TPY, String.valueOf(term.getBaseTermsPerYear()));
        }
    }

    /**
     * Queries ScheduleTerm + ScheduleTermDate beans for the active schedule
     * and outputs expanded term details including date ranges and schedule info.
     */
    private void gatherScheduleTermData(ReportDataGrid grid)
    {
        Schedule activeSchedule = findActiveSchedule();

        if (activeSchedule == null)
        {
            return;
        }

        String scheduleName = activeSchedule.getName();
        String comment = activeSchedule.getComment();

        Collection<ScheduleTerm> terms = getScheduleTerms(activeSchedule);
        SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy");

        for (ScheduleTerm term : terms)
        {
            /*
             * Resolve term date range from ScheduleTermDate records.
             * Each ScheduleTerm may have multiple ScheduleTermDate entries;
             * take the earliest start and latest end.
             */
            PlainDate startDate = null;
            PlainDate endDate = null;

            X2Criteria dateCriteria = new X2Criteria();
            dateCriteria.addEqualTo(ScheduleTermDate.COL_SCHEDULE_TERM_OID, term.getOid());

            QueryByCriteria dateQuery =
                    new QueryByCriteria(ScheduleTermDate.class, dateCriteria);

            Collection<ScheduleTermDate> termDates =
                    getBroker().getCollectionByQuery(dateQuery);

            for (ScheduleTermDate td : termDates)
            {
                PlainDate s = td.getStartDate();
                PlainDate e = td.getEndDate();

                if (s != null && (startDate == null || s.before(startDate)))
                {
                    startDate = s;
                }
                if (e != null && (endDate == null || e.after(endDate)))
                {
                    endDate = e;
                }
            }

            grid.append();
            grid.set(COL_CODE, term.getCode());
            grid.set(COL_NAME, term.getName());
            grid.set(COL_BASE_MAP, term.getBaseTermMap());
            grid.set(COL_GTM_MAP, term.getGradeTermMap());
            grid.set(COL_COVERED_TPY, String.valueOf(term.getCoveredTermsPerYear()));
            grid.set(COL_BASE_TPY, String.valueOf(term.getBaseTermsPerYear()));
            grid.set(COL_SCHED_NAME, scheduleName != null ? scheduleName : "");
            grid.set(COL_START, startDate != null ? sdf.format(startDate) : "");
            grid.set(COL_END, endDate != null ? sdf.format(endDate) : "");
            grid.set(COL_COMMENT, comment != null ? comment : "");
        }
    }

    /**
     * Finds the active schedule for the selected school year context.
     * In school context, scopes to the current school; otherwise returns
     * the first schedule found for the context year.
     *
     * @return Schedule bean, or null if none found
     */
    private Schedule findActiveSchedule()
    {
        if (m_context == null)
        {
            return null;
        }

        X2Criteria criteria = new X2Criteria();
        criteria.addEqualTo(Schedule.COL_DISTRICT_CONTEXT_OID, m_context.getOid());

        if (isSchoolContext())
        {
            criteria.addEqualTo(Schedule.COL_SCHOOL_OID, getSchool().getOid());
        }

        QueryByCriteria query = new QueryByCriteria(Schedule.class, criteria);

        return (Schedule) getBroker().getBeanByQuery(query);
    }

    /**
     * Returns all ScheduleTerm beans for the given schedule, ordered by code.
     *
     * @param schedule the active Schedule
     * @return Collection of ScheduleTerm beans
     */
    private Collection<ScheduleTerm> getScheduleTerms(Schedule schedule)
    {
        X2Criteria criteria = new X2Criteria();
        criteria.addEqualTo(ScheduleTerm.COL_SCHEDULE_OID, schedule.getOid());

        QueryByCriteria query = new QueryByCriteria(ScheduleTerm.class, criteria);
        query.addOrderByAscending(ScheduleTerm.COL_CODE);

        return getBroker().getCollectionByQuery(query);
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#initialize()
     */
    @Override
    protected void initialize() throws X2BaseException
    {
        super.initialize();

        /*
         * Read export mode
         */
        m_mode = (String) getParameter(MODE_PARAM);
        if (StringUtils.isEmpty(m_mode))
        {
            m_mode = MODE_SCHEMA;
        }

        /*
         * Load school year context (used by grade term and schedule term modes)
         */
        String contextOid = (String) getParameter(CONTEXT_OID_PARAM);
        if (!StringUtils.isEmpty(contextOid))
        {
            m_context = (DistrictSchoolYearContext) getBroker().getBeanByOid(
                    DistrictSchoolYearContext.class, contextOid);
        }

        /*
         * CSV formatting
         */
        setIncludeHeaderRow(true);
        setValueDelimiter(',');
        setValueWrapper('"');

        /*
         * Build column lists based on mode
         */
        buildColumns();
    }

    /**
     * Builds the column name and user name lists based on the selected export mode.
     */
    private void buildColumns()
    {
        m_columnNames = new ArrayList<String>();

        if (MODE_SCHEMA.equals(m_mode))
        {
            m_columnNames.add(COL_TABLE);
            m_columnNames.add(COL_CLASS_NAME);
            m_columnNames.add(COL_OID);
            m_columnNames.add(COL_LONG_NAME);
            m_columnNames.add(COL_SHORT_NAME);
            m_columnNames.add(COL_JAVA_NAME);
            m_columnNames.add(COL_JAVA_TYPE);
            m_columnNames.add(COL_DB_NAME);
        }
        else if (MODE_GRADE_TERMS.equals(m_mode))
        {
            m_columnNames.add(COL_CODE);
            m_columnNames.add(COL_NAME);
            m_columnNames.add(COL_BASE_MAP);
            m_columnNames.add(COL_GTM_MAP);
            m_columnNames.add(COL_COVERED_TPY);
            m_columnNames.add(COL_BASE_TPY);
        }
        else if (MODE_SCHEDULE_TERMS.equals(m_mode))
        {
            m_columnNames.add(COL_CODE);
            m_columnNames.add(COL_NAME);
            m_columnNames.add(COL_BASE_MAP);
            m_columnNames.add(COL_GTM_MAP);
            m_columnNames.add(COL_COVERED_TPY);
            m_columnNames.add(COL_BASE_TPY);
            m_columnNames.add(COL_SCHED_NAME);
            m_columnNames.add(COL_START);
            m_columnNames.add(COL_END);
            m_columnNames.add(COL_COMMENT);
        }

        m_columnUserNames = new ArrayList<String>(m_columnNames);
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#saveState(UserDataContainer)
     */
    @Override
    protected void saveState(UserDataContainer userData) throws X2BaseException
    {
        super.saveState(userData);
        runOnApplicationServer();
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getColumnNames()
     */
    @Override
    protected List getColumnNames()
    {
        return m_columnNames;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getColumnUserNames()
     */
    @Override
    protected List getColumnUserNames()
    {
        return m_columnUserNames;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getComment()
     */
    @Override
    protected String getComment()
    {
        return null;
    }

    /**
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getHeader()
     */
    @Override
    protected String getHeader()
    {
        return null;
    }

    /**
     * Returns a mode-specific CSV file name.
     *
     * @see com.follett.fsc.core.k12.tools.exports.ExportJavaSource#getCustomFileName()
     */
    @Override
    public String getCustomFileName()
    {
        if (MODE_SCHEMA.equals(m_mode))
        {
            return "DataDictionarySchema.csv";
        }
        if (MODE_GRADE_TERMS.equals(m_mode))
        {
            return "GradeTermMap.csv";
        }
        if (MODE_SCHEDULE_TERMS.equals(m_mode))
        {
            return "ScheduleTermMap.csv";
        }

        return "SchemaReferenceExport.csv";
    }
}
