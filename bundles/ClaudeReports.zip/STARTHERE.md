# Using AI to Generate & Modify Aspen SIS Reports & Exports

A practical guide for Aspen X2 administrators who want to use Claude Code to create custom reports and CSV exports without writing code by hand.

---

## Why This Works

This download contains everything Claude Code needs to build Aspen reports and exports from scratch:

- **BuildResources/** — a complete development guide covering database schema, Java patterns, JRXML layout, input definitions, and 30+ documented troubleshooting issues
- **CLAUDE.md** files — instructions that Claude Code reads automatically every session
- **Working examples** — production reports and exports that serve as structural references

You describe what you want in plain English. Claude Code reads the guides, writes the Java/JRXML/XML files, and packages the bundle. When something breaks on upload, you paste the error and Claude fixes it.

---

## Prerequisites

### Use Linux (Strongly Recommended)

Claude Code runs natively on Linux and macOS. Windows is not directly supported.

**If you're on Windows**, the easiest path is:

1. **WSL2 (Windows Subsystem for Linux)** — install Ubuntu from the Microsoft Store, then work entirely inside the WSL terminal. This is the recommended approach.
2. Alternatively, use a Linux VM or dual boot.

**Why Linux?** Claude Code is a terminal-based CLI tool. It reads files, runs shell commands, and manages your project — all of which work best in a native Unix environment. WSL2 gives you this on Windows with minimal friction.

### Required Software

| Tool | Purpose | Install |
|------|---------|---------|
| **Node.js 18+** | Runtime for Claude Code | `sudo apt install nodejs npm` or use [nvm](https://github.com/nvm-sh/nvm) |
| **zip** | Bundle packaging | `sudo apt install zip` (usually pre-installed) |

### Anthropic Account

You need an Anthropic account with Claude Code access.

- Claude **Max** subscription ($100/mo or $200/mo) includes Claude Code usage
- Alternatively, use an **API key** with credits at [console.anthropic.com](https://console.anthropic.com)

---

## Getting Started

### 1. Install Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

### 2. Authenticate

```bash
claude
# Follow the prompts to log in with your Anthropic account
```

### 3. Extract the Zip

Extract `ClaudeReports.zip` to a folder on your machine. If you're using WSL, extract it somewhere inside your WSL filesystem (e.g., your home directory):

```bash
mkdir ~/aspen-reports
cd ~/aspen-reports
unzip /path/to/ClaudeReports.zip
```

### 4. Start Working

```bash
cd ~/aspen-reports
claude
```

That's it. Claude Code automatically reads the `CLAUDE.md` files in the folder and understands the entire report architecture, database schema, and development patterns.

---

## What's in the Download

```
ClaudeReports/
├── CLAUDE.md                # Top-level AI instructions (read automatically)
├── STARTHERE.md             # This file
├── BuildResources/          # AI reference guides (Claude reads these automatically)
│   ├── Guide/               # 9 detailed development guide files
│   ├── Templates/           # Skeleton starter files for new reports
│   └── Report Examples/     # Place your exported report bundles here as references
└── Exports/
    └── DEVResources/        # Schema export utility (import into Aspen first)
```

**You don't need to read the guides yourself.** Claude Code reads them and applies the patterns when building reports. The guides exist so the AI produces correct, working code on the first try.

---

## Exporting Your Own Schema Data

Before building reports that reference your district's custom fields, you should export your own database schema using the **DEVResources** export included in this download.

### Step 1: Import the DEVResources Export

1. Log into Aspen as a district administrator
2. Go to **Admin > Tools > Exports/Reports > Import Bundle**
3. Upload `Exports/DEVResources/DEVResources.zip`

### Step 2: Run the Schema Export

1. Go to **Tools > Exports** and find **Schema & Term Reference Export**
2. Select a school year from the dropdown
3. Choose an export mode:
   - **Data Dictionary Schema** — exports all field definitions (Java names, DB columns, data types) for core tables
   - **Grade Term Map** — exports grade term bitmap definitions (Q1–Q4, YR)
   - **Schedule Term Details** — exports schedule term date ranges
4. Run the export and save the CSV

### Step 3: Add Your Schema to the Folder

Place the exported CSV files in `BuildResources/`:

- `DataDictionarySchema.csv` replaces `FullDatabaseSchema_cleaned.csv`
- `GradeTermMap.csv` replaces `GradeTermMap.csv`
- `ScheduleTermMap.csv` replaces `TermMapExpanded.csv`

Now Claude Code has your district's actual field definitions, custom field names, and term structure. This is critical for generating reports that use custom fields specific to your district.

---

## Generating a New Report or Export

### Start a Conversation

Open Claude Code in the extracted folder and describe what you need:

```
claude

> I need a new PDF report that lists all active students grouped by
> homeroom, showing their name, YOG, and guidance counselor. It should
> run from School View > Student tab with a grade level filter.
```

### What to Include in Your Request

The more context you give, the better the result:

- **Output format** — PDF report or CSV export?
- **What data** — which fields/tables? (students, attendance, schedule, staff, etc.)
- **Filters** — what should the user be able to filter on? (date range, grade level, teacher, etc.)
- **Grouping** — how should records be organized? (by homeroom, section, grade, etc.)
- **Where it runs** — which Aspen view and navigation context? (Staff View, School View, District View, specific tab)
- **Any custom fields** — reference your schema export to identify the right field names

### Example Prompts

**Simple student list:**
> Create a CSV export of all active students with their LASID, name, YOG, homeroom, and email address. It should run from School View > Student tab.

**Attendance report:**
> Build a PDF attendance report that shows daily attendance for a selected date range, grouped by homeroom. Include student photos, absence codes, and a summary count per homeroom. It runs from School View > Attendance tab.

**Schedule export:**
> I need an export of all master schedule sections with course number, section number, teacher name, room, period, and enrollment count. Include a term selector dropdown.

### What Happens Next

Claude Code will:

1. Read the development guides in `BuildResources/`
2. Ask clarifying questions if needed (navigation nodes, field names, etc.)
3. Generate all required files (Java, JRXML if PDF, Input XML, bundle-definition.xml)
4. Package everything into a `.zip` bundle

You then upload the `.zip` to Aspen via **Admin > Tools > Exports/Reports > Import Bundle**.

---

## When Things Go Wrong (And They Will)

Aspen compiles Java and JRXML server-side. You won't know if something is broken until you import and run the report. Here's the workflow for resolving issues:

### Compile Errors

If the report fails to run with `ClassNotFoundException` or the results are wrong:

1. **Copy the exact error message** from Aspen's job log
2. **Paste it into Claude Code:**

```
> The report failed with this error:
> ClassNotFoundException: com.x2dev.reports.yourstate.yourdistrict.MyReportData
```

3. Claude Code will diagnose the issue (usually a method that doesn't exist on the Aspen API, a wrong field name, or a missing import) and fix the code
4. It will rebuild the zip — upload it again

### Empty Results

If the report runs but returns no data:

```
> The report ran successfully but the results were empty. I expected
> to see about 200 students. I'm running it from School View in
> my school for the current school year.
```

Common causes Claude will check:
- `getCurrentContext()` returning null (district view issue)
- Wrong enrollment status filter
- Criteria too restrictive
- Schedule OIDs not matching the selected school year

### Wrong Data

If the output has incorrect values:

```
> The export is showing all staff, but it should only show teachers
> matching my filter criteria. Here's a sample of what I'm seeing:
> [paste a few rows]
```

Providing sample data or screenshots helps Claude narrow down the filter logic.

### General Debugging Tips

- **Always paste the exact error** — don't paraphrase
- **Describe what you expected vs what happened**
- **Share sample data** when possible (a few rows from a Quick Report showing the expected output)
- **Mention your context** — which school, which view, which school year
- **Be patient with iteration** — some Aspen API methods don't exist or behave differently than documented. Claude learns from each failure and adapts.

---

## Modifying Existing Reports

To change an existing report:

```
> I want to modify the Homeroom Attendance report to add a column
> for student email address after the Student ID column.
```

Claude Code will:
1. Read the existing Java, JRXML, and Input XML files
2. Make the targeted change
3. Rebuild the zip

You can also ask for broader changes:

```
> Can you add a date range filter to the Attendance Policy export
> so users can specify a custom start and end date instead of
> selecting a grade term?
```

---

## Best Practices

- **One report/export per conversation** — keeps context focused and avoids confusion
- **Test with small data first** — run against a single homeroom or section before going district-wide
- **Keep your schema export current** — re-run the DEVResources export if custom fields change
- **Don't edit generated code manually** — let Claude Code make all changes so it stays aware of the current state
- **Use existing reports as references** — tell Claude "follow the same pattern as the Homeroom Attendance report" for consistency
- **Use version control (optional)** — consider initializing a git repo in your folder (`git init`) to track changes and roll back if needed

---

## Quick Reference: Common Commands

| What You Want | What to Say |
|---|---|
| Create a new report | "I need a new PDF report that..." |
| Create a new export | "I need a new CSV export that..." |
| Fix a compile error | "The report failed with: [paste error]" |
| Fix empty results | "The report ran but returned no data. I expected..." |
| Modify an existing report | "Change the [report name] to add/remove/modify..." |
| Package a bundle | "Rebuild the zip bundle" |

---

## Additional Resources

- **Aspen X2 Help Center**: https://ma-beverly.myfollett.com/aspen/help/Content/Help_Center/Aspen_Main.htm
- **Claude Code Documentation**: https://docs.anthropic.com/en/docs/claude-code
- **Development Guides**: `BuildResources/Guide/00-AI-WORKFLOW.md` (start here)
